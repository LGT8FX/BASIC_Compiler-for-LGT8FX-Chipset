/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvAC.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvAC.h
 * @brief Header File of AC
 *		
 */

#ifndef _AC_H_
#define _AC_H_

/**********************************************************************************
***					          	MACRO AND DEFINITIONS							***													  	
**********************************************************************************/
#define E_ACBG_AIN0		0		/**< AIN0 is applied to the positive input */
#define E_ACBG_BGR		1		/**< Bandgap reference volatage is applied to the 
									positive input */
#define E_ACME_ADC0		0		/**< ADC0 is applied to the negetaive intput */
#define E_ACME_ADC1		1		/**< ADC1 is applied to the negetaive intput */
#define E_ACME_ADC2		2		/**< ADC2 is applied to the negetaive intput */
#define E_ACME_ADC3		3		/**< ADC3 is applied to the negetaive intput */
#define E_ACME_ADC4		4		/**< ADC4 is applied to the negetaive intput */
#define E_ACME_ADC5		5		/**< ADC5 is applied to the negetaive intput */
#define E_ACME_ADC6		6		/**< ADC6 is applied to the negetaive intput */
#define E_ACME_ADC7		7		/**< ADC7 is applied to the negetaive intput */
#define E_ACME_AIN1		8		/**< AIN1 is applied to the negetive input */
	
/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/**
 * @enum emAcis
 *	AC Interrupt Mode Select 
 */
enum emAcis
{
	E_ACIS_AE,				/**< Any edge of ACO generates an interrupt */
	E_ACIS_REV,				/**< Reserved */
	E_ACIS_FE,				/**< Falling edge of ACO generates an interrupt */
	E_ACIS_RE				/**< Rising edge of ACO generates an interrupt */
};

/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _AC_SRC_
#endif

#define DrvAC_Stop() ACSR |= 0x80
#define DrvAC_Start() ACSR &= 0x7f

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvAC_Init(void);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/

