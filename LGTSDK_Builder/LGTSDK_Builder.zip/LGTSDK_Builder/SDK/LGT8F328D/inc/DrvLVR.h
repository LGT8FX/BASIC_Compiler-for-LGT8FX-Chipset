/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvLVR.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvLVR.h
 * @brief Header File of LVR
 *		
 */

#ifndef _LVR_H_
#define _LVR_H_

/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/**
 * @enum emWclk
 * 	WatchDog Clock source
 */
typedef enum _VDTS
{
	E_LVR_V1D8,	/**< VDTS = 1.8V */
	E_LVR_V2D7,	/**< VDTS = 2.7V */
	E_LVR_V4D3	/**< VDTS = 4.3V */
} emVDTS;


/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _DRVLVR_SRC_
#endif
	
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvLVR_Init(void);
void DrvLVR_Enable(void);
void DrvLVR_Disable(void);
void DrvLVR_SetVDTS(emVDTS vdts);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/
