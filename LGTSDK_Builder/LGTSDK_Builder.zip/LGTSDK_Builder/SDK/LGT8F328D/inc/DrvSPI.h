/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvSPI.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvSPI.h
 * @brief Header File of SPI driver 
 *		
 */

#ifndef _SPI_H_
#define _SPI_H_

/**********************************************************************************
***					          		MODULE USED									***													  	
**********************************************************************************/

/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/** 
 * @enum emSpiT
 *	SPI Type
 */
enum emSpiT
{
	E_SPI_TYPE0 = 0x0,		/**< CPOL=0, CPHA=0: (Leading Edge)Sample(Rising) \
									(Trailing Edge)Setup(Falling) */
	E_SPI_TYPE1,			/**< CPOL=0, CPHA=1: (Leading Edge)Setup(Rising)  \
									(Trailing Edge)Sample(Falling) */
	E_SPI_TYPE2,			/**< CPOL=1, CPHA=0: (Leading Edge)Sample(Falling)\
									(Trailing Edge)Setup(Rising) */
	E_SPI_TYPE3				/**< CPOL=1, CPHA=1: (Leading Edge)Setup(Falling) \
									(Trailing Edge)ample(Rising) */
};

/** 
 * @enum emSckSel
 *	SPI clock rate select\n
 * 	Relationship between SCK and the Oscillator Frequency 
 */
enum emSckSel
{
	E_SCK_DIV_4 = 0x0,   	/**< SCK Frequency = Fosc/4 */		
	E_SCK_DIV_16,   		/**< SCK Frequency = Fosc/16 */		
	E_SCK_DIV_64,   		/**< SCK Frequency = Fosc/64 */		
	E_SCK_DIV_128,   		/**< SCK Frequency = Fosc/128 */		
	E_SCK_DIV_2,   			/**< SCK Frequency = Fosc/2 */		
	E_SCK_DIV_8,   			/**< SCK Frequency = Fosc/8 */		
	E_SCK_DIV_32,   		/**< SCK Frequency = Fosc/32 */		
};

/** 
 * @enmu emDord
 * 	Data Order 
 */
enum emDord
{
	E_DORD_MSB_FIRST = 0x0,	/**< the MSB of the data word is transmitted first */
	E_DORD_LSB_FIRST		/**< the LSB of the data word is transmitted first */
};

/**
 * @enum emSpiMode
 * 	Master/Slave Select 
 */
enum emSpiMode
{
	E_SPI_SLAVE = 0x0, 	 	/**< Select SPI Slave mode */
	E_SPI_MASTER			/**< Select SPI Master mode */
};

/**********************************************************************************
***					          	MACROS AND DEFINTIONS							***													  	
**********************************************************************************/
/** SS=HIGH */
#define DrvSPI_SPSSOff()	do { __ASM("sbi 0x05, 2"); } while(0)
/** SS=LOW */
#define DRVSPI_SPSSOn()		do { __ASM("cbi 0x05, 2"); } while(0)

#define DrvSPI_IsDataReady() (SPSR & (1 << SPIF))
#define DrvSPI_SendByte(value) SPDR = value
#define DrvSPI_GetByte() (SPDR)

/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _DRVSPI_SRC_
#endif

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvSPI_Init(void);
void DrvSPI_Transceive(u8 u8Len, u8 *pu8Buf);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/
