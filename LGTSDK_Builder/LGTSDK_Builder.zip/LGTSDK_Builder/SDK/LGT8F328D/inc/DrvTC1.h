/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvTC1.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvTC1.h
 * @brief Header File of TC1 driver 
 *		
 */

#ifndef _TIMMER1_H_
#define _TIMMER1_H_

/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/**
 * @enum emCS1
 *  the description of TC1's Clock Select
 */
enum emCS1
{
	E_CS1_NO = 0x0,		/**< no clock source */
	E_CS1_DIV1,			/**< system clock */
	E_CS1_DIV8,			/**< clk/8, from prescaler */
	E_CS1_DIV64,		/**< clk/64, from prescaler */
	E_CS1_DIV256,		/**< clk/256, from prescaler */
	E_CS1_DIV1024,		/**< clk/1024, from prescaler */
	E_CS1_T1F,			/**< external clock source from PIN T1, Clock on falling edge */
	E_CS1_T1R			/**< external clock source from PIN T1, Clock on rising edge */
};

/**
 * @enum emWgm1
 *	the description of TC1's operation mode 
 */
enum emWgm1
{
	E_WGM1_NORM = 0x0, 		/**< normal mode */
	E_WGM1_PCPWM_8B, 		/**< Phase Correct PWM mode, TOP = 0xff */
	E_WGM1_PCPWM_9B, 		/**< Phase Correct PWM mode, TOP = 0x1ff */
	E_WGM1_PCPWM_10B, 		/**< Phase Correct PWM mode, TOP = 0x3ff */
	E_WGM1_CTC_O,			/**< Clear Timer on Compare Match mode TOP = OCR1A */   
	E_WGM1_FPWM_8B,			/**< Fast PWM mode TOP = 0xff */
	E_WGM1_FPWM_9B,			/**< Fast PWM mode TOP = 0x1ff */
	E_WGM1_FPWM_10B,		/**< Fast PWM mode TOP = 0x3ff */
	E_WGM1_PFCPWM_I,		/**< Phase and Frequency Correct PWM Mode TOP = ICR1 */
	E_WGM1_PFCPWM_O,		/**< Phase and Frequency Correct PWM Mode TOP = OCR1A */
	E_WGM1_PCPWM_I,			/**< Phase Correct PWM Mode TOP = ICR1 */
	E_WGM1_PCPWM_O,			/**< Phase Correct PWM mode TOP = OCR1A */
	E_WGM1_CTC_I,			/**< Clear Timer on Compare Match mode Top = ICR1 */
	E_WGM1_FPWM_I = 14,		/**< Fast PWM mode TOP = ICR1 */
	E_WGM1_FPWM_O			/**< Fast PWM mode TOP = OCR1A */
};

/**
 * @enum emCom1Nopwm 
 *	Compare Output mode, non-PWM mode,
 *	Use these enumeration type when WGM1 = NORM or CTC 
 */
enum emCom1Nopwm
{
	E_COM1_NDIS = 0x0,	/**< disable OC */
	E_COM1_CTOG,		/**< toggle on compare match */
	E_COM1_CCLR,		/**< clear on comapre match */
	E_COM1_CSET			/**< set on compare match */
};

/**
 * @enum emCom1Fpwm 
 *	Compare Output mode, FPWM mode,
 *	Use these enumeration type when WGM1 = FPWM 
 */
enum emCom1Fpwm
{
	E_COM1_FDIS = 0x0,	/**< disable OC */
	E_COM1_FTOG,		/**< when WGM1[3] = 1: toggle on compare match */
	E_COM1_CCLR_MSET,	/**< clear on compare match, set on maximum  */
	E_COM1_CSET_MCLR	/**< set on compare match, clear on maximum */
};

/**
 * @enum emCom1Pcpwm 
 *	Compare Output mode, PCPWM mode,
 *	Use these enumeration type when WGM1 = PCPWM or PFCPWM
 */
enum emCom1Pcpwm
{
	E_COM1_PDIS = 0x0,	/**< disable OC */
	E_COM1_PTOG,		/**< when WGM1[3] = 1: toggle on compare match */
	E_COM1_UCLR_DSET,   /**< clear on compare match when up-counting, set on compare
							* match when down-counting */
	E_COM1_USET_DCLR	/**< set on compare match when up-counting, clear on compare
							* match when down-counting */
};

/**
 * @enum emIcnc1
 *	Input Capture Noise Canceler
 */
enum emIcnc1
{
	E_ICNC1_ENA = 0x0,	/**< Activates the Input Capture Noise Canceler */
	E_ICNC1_DIS			/**< Disable the Input Capture Noise Canceler */
};

/**
 * @enum emIces1
 *	Input Capture Edge Select
 */
enum emIces1
{
	E_ICES1_FE = 0x0,	/**< A falling edge is used as trigger */
	E_ICES1_RE			/**< A rising edge is used as trigger */
};

/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _DRVTC1_SRC_
#endif

#define DrvTC1_SetCNT(value) do { \
	DrvMISC_CLRI(); \
	TCNT1H = (value >> 8) & 0xff; \
	TCNT1L = (value & 0xff); \
	DrvMISC_RESI(); \
} while(0)

#define DrvTC1_SetOCA(value) do { \
	DrvMISC_CLRI(); \
	OCR1AH = (value >> 8) & 0xff; \
	OCR1AL = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define DrvTC1_SetOCB(value) do { \
	DrvMISC_CLRI(); \
	OCR1BH = (value >> 8) & 0xff; \
	OCR1BL = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define DrvTC1_SetICR(value) do { \
	DrvMISC_CLRI(); \
	ICR1H = (value >> 8) & 0xff; \
	ICR1L = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define _tc1_GetCNT() ((TCNT1H << 8) | TCNT1L)
#define _tc1_GetOCA() ((OCR1AH << 8) | OCR1AL)
#define _tc1_GetOCB() ((OCR1BH << 8) | OCR1BL)
#define _tc1_GetICR() ((ICR1H << 8) | ICR1L)
	
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvTC1_Init(void);
void DrvTC1_Stop(void);
void DrvTC1_Restart(void);
u16 DrvTC1_GetCNT(void);
u16 DrvTC1_GetOCA(void);
u16 DrvTC1_GetOCB(void);
u16 DrvTC1_GetICR(void);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/

