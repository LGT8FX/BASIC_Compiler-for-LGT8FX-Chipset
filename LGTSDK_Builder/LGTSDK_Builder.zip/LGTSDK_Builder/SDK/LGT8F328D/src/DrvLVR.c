/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F328D												    	**
** filename : DrvLVR.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvLVR.c
 * @brief Source File of LVR
 */

/** complier directives */
#define _DRVLVR_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for LVR initialize */

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvRTC_Init(void)
 * @brief Initialize RTC and run. 
 * 	RCK must be enabled, 
 */
void DrvLVR_Init(void)
{
	VDTCR |= 0xC0;
	VDTCR |= (0xC1 | (LVR_VDTS << 1)); 
}

void DrvLVR_Enable(void)
{
	VDTCR |= 0xC0;
	VDTCR |= 0xC1;
}

void DrvLVR_Disable(void)
{
	VDTCR |= 0xC0;
	VDTCR &= 0xC6;
}

void DrvLVR_SetVDTS(emVDTS vdts)
{
	VDTCR |= 0xC0;
	VDTCR |= (0xC0 | (vdts << 1));
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/

