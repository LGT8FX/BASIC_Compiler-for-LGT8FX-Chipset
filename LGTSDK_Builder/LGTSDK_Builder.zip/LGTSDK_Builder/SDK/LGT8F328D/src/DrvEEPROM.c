/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F328D												    	**
** filename : DrvEEPROM.c  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/** complier directives */
#define _DrvEEPROM_SRC_C_

/**********************************************************************************
*** 							MODULES USED									*** 													
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***					         MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/** macro for Flash Control Enable */

/**********************************************************************************
*** 								LOCAL VARIABLES 							*** 													
**********************************************************************************/

/**********************************************************************************
*** 						  EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvEEPROM_Init(void)
{
	ECCR = 0x80;
	ECCR = 0x40; // enable 1KB EEPROM
}

/**
 * @fn void DrvEEPROM_ProgByte(u16 u16Addr, u16 u16Len, u8 *pu8Data)
 *	Program EEPROM in Byte mode
 * @param u16Addr
 *	EEPROM Address which specify the Write Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the source data
 */
void DrvEEPROM_ProgByte(u16 u16Addr, u8 u8Data)
{
	// wait for completion of previous write
	// while(EECR & (1 << EEPE));
	
	// address
	EEARH = u16Addr >> 8;
	EEARL = (u16Addr) & 0xff;
	// data
	EEDR = u8Data;
	// Program Mode
	EECR = 0x04;
	EECR = 0x02;
	NOP(); NOP();
}

/** 
 * @fn void DrvEEPROM_ReadEByte(u16 u16Addr, u16 u16Len, u8 *pu8Data)
 *	Read data from EEPROM in Byte mode
 * @param u16Addr
 *	EEPROM Address which specify the Read Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the destination space
 */
u8 DrvEEPROM_ReadByte(u16 u16Addr)
{
	// address
	EEARH = u16Addr >> 8;
	EEARL = (u16Addr) & 0xff;
	// start eeprom read by writting EERE
	EECR |= (1 << EERE);
	NOP(); NOP();

	// return data from data register
	return EEDR;
}

/**
 * @fn void DrvEEPROM_ProgHWord(u16 wAddr, u16 wData)
 *	Write 2-byte
 * @param wAddr
 *	Half-word address
 * @param wData
 *	2-byte data
 */
void DrvEEPROM_ProgHWord(u16 u16Addr, u16 u16Data)
{
	EEARL = 0;
	EEDR = u16Data & 0xff;
	EEARL = 1;
	EEDR = u16Data >> 8;

	EEARH = u16Addr >> 8;
	EEARL = u16Addr & 0xff;
	// Program Mode
	EECR = 0x24;
	EECR = 0x22;	
	NOP(); NOP();
}

/**********************************************************************************
*** 										EOF 								*** 													
**********************************************************************************/

