/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F328D												    	**
** filename : DrvPWR.c	 		 												**
** version  : 1.0 													   			**
** date     : April 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	Logic Green Technologies								**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2013
Revised by 	: LGT Software Group
Description : Original version.
*/


/** complier directives */
#define _DRVPWR_SRC_C_

/**********************************************************************************
***					           	 	MODULES USED								***													  	
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***					            MACRO AND DEFINITIONS							***													  	
**********************************************************************************/  


/**********************************************************************************
***					            EXPORTED FUNCTIONS								***													  	
**********************************************************************************/  
void DrvPWR_Init(void)
{
	// Set power/off lock
	DRVPWR_PWROFF_LOCK();
}

/**
 * @fn void DrvPWR_Sleep()
 */
void DrvPWR_Sleep(EMSMODE emSMode)
{
	u8 u8Mod;

	u8 CLKPR_reg = CLKPR;
	u8 LDOCR_reg = LDOCR;
	u8 PMCR_reg = PMCR;
	u8 SREG_reg = SREG;
	CLI();

	if(emSMode == E_SLEEP_POFFS0)
	{
		u8Mod = (PMCR & 0x1F) | 0x40;
		PMCR = 0x80;
		PMCR = u8Mod;

		CLKPR = 0x80;
		CLKPR = 0x00;
	}
	else
	{
		CLKPR = 0x80;
		CLKPR = 0x08;
	}
	
	NOP(); NOP();

	LDOCR = 0x80;
	LDOCR = 0x02;

	u8Mod = ((emSMode & 0x7) << 1) | 0x1;
	SMCR = u8Mod;
	SLEEP();

	NOP(); NOP();
	DRVPWR_PWROFF_LOCK();

	LDOCR = 0x80;
	LDOCR = LDOCR_reg;
	
	CLKPR = 0x80;
	CLKPR = CLKPR_reg;

	if(emSMode == E_SLEEP_POFFS0)
	{
		PMCR = 0x80;
		PMCR = PMCR_reg;
	}

	SREG = SREG_reg;
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/  

