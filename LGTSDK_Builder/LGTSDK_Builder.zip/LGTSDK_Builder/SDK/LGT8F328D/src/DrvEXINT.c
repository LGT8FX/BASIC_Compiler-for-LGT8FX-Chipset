/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F328D												    	**
** filename : DrvINT.c		  		   	 										**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvINT.c
 * @brief Source File of External Interrupt and PIN Change Interrupt 
 */

/** complier directives */
#define _DRVINT_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for External Interrupt initialize */

#define EXINT_PCIBEN (EXINT_PCIB7MSK|EXINT_PCIB6MSK|EXINT_PCIB5MSK|EXINT_PCIB4MSK| \
		EXINT_PCIB3MSK|EXINT_PCIB2MSK|EXINT_PCIB1MSK|EXINT_PCIB0MSK)
#define EXINT_PCICEN (EXINT_PCIC6MSK|EXINT_PCIC5MSK|EXINT_PCIC4MSK| \
		EXINT_PCIC3MSK|EXINT_PCIC2MSK|EXINT_PCIC1MSK|EXINT_PCIC0MSK)
#define EXINT_PCIDEN (EXINT_PCID7MSK|EXINT_PCID6MSK|EXINT_PCID5MSK|EXINT_PCID4MSK| \
		EXINT_PCID3MSK|EXINT_PCID2MSK|EXINT_PCID1MSK|EXINT_PCID0MSK)
#define EXINT_PCIEEN (EXINT_PCIE6MSK|EXINT_PCIE5MSK|EXINT_PCIE4MSK| \
		EXINT_PCIE3MSK|EXINT_PCIE2MSK|EXINT_PCIE1MSK|EXINT_PCIE0MSK)

#define EXINT_PCIBMSK ((EXINT_PCIB7MSK << 7)|(EXINT_PCIB6MSK << 6)|(EXINT_PCIB5MSK << 5)|(EXINT_PCIB4MSK << 4)| \
		(EXINT_PCIB3MSK << 3)|(EXINT_PCIB2MSK << 2)|(EXINT_PCIB1MSK << 1)|EXINT_PCIB0MSK)
#define EXINT_PCICMSK ((EXINT_PCIC6MSK << 6)|(EXINT_PCIC5MSK << 5)|(EXINT_PCIC4MSK << 4)| \
		(EXINT_PCIC3MSK << 3)|(EXINT_PCIC2MSK << 2)|(EXINT_PCIC1MSK << 1)|EXINT_PCIC0MSK)
#define EXINT_PCIDMSK ((EXINT_PCID7MSK << 7)|(EXINT_PCID6MSK << 6)|(EXINT_PCID5MSK << 5)|(EXINT_PCID4MSK << 4)| \
		(EXINT_PCID3MSK << 3)|(EXINT_PCID2MSK << 2)|(EXINT_PCID1MSK << 1)|EXINT_PCID0MSK)
#define EXINT_PCIEMSK ((EXINT_PCIE6MSK << 6)|(EXINT_PCIE5MSK << 5)|(EXINT_PCIE4MSK << 4)| \
		(EXINT_PCIE3MSK << 3)|(EXINT_PCIE2MSK << 2)|(EXINT_PCIE1MSK << 1)|EXINT_PCIE0MSK)

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/** 
 * @fn void DrvEXINT_Init(void)
 * @brief Initial External Interrupt Controller
 */
void DrvEXINT_Init(void)
{
	u8 u8Tmp;
#if (EXINT_INT0EN | EXINT_INT1EN)
	/** Store SREG, & disable globall interupt */
	u8Tmp = SREG;
	CLI();
	/** Set Interrupt Sense */
	EICRA = (EXINT_INT0ISC << ISC00) | (EXINT_INT1ISC << ISC10);
	/** Set Interrupt Enable */
	EIMSK = (EXINT_INT0EN << INT0) | (EXINT_INT1EN << INT1);
	/** Clear interupt flag */
	EIFR = (EXINT_INT0EN << INT0) | (EXINT_INT1EN << INT1);
	/** Restore SREG */
	SREG = u8Tmp;
#endif

#if (EXINT_PCIBEN | EXINT_PCICEN | EXINT_PCIDEN | EXINT_PCIEEN)
	/** Store SREG & disable global interrupt */
	u8Tmp = SREG;
	CLI();
	/** Set PIN Change Interrupt Mask */
#if EXINT_PCIBEN
	PCMSK0 = EXINT_PCIBMSK;
#endif
#if EXINT_PCICEN
	PCMSK1 = EXINT_PCICMSK;
#endif
#if EXINT_PCIDEN
	PCMSK2 = EXINT_PCIDMSK;
#endif
#if EXINT_PCIEEN
	PCMSK3 = EXINT_PCIEMSK;
#endif
	/** Set PIN Change Interrupt Enable */
	PCICR = (EXINT_PCIBEN << PCIE0) | (EXINT_PCICEN << PCIE1) | \
			(EXINT_PCIDEN << PCIE2) | (EXINT_PCIEEN << PCIE3);
	/** Clear Interrupt Flag */
	PCIFR = (EXINT_PCIBEN << PCIE0) | (EXINT_PCICEN << PCIE1) | \
			(EXINT_PCIDEN << PCIE2) | (EXINT_PCIEEN << PCIE3);
	/** Restore SREG */
	SREG = u8Tmp;
#endif
}


/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/
