/*********************************************************************************
** 										**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                    	**
**                                                                         	**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvAC1.c
 * @brief Source File of AC1
 */

/** complier directives */
#define _DRVAC1_SRC_

/**********************************************************************************
***     MODULES USED								***
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***  MACROS AND DEFINITIONS							***
**********************************************************************************/ 
/* Arguments for AC initialize */
#if (AC_C1PS == E_C1PS_DAC) || (AC_C1PS == E_C1PS_OFF)
#define	AC_C1BG	1
#else
#define	AC_C1BG 0
#endif

#if (AC_C1PS == E_C1PS_ACXP) || (AC_C1PS == E_C1PS_OFF)
#define	AC_C1PS0 1
#else
#define	AC_C1PS0 0
#endif

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
/**
 * @fn void DrvAC1_Init(void)
 * @brief Initialize AC1.
 */
void DrvAC1_Init(void)
{
	// Disable AC
	C1SR = (1 << C1D) | (1 << C1I);
	
	// {C1BG, C1PS0} to determine posedge source
	C1XR = (AC_C1OE << C1OE) | (AC_C1PS0 << C1PS0) | (AC_C1WKE << C1WKE) |\
	       (AC_C1FEN << C1FEN) | (AC_C1FS & 0x3);

	// CME1 from ADCSRB to determine negedge source
	ADCSRB &= 0xcf;
	ADCSRB |= (AC_C1NS << CME10);

	// set AC
	C1SR = ((AC_C1BG << C1BG) | (AC_C1IE << C1IE) | \
				(AC_C1IC << C1IC) | (AC_C1IS << C1IS0));
}

/**********************************************************************************
*** EOF 									***
**********************************************************************************/

