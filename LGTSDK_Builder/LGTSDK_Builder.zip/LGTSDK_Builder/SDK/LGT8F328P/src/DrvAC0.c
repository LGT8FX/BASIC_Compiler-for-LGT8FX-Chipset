/*********************************************************************************
** 										**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                    	**
**                                                                         	**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvAC0.c
 * @brief Source File of AC0
 */

/** complier directives */
#define _DRVAC0_SRC_

/**********************************************************************************
***     MODULES USED								***
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***  MACROS AND DEFINITIONS							***
**********************************************************************************/ 
/* Arguments for AC initialize */
#if (AC_C0PS == E_C0PS_DAC) || (AC_C0PS == E_C0PS_OFF)
#define	AC_C0BG	1
#else
#define AC_C0BG 0
#endif

#if (AC_C0PS == E_C0PS_ACXP) || (AC_C0PS == E_C0PS_OFF)
#define	AC_C0PS0 1
#else
#define AC_C0PS0 0
#endif

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
/**
 * @fn void DrvAC0_Init(void)
 * @brief Initialize AC0.
 */
void DrvAC0_Init(void)
{
	// Disable AC
	C0SR = (1 << C0D) | (1 << C0I);
	
	// {C0BG, C0PS0} to determine posedge source
	C0XR = (AC_C0OE << C0OE) | (AC_C0PS0 << C0PS0) | (AC_C0WKE << C0WKE) |\
	       (AC_C0FEN << C0FEN) | (AC_C0FS & 0x3);	

	// CME0 from ADCSRB to determine negedge source
	ADCSRB &= 0x3f;
	ADCSRB |= (AC_C0NS << CME00);
				
	// set AC
	C0SR = ((AC_C0BG << C0BG) | (AC_C0IE << C0IE) | \
				(AC_C0IC << C0IC) | (AC_C0IS << C0IS0));
}

/**********************************************************************************
*** EOF 									***
**********************************************************************************/

