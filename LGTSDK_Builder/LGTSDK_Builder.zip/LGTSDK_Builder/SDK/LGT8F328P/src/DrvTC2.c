/*
**********************************************************************************
**								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                               		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvTC2.c
 * @brief Source File of TC2 driver 
 */

/** complier directives */
#define _DRVTC2_SRC_

/**********************************************************************************
***           MODULES USED							***
**********************************************************************************/ 
#include "allinone.h"

#if (TC2_CS2 == 0)
#warning <E0:Timer/Counter 2> No clock source selected for Timer 2
#endif	

#if ((TC2_WGM2 != 0) && (TC2_WGM2 != 2)) && (TC2_COM2A == 1)
#warning <W1:Timer/Counter 2> Selected compare(A) mode only support by Normal/CTC mode
#endif

#if ((TC2_WGM2 != 0) && (TC2_WGM2 != 2)) && (TC2_COM2B == 1)
#warning <W1:Timer/Counter 2> Selected compare(B) mode only support by Normal/CTC mode
#endif

#if ((TC2_WGM2 == 0) || (TC2_WGM2 == 2) || (TC2_WGM2 == 4) || (TC2_WGM2 == 5)) && (TC2_OC2AEN == 1) && (TC2_COM2A == 1)
#warning <W1:Timer/Counter 2> OC2A only support 50% duty ratio PWM with current configuration
#endif

#if ((TC2_WGM2 == 0) || (TC2_WGM2 == 2)) && (TC2_OC2AEN == 1) && (TC2_COM2A != 1)
	#warning <W1:Timer/Counter 2> There will no PWM output on OC2A with selected compare mode 
#endif

#if ((TC2_WGM2 == 0) || (TC2_WGM2 == 2)) && (TC2_OC2BEN == 1) && (TC2_COM2B != 1)
	#warning <W1:Timer/Counter 2> There will no PWM output on OC2B with selected compare mode 
#endif

#if (TC2_WGM2 == 2) || (TC2_WGM2 == 4) || (TC2_WGM2 == 5)
#if (TC2_OCR2B > TC2_OCR2A)
#warning <E0:Timer/Counter 2> OCR2B should not over than OCR2A in selected mode
#endif
#endif	

#if (MMCU_PACKAGE == MMCU_QFP48L)
#define	TC2_C2ASX	TC2_C2AIO
#define	TC2_C2BSX	TC2_C2BIO
#else
#define	TC2_C2ASX	0
#define	TC2_C2BSX	0
#endif

/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for TC2 initialize */

static u8 _tccr2b = 0;
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvTC2_Init(void)
 * @brief Initialize TC2 and run. \n
 *	The arguments of this function are macros (TC2_CS2,TC2_WGM2,argCOM20,argOCR2,\n
 *	TC2_TCNT2,argOC2Ena). Before calling you should give the correct value to \n
 *  shese macros according your application
 */
#if (TC2_MODE == 0)
void DrvTC2_Init(void)
{
	/** 1. Stop timer */
	TCCR2B = 0x0;

	/** 2. Force compare match: OC = 1*/
	// The setup of the OC2 should be performed before setting 
	// the Data Direction Register for the port pin to output
	// set OC2 before DDR_oc2 is set
	TCCR2A = (E_COM2_CSET << COM2A0) | (E_COM2_CSET << COM2B0);
	// force compare match
	TCCR2B = 0xc0;

	/** 3. Set PIN OC's direction */
#if (TC2_C2BSX == 1) || (TC2_C2ASX == 1)
	u8	btmp = PMX1 | (TC2_C2BSX << 1) | TC2_C2ASX;
	PMX0 = 0x80;
	PMX1 = btmp;
#endif

#if (TC2_C2ASX == 1)
	DDRF |= (1 << PF6);
#else 
	DDRB |= (TC2_OC2AEN << PB3);
#endif

#if (TC2_C2BSX == 1)
	DDRF |= (1 << PF7);
#else
	DDRD |= (TC2_OC2BEN << PD3);
#endif
	
	/** 4. Initiate TCNT0 */
	TCNT2 = TC2_TCNT2;
	/** 5. Initiate (OCR)output compare register */
	OCR2A = TC2_OCR2A;
	OCR2B = TC2_OCR2B;

	/** 6. Config Interrupt if OCF2 or TOV2 is enabled */
#if (TC2_OCF2AEN == TRUE) || (TC2_OCF2BEN == TRUE) || (TC2_TOV2EN == TRUE)
	// Clear interrupt flag
	TIFR2 = 7;
	TIMSK2 = TC2_TOV2EN | (TC2_OCF2AEN << 1) | (TC2_OCF2BEN << 2);	
#endif
	
	/** 7. Initiate TCCR2A and TCCR2B */
	TCCR2A = (TC2_COM2A << COM2A0) | (TC2_COM2B << COM2B0) |\
			((TC2_WGM2 & 0x3) << WGM20);
	TCCR2B = TC2_CS2 | (((TC2_WGM2 & 0x4) >> 2) << WGM22);
}
#endif

/**
 * 	@fn void DrvTC2_SwitchClockSrc(E_TC2_MODE clkSrc, u8 TCNTLoad, u8 OCRLoad, u8 TCCRLoad)
 * Description:
 *		a disable the T/C2 interrupts by clearing OCIE2 and TIOE2.
 *		b. Select clock source by setting AS2 as appropriate.
 *		c. write new values to TCNT2, OCR2 and TCCR2
 *		d. to switch to asynchronous operations: wait for TCN2UB, OCR2UB, and TCR2UB.
 *		e. clear the T/C interrupt flags
 *		f. Enable interrupts, if needed.	
 * 
 */
#if (TC2_MODE == 1) 
void DrvTC2_Init(void)
{
	// a. disable the T/C2 interrupts by clearing OCIE2 and TIOE2.
	TIMSK2 = 0;

	// select clock sources between internal 32K/RC or external crystal
	ASSR |= (TC2_ACLKS << 7);
	
	// b. Select clock source by setting AS2 as appropriate.
	ASSR |= (1 << 5);

	/** 3. Set PIN OC's direction */
	DDRB |= (TC2_OC2AEN << PB3);
	DDRD |= (TC2_OC2BEN << PD3);

	// c. write new values to TCNT2, OCR2 and TCCR2

	TCNT2 = TC2_TCNT2;
	// output compare register
	OCR2A = TC2_OCR2A;
	OCR2B = TC2_OCR2B;

	// control register
	TCCR2A = (TC2_COM2B << COM2B0) | (TC2_COM2A << COM2A0) | ((TC2_WGM2 & 0x3));
	TCCR2B = TC2_CS2 | (((TC2_WGM2 & 0x4) >> 2) << WGM22);
	
	// d. to switch to asynchronous operations: wait for TCN2UB, OCR2UB, and TCR2UB.
	//TC2_ASSR_DTE(BIT(TCN2UB));
	//TC2_ASSR_DTE(BIT(OCR2AUB));
	//TC2_ASSR_DTE(BIT(OCR2BUB));
	//TC2_ASSR_DTE(BIT(TCR2AUB));
	//TC2_ASSR_DTE(BIT(TCR2BUB));
	/** 6. Config Interrupt if OCF2 or TOV2 is enabled */
#if (TC2_OCF2AEN == TRUE) || (TC2_OCF2BEN == TRUE) || (TC2_TOV2EN == TRUE)
	// Clear interrupt flag
	TIFR2 = 7;
	TIMSK2 = TC2_TOV2EN | (TC2_OCF2AEN << 1) | (TC2_OCF2BEN << 2);	
#endif
}
#endif

void DrvTC2_Stop(void)
{
	_tccr2b = TCCR2B;
	TCCR2B = 0;
}

void DrvTC2_Restart(void)
{
	TCCR2B = _tccr2b;
}


/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/
