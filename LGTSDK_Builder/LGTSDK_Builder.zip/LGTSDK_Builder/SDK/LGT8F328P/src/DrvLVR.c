/*********************************************************************************
**								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvLVR.c
 * @brief Source File of LVR
 */

/** complier directives */
#define _DRVLVR_SRC_

/**********************************************************************************
***	MODULES USED								***
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***  	MACROS AND DEFINITIONS							***
**********************************************************************************/ 
/* Arguments for LVR initialize */

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
/**
 * @fn void DrvRTC_Init(void)
 * @brief Initialize RTC and run. 
 * 	RCK must be enabled, 
 */
void DrvLVR_Init(void)
{
	VDTCR = 0xC0;
	VDTCR = 0xC1 | (LVR_VDTS << 2); 

	NOP(); NOP();
	VDTCR = 0xC0;
	VDTCR = 0xC3 | (LVR_VDTS << 2);
}

void DrvLVR_Enable(void)
{
	VDTCR = 0xC1;
	VDTCR = 0xC1 | (LVR_VDTS << 2); 

	NOP(); NOP();
	VDTCR = 0xC1;
	VDTCR = 0xC3 | (LVR_VDTS << 2);
}

void DrvLVR_Disable(void)
{
	u8 btmp = VDTCR & 0xfc;
	VDTCR = 0xC0;
	VDTCR = btmp;
}

void DrvLVR_SetVDTS(emVDTS vdts)
{
	u8 btmp = (VDTCR & 0xe3) | (vdts << 2);
	VDTCR = 0xC0;
	VDTCR = btmp;
}

/**********************************************************************************
*** 	EOF 									***
**********************************************************************************/
