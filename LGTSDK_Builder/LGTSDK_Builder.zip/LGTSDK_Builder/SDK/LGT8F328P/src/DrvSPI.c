/*********************************************************************************
** 								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                               		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvSPI.c
 * @brief Source File of SPI driver 
 */

/** complier directives */
#define _DRVSPI_SRC_

/**********************************************************************************
***    	MODULES USED								***
**********************************************************************************/ 
#include "allinone.h"

/**********************************************************************************
***     MACRO AND DEFINITIONS
***********************************************************************************/ 
/** Arguments for SPI initialize */

/**********************************************************************************
***     EXPORTED FUNCTIONS
**********************************************************************************/ 
/**
 * @fn void DrvSPI_Init(void)
 */
void DrvSPI_Init(void)
{

#if (MMCU_PACKAGE == MMCU_SSOP20L)
	// switch SPSS to PB1
	u8 btmp = PMX0 | 0x04;
	PMX0 = 0x80;
	PMX0 = btmp;

	// SCK,MISO,MOSI,SS = PB[5,4,3,1]
	if(SPI_SPIM == E_SPI_MASTER) {
		// SS = 1
		PORTB = (PORTB & 0xc5) | 0x2;
		// SCK,MISO,MOSI,SS = O,I,O,O
		DDRB = (DDRB & 0xc5) | 0x2a; 
	} else {
		PORTB = (PORTB & 0xc5);
		// SCK,MISO,MOSI,SS = I,O,I,I
		DDRB = (DDRB & 0xc5) | 0x10; 
	}
#else
	// SCK,MISO,MOSI,SS = PB[5,4,3,2]
	if(SPI_SPIM == E_SPI_MASTER) {
		// SS = 1
		PORTB = (PORTB & 0xc3) | 0x4;
		// SCK,MISO,MOSI,SS = O,I,O,O
		DDRB = (DDRB & 0xc3) | 0x2c; 
	} else {
		PORTB = (PORTB & 0xc3);
		// SCK,MISO,MOSI,SS = I,O,I,I
		DDRB = (DDRB & 0xc3) | 0x10; 
	}
#endif

	SPCR = (SPI_SPIIEN << SPIE) | (SPI_SPIDORD << DORD) | (SPI_SPITYPE << CPHA) | \
			(SPI_SPIM << MSTR) | ((SPI_SPICLK & 0x3) << SPR0);
	
	SPSR = (SPI_SPICLK >> 2) & 1;
	
	// enable spi
	SPCR |= (1 << SPE);
}

u8 DrvSPI_transferByte(u8 data)
{
	u8 rxdd;

	SPDR = data;
	while((SPFR & (1 << RDEMPT)));
	rxdd = SPDR;
	SPFR = _BV(RDEMPT) | _BV(WREMPT);

	return rxdd;
}

u16 DrvSPI_transferWord(u16 data)
{
	union { u16 val; struct { u8 lsb; u8 msb; }; } din, dout;
	
	din.val = data;
	if(!(SPCR & (1 << DORD))) {
		SPDR = din.msb;
 		while ((SPFR & _BV(RDEMPT)));
 		dout.msb = SPDR;
 		SPFR = _BV(RDEMPT) | _BV(WREMPT);

		SPDR = din.lsb;
 		while ((SPFR & _BV(RDEMPT)));
 		dout.lsb = SPDR;
 		SPFR = _BV(RDEMPT) | _BV(WREMPT);
 	} else {
 		SPDR = din.lsb;
 		while ((SPFR & _BV(RDEMPT)));
		dout.lsb = SPDR;
		SPFR = _BV(RDEMPT) | _BV(WREMPT);

		SPDR = din.msb;
		while ((SPFR & _BV(RDEMPT)));
		dout.msb = SPDR;
		SPFR = _BV(RDEMPT) | _BV(WREMPT);
 	}

	return dout.val;
}

/**
 * @fn void DrvSPI_Exchange(u8 *src, u8 length)
 */
void DrvSPI_transferBuffer(u8 *src, u8 length)
{
	if (length == 0) return;

	u8 *p = (u8 *)src;
	SPDR = *p;
	while (--length > 0) {
		u8 out = *(p + 1);
		while ((SPFR & _BV(RDEMPT)));
		u8 in = SPDR;
		SPFR = _BV(RDEMPT) | _BV(WREMPT);
		SPDR = out;
		*p++ = in;
 	}
	
	while ((SPFR & _BV(RDEMPT)));
	*p = SPDR;
	SPFR = _BV(RDEMPT) | _BV(WREMPT);
}

/**********************************************************************************
*** EOF										***
***********************************************************************************/ 
