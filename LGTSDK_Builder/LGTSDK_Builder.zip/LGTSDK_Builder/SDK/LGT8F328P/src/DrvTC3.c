/*********************************************************************************
** 								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                               		**
**                                                                    		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvTC3.c
 * @brief Source File of TC1 driver 
 */

/** complier directives */
#define _DRVTC3_SRC_

/**********************************************************************************
***     MODULES USED								***
**********************************************************************************/ 
#include "allinone.h"
	
#if (TC3_CS3 == 0)
#warning <E0:Timer/Counter 3> No clock source selected for Timer 3
#endif	

#if (TC3_COM3A == 0) && (TC3_OC3AEN == 1)
#warning <W1:Timer/Counter 3> Compare(A) mode should be selected for PWM output
#endif

#if (TC3_COM3B == 0) && (TC3_OC3BEN == 1)
#warning <W1:Timer/Counter 3> Compare(B) mode should be selected for PWM output
#endif

#if ((TC3_WGM3 == 0) || (TC3_WGM3 == 4)) && ((TC3_COM3A == 2) || (TC3_COM3A == 3))
	#if (TC3_OC3AEN == 1)
	#warning <W1:Timer/Counter 3> OC3A will not output PWM with current WGM configuration
	#endif
#endif

#if ((TC3_WGM3 == 0) || (TC3_WGM3 == 4)) && ((TC3_COM3B == 2) || (TC3_COM3B == 3))
	#if (TC3_OC3AEN == 1)
	#warning <W1:Timer/Counter 3> OC3B will not output PWM with current WGM configuration 
	#endif
#endif

#if ((TC3_WGM3 == 0) || (TC3_WGM3 == 4)) && ((TC3_OC3AEN == 1) || (TC3_OC3BEN == 1))
#warning <W1:Timer/Counter 3> only 50% duty ratio PWM supported by selected mode
#endif

#if ((TC3_WGM3 == 4) ||(TC3_WGM3 == 9) || (TC3_WGM3 == 0xb) || (TC3_WGM3 == 0xf))
	#if (TC3_OC3AEN == 1) && (TC3_COM3A == 1)
	#warning <W1:Timer/Counter 3> OC3A PWM only support 50% duty ratio with selected compare mode
	#endif
	#if (TC3_COM3A != 1) && (TC3_OC3AEN == 1)
	#warning <W1:Timer/Counter 3> OC3A will not output PWM with selected compare mode
	#endif
	#if (TC3_OCR3B > TC3_OCR3A)
	#warning <E0:Timer/Counter 3> OCR3A should be set more smaller than OCR3A in selected mode
	#endif
#endif

#if ((TC3_WGM3 == 8) || (TC3_WGM3 == 0xa) || (TC3_WGM3 == 0xc) || (TC3_WGM3 == 0xe))
	#if (TC3_ICR3 == 0)
	#warning <W0:Timer/Counter 3> ICR3 should be enable for selected mode
	#endif
	#if (TC3_OCR3A > TC3_ICR3) || (TC3_OCR3B > TC3_ICR3)
	#warning <E0:Timer/Counter 3> OCR3A/OCR3B should be set smaller than ICR3 in selected mode
	#endif
#endif

#if ((TC3_WGM3 == 5) || (TC3_WGM3 == 6) || (TC3_WGM3 == 7) || (TC3_WGM3 == 0xe))
	#if (TC3_OC3AEN == 1) && (TC3_COM3A == 1)
	#warning <W0:Timer/Counter 3> OC3A will not output PWM in selected configuration
	#endif
	#if (TC3_OC3BEN == 1) && (TC3_COM3B == 1)
	#warning <W0:Timer/Counter 3> OC3B will not output PWM in selected configuration
	#endif
#endif

#if (TC3_WGM3 == 0xf) && (TC3_OC3BEN == 1)
#warning <W1:Timer/Counter 3> OC3B will not output PWM in select configuration
#endif

#if ((TC3_WGM3 == 1) || (TC3_WGM3 == 2) || (TC3_WGM3 == 3) || (TC3_WGM3 == 8) || (TC3_WGM3 == 0xa))
	#if ((TC3_OC3AEN == 1) && (TC3_COM3A == 1))
	#warning <W0:Timer/Counter 3> OC3A will not output PWM in selected configuration
	#endif
	#if ((TC3_OC3BEN == 1) && (TC3_COM3B == 1))
	#warning <W0:Timer/Counter 3> OC3B will not output PWM in selected configuration
	#endif
#endif

#if ((TC3_WGM3 == 0xb) || (TC3_WGM3 == 9)) && (TC3_OC3BEN ==1)
	#if (TC3_COM3B == 1)
	#warning <W1:Timer/Counter 3> OC3B will not output PWM in select configuration
	#endif
#endif

#if (TC3_COM3A != 0) && (TC3_OCR3A == 0)
	#warning <W1:Timer/Counter 3> Please confirm OCR3A is given properly.
#endif

#if (TC3_COM3B != 0) && (TC3_OCR3B == 0)
	#warning <W1:Timer/Counter 3> Please confirm OCR3B is given properly.
#endif

#if (MMCU_PACKAGE != MMCU_QFP48L)
#undef	TC3_OC3CEN
#undef	TC3_OCF3CEN
#undef 	TC3_COM3C

#define	TC3_OC3CEN	0
#define	TC3_OCF3CEN	0
#define	TC3_COM3C	0
#endif

/**********************************************************************************
***   	 MACROS AND DEFINITIONS							***
**********************************************************************************/ 
/* Arguments for TC3 initialize */

static u8 _tccr3b = 0;
/**********************************************************************************
***	PROTOTYPE OF LOCAL FUNCTIONS						***
**********************************************************************************/

/**********************************************************************************
***  	EXPORTED FUNCTIONS							*** 
**********************************************************************************/
/**
 * @fn void DrvTC3_Init(void)
 * @brief Initialize TC3 and run. \n
 *	The arguments of this function are macros (TC3_CS3,TC3_WGM3,TC3_COM3A,TC3_COM3B, \n
 *	TC3_OCR3A,TC3_OCR3B,TC3_TCNT3,TC3_ICR3,TC3_OC3AEN,TC3_OCR3BEna). Before calling  \n
 *	you should give the correct value to shese macros according your application
 */
void DrvTC3_Init(void)
{
	// u8reg is used for storing value of SREG
	u8 u8reg;
		
	/** 1. Stop timer */
	TCCR3B = 0x0;

	/** 2. Force compare match: OC = 1*/
	// The setup of the OC1x should be performed before setting 
	// the Data Direction Register for the port pin to output
	// set OC1x before DDR_OC1x is set
	TCCR3A = (E_COM3_CSET << COM3A0) | (E_COM3_CSET << COM3B0);
	// force compare match
	TCCR3C = 0xc0;

	/** 3. Set PIN OC3x's direction */
#if (TC3_OC3AEN == 1)
	#if (TC3_C3AAC == 1) 
		u8reg = PMX1 | 0x4;
		PMX0 = 0x80;
		PMX1 = u8reg;
	#else	
		DDRF |= (1 << PF1);
	#endif
#endif
		
#if (TC3_OC3BEN == 1) || (TC3_OC3CEN == 1)
	DDRF |= (TC3_OC3BEN << PF2) | (TC3_OC3CEN << PF3);
#endif

	/** 4. Disalble Global Interrupt */
	u8reg = SREG;
	CLI();
	
	/** 5. Initiate TCNT3 */
	TCNT3H = (TC3_TCNT3 >> 8) & 0xff;
	TCNT3L = TC3_TCNT3 & 0xff;
	
	/** 6. Initiate (OCR1A & OCR1B)output compare register */
	OCR3AH = (TC3_OCR3A >> 8) & 0xff;
	OCR3AL = TC3_OCR3A & 0xff;
	OCR3BH = (TC3_OCR3B >> 8) & 0xff;
	OCR3BL = TC3_OCR3B & 0xff;
#if (MMCU_PACKAGE == MMCU_QFP48L)
	OCR3CH = (TC3_OCR3C >> 8) & 0xff;
	OCR3CL = TC3_OCR3C & 0xff;
#endif
	ICR3H = (TC3_ICR3 >> 8) & 0xff;
	ICR3L = TC3_ICR3 & 0xff;

	/** 7. Restore SREG  */
	SREG = u8reg;

	/** 8. Config Interrupt if OCF3A, OCR3B, TOV3 or ICP3 is enabled */
#if ((TC3_TOV3EN == TRUE) || (TC3_OCF3AEN == TRUE) || (TC3_OCF3CEN == TRUE) || \
		(TC3_OCF3BEN == TRUE) || (TC3_ICP3EN == TRUE))
	// Clear interrupt flag
	TIFR3 = 0x2f;
	TIMSK3 = (TC3_TOV3EN << TOV3) | (TC3_OCF3AEN << OCF3A) | (TC3_OCF3CEN << OCF3C) |\
				(TC3_OCF3BEN << OCF3B) | (TC3_ICP3EN << ICF3);
#endif
	
	/** 9. Initiate TCCR3A and TCCR3B */
	TCCR3A = (TC3_COM3A << COM3A0) | (TC3_COM3B << COM3B0) | (TC3_COM3C << COM3C0) |\
			((TC3_WGM3 & 0x3) << WGM30);
	TCCR3B = TC3_CS3 | (((TC3_WGM3 & 0xc) >> 2) << WGM32) | (TC3_ICNC3 << ICNC3) | (TC3_ICES3 << ICES3);
}

void DrvTC3_Stop(void)
{
	_tccr3b = TCCR3B;
	TCCR3B = 0x0;
}

void DrvTC3_Restart(void)
{
	TCCR3B = _tccr3b;
}

u16 DrvTC3_GetCNT(void)
{
	u16 u16Tmp = 0;

	DrvMISC_CLRI();
	u16Tmp = _tc3_GetCNT();
	DrvMISC_RESI();

	return u16Tmp;
}

u16 DrvTC3_GetOCA(void)
{
	u16 u16Tmp = 0;

	DrvMISC_CLRI();
	u16Tmp = _tc3_GetOCA();
	DrvMISC_RESI();

	return u16Tmp;
}

u16 DrvTC3_GetOCB(void)
{
	u16 u16Tmp = 0;

	DrvMISC_CLRI();
	u16Tmp = _tc3_GetOCB();
	DrvMISC_RESI();

	return u16Tmp;
}

u16 DrvTC3_GetOCC(void)
{
	u16 u16Tmp = 0;

	DrvMISC_CLRI();
	u16Tmp = _tc3_GetOCC();
	DrvMISC_RESI();

	return u16Tmp;
}

u16 DrvTC3_GetICR(void)
{
	u16 u16Tmp = 0;

	DrvMISC_CLRI();
	u16Tmp = _tc3_GetICR();
	DrvMISC_RESI();

	return u16Tmp;
}

/**********************************************************************************
*** 	EOF 									***
**********************************************************************************/
