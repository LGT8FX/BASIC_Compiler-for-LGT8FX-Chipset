/*********************************************************************************
** 								   		**
** Copyright (c) 2013, 	Logic Green Technologies				**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2013
Revised by 	: LGT Software Group
Description : Original version.
*/


/** complier directives */
#define _DRVPWR_SRC_C_

/**********************************************************************************
***	MODULES USED								***
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***     MACRO AND DEFINITIONS							***
**********************************************************************************/  
#define	PWR_IOCD (PWR_IOCD7 << 7)|(PWR_IOCD6 << 6)|(PWR_IOCD5 << 5)|(PWR_IOCD4 << 4)|\
		(PWR_IOCD3 << 3)|(PWR_IOCD2 << 2)|(PWR_IOCD1 << 1)|PWR_IOCD0;

/**********************************************************************************
***	EXPORTED FUNCTIONS							***
**********************************************************************************/  
void DrvPWR_Init(void)
{
	// Set power/off lock
	DRVPWR_LOCK();
}

/**
 * @fn void DrvPWR_Sleep()
 */
void DrvPWR_Sleep(EMSMODE mode)
{
	u8 CLKPR_reg = CLKPR;
	u8 LDOCR_reg = LDOCR;
	u8 MCUSR_reg = MCUSR | 0x7f;
	u8 SREG_reg = SREG;

	// global interrupt disable
	CLI();

#if PWR_SWDD == 1
	// disable SWD interface to release PE0/2
	MCUSR = 0xff;
	MCUSR = 0xff;
#endif

#if PWR_DPS2EN == 1
	DRVPWR_IOCD(PWR_IOCD);
	DRVPWR_EnableDPS2();
#endif

#if PWR_CLKPR == 1
	// minimize system power before LDO power/down
	CLKPR = 0x80;
	CLKPR = 0x08;
#endif

	//NOP(); NOP(); NOP(); NOP();
#if PWR_LDOPD == 1
	LDOCR = 0x80;
	LDOCR = 0x02; // LDO power/down
#endif

	//NOP(); NOP(); NOP(); NOP();	
	// bring system to sleep
	SMCR = ((mode & 0x7) << 1) | 0x1; 	
	SLEEP();

	NOP(); NOP(); // NOP(); NOP();

#if PWR_LDOPD == 1
	// restore LDO settings
	LDOCR = 0x80;
	LDOCR = LDOCR_reg;
#endif
	NOP(); NOP(); NOP(); NOP();

#if PWR_CLKPR == 1
	// restore system clock prescaler
	CLKPR = 0x80;
	CLKPR = CLKPR_reg;
#endif
	// restore SWD/SWC interface
	MCUSR = 0x80;
	MCUSR = MCUSR_reg;

	// restore interrupt settings
	SREG = SREG_reg;
}

/**********************************************************************************
*** 	EOF 									***
**********************************************************************************/  
