/*********************************************************************************
** 										**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                    	**
**                                                                         	**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvDAC.c
 * @brief Source File of AC
 */

/** complier directives */
#define _DRVDAC_SRC_

/**********************************************************************************
***     MODULES USED								***
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***  MACROS AND DEFINITIONS							***
**********************************************************************************/ 

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
/**
 * @fn void DrvDAC_Init(void)
 * @brief Initialize DAC.
 */
void DrvDAC_Init(void)
{
	// set DAC's output level
	DALR = DAC_DALR & 0xff;

	// DAC configuration
	DACON = 0x8 | (DAC_DAOE << 2) | (DAC_DAVS & 3);
}

void DrvDAC_SetReference(u8 refs)
{
	u8	btmp = DACON & 0xfc;

	btmp |= (refs & 0x3);
	DACON = btmp;
}


/**********************************************************************************
*** EOF 									***
**********************************************************************************/

