/*********************************************************************************
** 								   		**
** Copyright (c) 2013, 	LogicGreen techologies					**
** All rights reserved.                                               		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

#ifndef _DrvPWR_H_
#define _DrvPWR_H_

/**********************************************************************************
***    	MODULES USED								***
**********************************************************************************/  
#include "global.h"

/**********************************************************************************
***  MACRO AND DEFINTION							***
**********************************************************************************/ 
#define PRR_ADC		0x0001
#define PRR_USART0	0x0002
#define PRR_SPI		0x0004
#define PRR_TIM1	0x0008
#define PRR_TIM0	0x0020
#define PRR_TIM2	0x0040
#define PRR_TWI		0x0080

#define PRR_PCI		0x0200
#define PRR_EFL		0x0400
#define PRR_WDT		0x2000

#ifdef	PRR10
#define PRR10	(*(volatile u16*)0x0064)
#endif

/**********************************************************************************
***    TYPEDEF AND STRUCTURE							***
**********************************************************************************/
/**
 * @enum emSmod
 *	Sleep Mode
 */

/**
 * @typedef typedef enum emSmode EMSMODE
 */
typedef enum emSmod
{
	E_SLEEP_IDLE,			/** IDLE */
	E_SLEEP_ANRM,			/** ADC Noise Reduction mode */
	E_SLEEP_SAVE,			/** SAVE */
	E_SLEEP_DPS1,			/** DPS0 */
	E_SLEEP_DPS0 = 6,		/** DPS1 */
	E_SLEEP_DPS2 = 7		/** DPS2 */
}EMSMODE;

// DPS2 auto-wakeup time (awt)
#define	DPS2_LPRC_OFF		0x0
#define	DPS2_LPRC_128MS		0x4
#define	DPS2_LPRC_256MS		0x5
#define	DPS2_LPRC_512MS		0x6
#define	DPS2_LPRC_1S		0x7

/**********************************************************************************
***     MACRO DEFINITION	
**********************************************************************************/ 
#define DrvPWR_ModuleEnable(ID) do { PRR10 &= ~ID; } while(0)
#define DrvPWR_ModuleDisable(ID) do { PRR10 |= ID; } while(0)

#define DRVPWR_LOCK() do {SMCR = 0x8;} while(0)

#define	DRVPWR_IOCD(pid)	do { IOCWK = pid; } while(0)
#define	DRVPWR_EnableDPS2()	do { DPS2R |= (1 << DPS2E); } while(0)
#define	DRVPWR_DisableDPS2()	do { DPS2R &= ~(1 << DPS2E); } while(0)

#define	DrvPWR_LPRCMode(awt)	do { DPS2R &= 0xf8; DPS2R |= (awt & 0x7); } while(0)

/**********************************************************************************
***    	EXPORTED FUNCTIONS							***
**********************************************************************************/ 
void DrvPWR_Init(void);
void DrvPWR_Sleep(EMSMODE emSMode);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/  
