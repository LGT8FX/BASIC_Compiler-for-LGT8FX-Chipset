/*
**********************************************************************************
**								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvINT.h
 * @brief Header File External Interrupt and PIN Change Interrupt 
 *		
 */

#ifndef _INT_H_
#define _INT_H_

/**********************************************************************************
***      MODULES USED								***
**********************************************************************************/ 

/**********************************************************************************
***      TYPEDEFS AND STRUCTURES						***
**********************************************************************************/
/** 
 * @enum emIsc
 * 	External Interrupt Sense Control
 */
enum emIsc
{
	E_ISC_LOW,		/**< The low level of INTn generates an interrupt request */
	E_ISC_AE,		/**< Any edge of INTn generates asynchronously an interupt */
	E_ISC_FE,		/**< The falling edge of INTn generates asynchronously and 
							interrupt request */
	E_ISC_RE		/**< The rising edge of INTn generates asynchronously and 
							interrupt request */
};

/**********************************************************************************
***   	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _DRVINT_SRC_
#endif

#define PCMSKB	(*(volatile unsigned char *)0x6b)
#define PCMSKC	(*(volatile unsigned char *)0x6c)
#define PCMSKD	(*(volatile unsigned char *)0x6d)
#define PCMSKE	(*(volatile unsigned char *)0x73)
#define PCMSKF	(*(volatile unsigned char *)0x74)

/*
 * ID can be INT[1:0]
 */
#define DrvEXINT_DisableEXINT(ID) do { \
	EIMSK &= ~(1 << ID); \
	} while (0)

/*
 * ID can be INT[1:0]
 */
#define DrvEXINT_EnableEXINT(ID) do { \
	EIMSK |= (1 << ID); \
	} while (0)

/*
 * ID can be PB[7:0], PC[6:0], PD[7:0] or PE[6:0]
 */
#define DrvEXINT_DisablePCINT(PN, ID) do { \
	PCMSK##PN &= ~(1 << ID); \
	} while (0)

/*
 * ID can be PB[7:0], PC[6:0], PD[7:0] or PE[6:0]
 */
#define DrvEXINT_EnablePCINT(PN, ID) do { \
	PCMSK##PN |= (1 << ID); \
	} while (0)
	
/**********************************************************************************
***  	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvEXINT_Init(void);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/
