/*********************************************************************************
** 								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvAC1.h
 * @brief Header File of AC
 *		
 */

#ifndef _AC1_H_
#define _AC1_H_

/**********************************************************************************
***	MACRO AND DEFINITIONS							***
**********************************************************************************/
#define E_C1PS_AC1P		0		/**< AC0P/PD6 is applied to the positive input */
#define E_C1PS_ACXP		1		/**< ACXP/PE1 is applied to the positive input */ 
#define E_C1PS_DAC		2		/**< DAC is applied to the positive input */ 
#define E_C1PS_OFF		3		/**< disable positive input */ 

#define E_C1NS_ACXN		0		/**< ACXN/PD7 is applied to the negetive input */
#define E_C1NS_AC1N		1		/**< AC1N/PE3 is applied to the negetive input */
#define E_C1NS_V5D1		2		/**< 1/5 VDS is applied to the negetive input */
#define E_C1NS_DAP		3		/**< disable negetive input */

/**********************************************************************************
***	TYPEDEFS AND STRUCTURES							***
**********************************************************************************/
/**
 * @enum emAcis
 *	AC Interrupt Mode Select 
 */
enum emAC1IS
{
	E_C1IS_AE,				/**< Any edge of ACO generates an interrupt */
	E_C1IS_REV,				/**< Reserved */
	E_C1IS_FE,				/**< Falling edge of ACO generates an interrupt */
	E_C1IS_RE				/**< Rising edge of ACO generates an interrupt */
};

/**********************************************************************************
***	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _AC1_SRC_
#endif

#define DrvAC1_Stop() C1SR |= 0x80
#define DrvAC1_Start() C1SR &= 0x7f

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvAC1_Init(void);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/
