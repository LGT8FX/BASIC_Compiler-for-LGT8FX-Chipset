/*
**********************************************************************************
**								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvTC2.h
 * @brief Header File of TC2 driver 
 *		
 */

#ifndef _TC2_H_
#define _TC2_H_

/**********************************************************************************
***   	MODULES USED								***
**********************************************************************************/ 

/**********************************************************************************
***     TYPEDEFS AND STRUCTURES							***
**********************************************************************************/
/**
 * @enum emCS2
 *  the description of TC2's Clock Select
 */
enum emCS2
{
	E_CS2_NO = 0x0,		/**< no clock source */
	E_CS2_DIV1,			/**< system clock */
	E_CS2_DIV8,			/**< clk/8, from prescaler */
	E_CS2_DIV32,		/**< clk/32, from prescaler */
	E_CS2_DIV64,		/**< clk/64, from prescaler */
	E_CS2_DIV128,		/**< clk/128, from prescaler */
	E_CS2_DIV256,		/**< clk/256, from prescaler */
	E_CS2_DIV1024,		/**< clk/1024, from prescaler */
};

/**
 * @enum emWgm2
 *	the description of TC2's operation mode 
 */
enum emWgm2
{
	E_WGM2_NORM = 0x0, 		/**< normal mode */
	E_WGM2_PCPWM, 			/**< Phase Correct PWM mode, TOP = 0xff */
	E_WGM2_CTC,				/**< Clear Timer on Compare Match mode */   
	E_WGM2_FPWM,			/**< Fast PWM mode TOP = 0xff */
	E_WGM2_PCPWM_O = 0x5,	/**< Phase Correct PWM mode TOP = OCR0 */
	E_WGM2_FPWM_O = 0x7		/**< Fast PWM mode TOP = OCR0 */
};

/**
 * @enum emCom2Nopwm 
 *	Compare Output mode, non-PWM mode,
 *	Use these enumeration type when WGM2 = NORM or CTC 
 */
enum emCom2Nopwm
{
	E_COM2_NDIS = 0x0,	/**< disable OC */
	E_COM2_CTOG,		/**< toggle on compare match */
	E_COM2_CCLR,		/**< clear on comapre match */
	E_COM2_CSET			/**< set on compare match */
};

/**
 * @enum emCom0Fpwm 
 *	Compare Output mode, FPWM mode,
 *	Use these enumeration type when WGM2 = FPWM 
 */
enum emCom2Fpwm
{
	E_COM2_FDIS = 0x0,	/**< disable OC */
	E_COM2_FTOG,		/**< when WGM2[2] = 1: toggle on compare match */
	E_COM2_CCLR_MSET,	/**< clear on compare match, set on maximum  */
	E_COM2_CSET_MCLR	/**< set on compare match, clear on maximum */
};

/**
 * @enum emCom2Pcpwm 
 *	Compare Output mode, PCPWM mode,
 *	Use these enumeration type when WGM2 = PCPWM
 */
enum emCom2Pcpwm
{
	E_COM2_PDIS = 0x0,	/**< disable OC */
	E_COM2_PTOG,		/**< when WGM0[2] = 1: toggle on compare match */
	E_COM2_UCLR_DSET,   /**< clear on compare match when up-counting, set on compare
							* match when down-counting */
	E_COM2_USET_DCLR,	/**< set on compare match when up-counting, clear on compare
							* match when down-counting */
};

/** Timer/Counter 1 mode */
typedef enum
{
	E_TC2_SYNC,			/** synchronous mode */
	E_TC2_ASYNC			/** asynchronous mode */
}ENUM_TC2_MODE;

/**********************************************************************************
***					          	MACRO AND DEFINITIONS							***													  	
**********************************************************************************/
#define TC2_INTRE_MSK			((1 << OCIE2A) | (1 << OCIE2B) | (1 << TOIE2))
#define TC2_ASSR_DTE(bitmask)		while(ASSR & bitmask)

/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _DRVTC2_SRC_
#endif

#define DrvTC2_SetCNT(value)	TCNT2 = value
#define DrvTC2_SetOCA(value)	OCR2A = value
#define DrvTC2_SetOCB(value)	OCR2B = value
#define DrvTC2_GetOCA()		(OCR2A)
#define DrvTC2_GetOCB()		(OCR2B)
#define DrvTC2_GetCNT()		(TCNT2)

#define DrvTC2_SetPrescaler(value) do { \
	TCCR2B = (TCCR2B & ~0x7) | value; \
} while (0)

	
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvTC2_Init(void);
void DrvTC2_Stop(void);
void DrvTC2_Restart(void);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/

