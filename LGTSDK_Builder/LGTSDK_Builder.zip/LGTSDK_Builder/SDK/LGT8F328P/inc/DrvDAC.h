/*********************************************************************************
** 								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvDAC.h
 * @brief Header File of DAC
 *		
 */

#ifndef _DAC_H_
#define _DAC_H_

/**********************************************************************************
***	MACRO AND DEFINITIONS							***
**********************************************************************************/
#define DAC_REFS_VCC		0	
#define DAC_REFS_AVREF		1
#define DAC_REFS_IVREF		2
#define DAC_REFS_OFF		3

/**********************************************************************************
***	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _DAC_SRC_
#endif

#define DrvDAC_Enable()			DACON |= 0x8
#define DrvDAC_Disable()		DACON &= 0xf7

#define	DrvDAC_EnableOutput2IO() 	DACON |= 0x4
#define	DrvDAC_DisableOutput2IO()	DACON &= 0xfb

#define DrvDAC_SetLevel(level)		DALR = level

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvDAC_Init(void);
void DrvDAC_SetReference(u8);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/
