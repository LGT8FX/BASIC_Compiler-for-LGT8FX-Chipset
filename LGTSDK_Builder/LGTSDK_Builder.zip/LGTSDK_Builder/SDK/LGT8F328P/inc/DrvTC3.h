/*********************************************************************************
** 								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvTC3.h
 * @brief Header File of TC3 driver 
 *		
 */

#ifndef _TIMMER3_H_
#define _TIMMER3_H_

/**********************************************************************************
***     TYPEDEFS AND STRUCTURES							***
**********************************************************************************/
/**
 * @enum emCS3
 *  the description of TC3's Clock Select
 */
enum emCS3
{
	E_CS3_NO = 0x0,		/**< no clock source */
	E_CS3_DIV1,			/**< system clock */
	E_CS3_DIV8,			/**< clk/8, from prescaler */
	E_CS3_DIV64,		/**< clk/64, from prescaler */
	E_CS3_DIV256,		/**< clk/256, from prescaler */
	E_CS3_DIV1024,		/**< clk/1024, from prescaler */
	E_CS3_T1F,			/**< external clock source from PIN T1, Clock on falling edge */
	E_CS3_T1R			/**< external clock source from PIN T1, Clock on rising edge */
};

/**
 * @enum emWgm3
 *	the description of TC3's operation mode 
 */
enum emWgm3
{
	E_WGM3_NORM = 0x0, 		/**< normal mode */
	E_WGM3_PCPWM_8B, 		/**< Phase Correct PWM mode, TOP = 0xff */
	E_WGM3_PCPWM_9B, 		/**< Phase Correct PWM mode, TOP = 0x1ff */
	E_WGM3_PCPWM_10B, 		/**< Phase Correct PWM mode, TOP = 0x3ff */
	E_WGM3_CTC_O,			/**< Clear Timer on Compare Match mode TOP = OCR1A */   
	E_WGM3_FPWM_8B,			/**< Fast PWM mode TOP = 0xff */
	E_WGM3_FPWM_9B,			/**< Fast PWM mode TOP = 0x1ff */
	E_WGM3_FPWM_10B,		/**< Fast PWM mode TOP = 0x3ff */
	E_WGM3_PFCPWM_I,		/**< Phase and Frequency Correct PWM Mode TOP = ICR1 */
	E_WGM3_PFCPWM_O,		/**< Phase and Frequency Correct PWM Mode TOP = OCR1A */
	E_WGM3_PCPWM_I,			/**< Phase Correct PWM Mode TOP = ICR1 */
	E_WGM3_PCPWM_O,			/**< Phase Correct PWM mode TOP = OCR1A */
	E_WGM3_CTC_I,			/**< Clear Timer on Compare Match mode Top = ICR1 */
	E_WGM3_FPWM_I = 14,		/**< Fast PWM mode TOP = ICR1 */
	E_WGM3_FPWM_O			/**< Fast PWM mode TOP = OCR1A */
};

/**
 * @enum emCom3Nopwm 
 *	Compare Output mode, non-PWM mode,
 *	Use these enumeration type when WGM3 = NORM or CTC 
 */
enum emCom3Nopwm
{
	E_COM3_NDIS = 0x0,	/**< disable OC */
	E_COM3_CTOG,		/**< toggle on compare match */
	E_COM3_CCLR,		/**< clear on comapre match */
	E_COM3_CSET			/**< set on compare match */
};

/**
 * @enum emCom3Fpwm 
 *	Compare Output mode, FPWM mode,
 *	Use these enumeration type when WGM3 = FPWM 
 */
enum emCom3Fpwm
{
	E_COM3_FDIS = 0x0,	/**< disable OC */
	E_COM3_FTOG,		/**< when WGM3[3] = 1: toggle on compare match */
	E_COM3_CCLR_MSET,	/**< clear on compare match, set on maximum  */
	E_COM3_CSET_MCLR	/**< set on compare match, clear on maximum */
};

/**
 * @enum emCom3Pcpwm 
 *	Compare Output mode, PCPWM mode,
 *	Use these enumeration type when WGM1 = PCPWM or PFCPWM
 */
enum emCom3Pcpwm
{
	E_COM3_PDIS = 0x0,	/**< disable OC */
	E_COM3_PTOG,		/**< when WGM1[3] = 1: toggle on compare match */
	E_COM3_UCLR_DSET,   /**< clear on compare match when up-counting, set on compare
							* match when down-counting */
	E_COM3_USET_DCLR	/**< set on compare match when up-counting, clear on compare
							* match when down-counting */
};

/**
 * @enum emIcnc3
 *	Input Capture Noise Canceler
 */
enum emIcnc3
{
	E_ICNC3_ENA = 0x0,	/**< Activates the Input Capture Noise Canceler */
	E_ICNC3_DIS			/**< Disable the Input Capture Noise Canceler */
};

/**
 * @enum emIces3
 *	Input Capture Edge Select
 */
enum emIces3
{
	E_ICES3_FE = 0x0,	/**< A falling edge is used as trigger */
	E_ICES3_RE			/**< A rising edge is used as trigger */
};

/**********************************************************************************
***    	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _DRVTC3_SRC_
#endif

#define DrvTC3_SetCNT(value) do { \
	DrvMISC_CLRI(); \
	TCNT3H = (value >> 8) & 0xff; \
	TCNT3L = (value & 0xff); \
	DrvMISC_RESI(); \
} while(0)

#define DrvTC3_SetOCA(value) do { \
	DrvMISC_CLRI(); \
	OCR3AH = (value >> 8) & 0xff; \
	OCR3AL = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define DrvTC3_SetOCB(value) do { \
	DrvMISC_CLRI(); \
	OCR3BH = (value >> 8) & 0xff; \
	OCR3BL = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define DrvTC3_SetOCC(value) do { \
	DrvMISC_CLRI(); \
	OCR3CH = (value >> 8) & 0xff; \
	OCR3CL = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define DrvTC3_SetICR(value) do { \
	DrvMISC_CLRI(); \
	ICR3H = (value >> 8) & 0xff; \
	ICR3L = (value & 0xff); \
	DrvMISC_RESI(); \
} while (0)

#define _tc3_GetCNT() ((TCNT3H << 8) | TCNT3L)
#define _tc3_GetOCA() ((OCR3AH << 8) | OCR3AL)
#define _tc3_GetOCB() ((OCR3BH << 8) | OCR3BL)
#define _tc3_GetOCC() ((OCR3CH << 8) | OCR3CL)
#define _tc3_GetICR() ((ICR3H << 8) | ICR3L)
	
/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvTC3_Init(void);
void DrvTC3_Stop(void);
void DrvTC3_Restart(void);
u16 DrvTC3_GetCNT(void);
u16 DrvTC3_GetOCA(void);
u16 DrvTC3_GetOCB(void);
u16 DrvTC3_GetICR(void);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/
