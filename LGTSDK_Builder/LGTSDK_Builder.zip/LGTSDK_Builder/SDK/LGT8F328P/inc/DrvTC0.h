/*
**********************************************************************************
**								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                    		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvTC0.h
 * @brief Header File of TC0 driver 
 *		
 */

#ifndef _TC0_H_
#define _TC0_H_

/**********************************************************************************
***      TYPEDEFS AND STRUCTURES						***
**********************************************************************************/
/**
 * @enum emCS0
 *  the description of TC0's Clock Select
 */
enum emCS0
{
	E_CS0_NO = 0x0,		/**< no clock source */
	E_CS0_DIV1,			/**< system clock */
	E_CS0_DIV8,			/**< clk/8, from prescaler */
	E_CS0_DIV64,		/**< clk/64, from prescaler */
	E_CS0_DIV256,		/**< clk/256, from prescaler */
	E_CS0_DIV1024,		/**< clk/1024, from prescaler */
	E_CS0_T0F,			/**< external clock source from PIN T0, Clock on falling edge */
	E_CS0_T0R			/**< external clock source from PIN T0, Clock on rising edge */
};

/**
 * @enum emWgm0
 *	the description of TC0's operation mode 
 */
enum emWgm0
{
	E_WGM0_NORM = 0x0, 		/**< normal mode */
	E_WGM0_PCPWM, 			/**< Phase Correct PWM mode, TOP = 0xff */
	E_WGM0_CTC,				/**< Clear Timer on Compare Match mode */   
	E_WGM0_FPWM,			/**< Fast PWM mode TOP = 0xff */
	E_WGM0_PCPWM_O = 0x5,	/**< Phase Correct PWM mode TOP = OCR0 */
	E_WGM0_FPWM_O = 0x7		/**< Fast PWM mode TOP = OCR0 */
};

/**
 * @enum emCom0Nopwm 
 *	Compare Output mode, non-PWM mode,
 *	Use these enumeration type when WGM0 = NORM or CTC 
 */
enum emCom0Nopwm
{
	E_COM0_NDIS = 0x0,	/**< disable OC */
	E_COM0_CTOG,		/**< toggle on compare match */
	E_COM0_CCLR,		/**< clear on comapre match */
	E_COM0_CSET			/**< set on compare match */
};

/**
 * @enum emCom0Fpwm 
 *	Compare Output mode, FPWM mode,
 *	Use these enumeration type when WGM0 = FPWM 
 */
enum emCom0Fpwm
{
	E_COM0_FDIS = 0x0,	/**< disable OC */
	E_COM0_FTOG,		/**< when WGM0[2] = 1: toggle on compare match */
	E_COM0_CCLR_MSET,	/**< clear on compare match, set on maximum  */
	E_COM0_CSET_MCLR	/**< set on compare match, clear on maximum */
};

/**
 * @enum emCom0Pcpwm 
 *	Compare Output mode, PCPWM mode,
 *	Use these enumeration type when WGM0 = PCPWM
 */
enum emCom0Pcpwm
{
	E_COM0_PDIS = 0x0,	/**< disable OC */
	E_COM0_PTOG,		/**< when WGM0[2] = 1: toggle on compare match */
	E_COM0_UCLR_DSET,   /**< clear on compare match when up-counting, set on compare
							* match when down-counting */
	E_COM0_USET_DCLR,	/**< set on compare match when up-counting, clear on compare
							* match when down-counting */
};

/**********************************************************************************
***    	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _DRVTC0_SRC_
#endif

#define DrvTC0_SetCNT(value)	TCNT0 = value
#define DrvTC0_SetOCA(value)	OCR0A = value
#define DrvTC0_SetOCB(value)	OCR0B = value
#define DrvTC0_GetOCA()		(OCR0A)
#define DrvTC0_GetOCB()		(OCR0B)
#define DrvTC0_GetCNT()		(TCNT0)

#define DrvTC0_SetPrescaler(value) do { \
	TCCR0B = (TCCR0B & ~0x7) | value; \
} while (0)

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvTC0_Init(void);
void DrvTC0_Stop(void);
void DrvTC0_Restart(void);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/

