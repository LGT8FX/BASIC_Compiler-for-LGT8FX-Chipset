/**********************************************************************************
**								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvLVR.h
 * @brief Header File of LVR
 *		
 */

#ifndef _LVR_H_
#define _LVR_H_

/**********************************************************************************
***	TYPEDEFS AND STRUCTURES							***
**********************************************************************************/
/**
 * @enum emWclk
 * 	WatchDog Clock source
 */
typedef enum _VDTS
{
	E_LVR_V1D8,	/**< VDTS = 1.8V */
	E_LVR_V2D2,	/**< VDTS = 2.2V */
	E_LVR_V2D5,	/**< VDTS = 2.5V */
	E_LVR_V2D9,	/**< VDTS = 2.9V */
	E_LVR_V3D2,	/**< VDTS = 3.2V */
	E_LVR_V3D6,	/**< VDTS = 3.6V */
	E_LVR_V4D0,	/**< VDTS = 4.0V */
	E_LVR_V4D4	/**< VDTS = 4.4V */
} emVDTS;


/**********************************************************************************
***    	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _DRVLVR_SRC_
#endif
	
/**********************************************************************************
***  	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvLVR_Init(void);
void DrvLVR_Enable(void);
void DrvLVR_Disable(void);
void DrvLVR_SetVDTS(emVDTS vdts);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/
