/*********************************************************************************
** 								   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD			**
** All rights reserved.                                                		**
**                                                                     		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvAC0.h
 * @brief Header File of AC
 *		
 */

#ifndef _AC0_H_
#define _AC0_H_

/**********************************************************************************
***	MACRO AND DEFINITIONS							***
**********************************************************************************/
#define E_C0PS_AC0P		0		/**< AC0P/PD6 is applied to the positive input */
#define E_C0PS_ACXP		1		/**< ACXP/PE1 is applied to the positive input */ 
#define E_C0PS_DAC		2		/**< DAC is applied to the positive input */ 
#define E_C0PS_OFF		3		/**< disable positive input */ 

#define E_C0NS_ACXN		0		/**< ACXN/PD7 is applied to the negetive input */
#define E_C0NS_ADMX		1		/**< ADC/MUX is applied to the negetive input */
#define E_C0NS_DAP		2		/**< DAP/OUT is applied to the negetive input */
#define E_C0NS_OFF		3		/**< disable negetive input */

/**********************************************************************************
***	TYPEDEFS AND STRUCTURES							***
**********************************************************************************/
/**
 * @enum emAcis
 *	AC Interrupt Mode Select 
 */
enum emAC0IS
{
	E_C0IS_AE,				/**< Any edge of ACO generates an interrupt */
	E_C0IS_REV,				/**< Reserved */
	E_C0IS_FE,				/**< Falling edge of ACO generates an interrupt */
	E_C0IS_RE				/**< Rising edge of ACO generates an interrupt */
};

/**********************************************************************************
***	EXPORTED VARIABLES							***
**********************************************************************************/
#ifndef _AC0_SRC_
#endif

#define DrvAC0_Stop() C0SR |= 0x80
#define DrvAC0_Start() C0SR &= 0x7f

/**********************************************************************************
*** 	EXPORTED FUNCTIONS							***
**********************************************************************************/
void DrvAC0_Init(void);

#endif
/**********************************************************************************
***	EOF									***
**********************************************************************************/
