/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvSPI.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvSPI.c
 * @brief Source File of SPI driver 
 */

/** complier directives */
#define _DRVSPI_SRC_

/**********************************************************************************
***					            	MODULES USED								***													  	
**********************************************************************************/ 
#include "allinone.h"

/**********************************************************************************
***					            MACRO AND DEFINITIONS							***													  	
**********************************************************************************/ 
/** Arguments for SPI initialize */

/**********************************************************************************
***					              EXPORTED FUNCTIONS							***													  	
**********************************************************************************/ 
/**
 * @fn void DrvSPI_Init(void)
 */
void DrvSPI_Init(void)
{
	// SCK,MISO,MOSI,SS = PB[5,4,3,2]
	if(SPI_SPIM == E_SPI_MASTER)
	{
		// SS = 1
		PORTB = (PORTB & 0xc3) | 0x4;
		// SCK,MISO,MOSI,SS = O,I,O,O
		DDRB = (DDRB & 0xc3) | 0x2c; 
	}
	else
	{
		PORTB = (PORTB & 0xc3);
		// SCK,MISO,MOSI,SS = O,I,O,O
		DDRB = (DDRB & 0xc3) | 0x10; 
	}
	//
	SPCR = (SPI_SPIIEN << SPIE) | (SPI_SPIDORD << DORD) | (SPI_SPITYPE << CPHA) | \
			(SPI_SPIM << MSTR) | ((SPI_SPICLK & 0x3) << SPR0);
	// 
	SPSR = (SPI_SPICLK >> 2) & 1;
	//
	SPCR |= (1 << SPE);
}

/**
 * @fn void DrvSPI_Exchange(u8 u8Len, u8 *pu8Buf)
 */
void DrvSPI_Transceive(u8 u8Len, u8 *pu8Buf)
{
	while(u8Len > 0)
	{
		// write data into SPDR
		DrvSPI_SendByte(*pu8Buf);

		// read SPSR to check that if interrupt flag is set
		while(!(DrvSPI_IsDataReady())); 
		//
		*pu8Buf++ = DrvSPI_GetByte();
		// 
		//DrvMISC_Delayus(20);

		u8Len--;
	}
}

/**********************************************************************************
***					            		EOF										***													  	
**********************************************************************************/ 

