/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : LGT8F88ABSPPrj											    	**
** filename : DrvTWI.c	  														**
** version  : 1.0 													   			**
** date     : April 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	Logic Green Technologies								**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2013
Revised by 	: LGT Software Group
Description : Original version.
*/


/**
 *	@file DrvTWI.c
 *	@brief source file of TWI driver 
 */

/** complier directives */
#define _DrvTWI_SRC_C_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "compiler.h"

#include "DrvTWI.h"
#include "mcommon.h"
#include "mmacros.h"

/**********************************************************************************
***					            MACROS AND DEFINITIONS							***													  	
**********************************************************************************/ 
/* Arguments for TWI Initialize */
/** macro for TWI Mode */
#define argTWIMode		TWI_MODE_MASTER			
/** macro for TWI Bit Rate */
#define argTWBR			16
/** macro for TWI Prescaler */
#define argTWPS			E_TWPS_1
/** macro for TWI Device Address: Bit 0 is global Call Enable */
#define argTWIAddr		0x20
/** macro for TWI Device Address mask */
#define argTWIAMask		0x08

/* Arguments for TWI Interrupt */
/** macro for TWI Interrupt Enable */
#define argTWINTEna		TRUE	

/**********************************************************************************
***					            EXPORTED VARIABLES								***													  	
**********************************************************************************/ 
/* TWI state and address*/
volatile enum emTWIState	g_u8TWIState; 
u8 							g_u8TWIDevAddrRW; 
/* data buffer */
/** Data Buffer for TWI Transfer: Data[0] = Internal Address */
u8 							g_bfu8TWIData[TRANS_DATA_LEN + 1];
u8 							g_u8TWIDataLength; 


/**********************************************************************************
***					            LOCAL VARIABLES									***													  	
**********************************************************************************/ 
static u8 					s_u8TWIDataIndex;
/**********************************************************************************
***					       	PROTOTYPE OF LOCAL FUNCTIONS						***													  	
**********************************************************************************/ 
//static void DrvTWI_SlaveRecvHook(void);
//static void DrvTWI_SlaveSendHook(void);
PFN_DRVTWI_CALLBACK DrvTWI_SlaveRecvHook = PNULL;
PFN_DRVTWI_CALLBACK DrvTWI_SlaveSendHook = PNULL;

/**********************************************************************************
***					       				EXPORTED FUNCTIONS						***													  	
**********************************************************************************/ 
/**
 *	@fn void DrvTWI_Init(void)
 *	 Initialize TWI
 */
void DrvTWI_Init(void)
{ 
	u8 u8Sreg;
	// store SREG
	u8Sreg = SREG;
	// close global interrupt
	CLI();
	// disable TWI and clear interrupt flag
	TWCR = 0x80;
	// set baud rate as 
	// Fscl = Fsys/(16+2*TWBR*pow(4,TWPS))
	TWSR = argTWPS;
	TWBR = argTWBR;
	// TWI enable
	TWCR = (1 << TWEN);
	// state
	g_u8TWIState = E_TWI_IDLE; 
	// enable IE, and ACK
#if argTWINTEna == TRUE
	TWCR |= (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
#else
	TWCR |= (1 << TWEA) | (1 << TWEN);
#endif
	//localBufferLength = 0x10;
	TWAR = argTWIAddr;
	// address mask
	TWAMR = argTWIAMask;
	// reanble global interrupt
	SREG = u8Sreg;    
} 

#if (argTWIMode == TWI_MODE_MASTER)
/**
 * @fn void DrvTWI_MasterTrans(u8 u8DevAddr)
 *	Start TWI Transfer
 * @param u8DevAddr
 *	u8DevAddr[7] = I2C Device Address
 *	u8DevAddr[0] = R/W Control Bit
 */
void DrvTWI_MasterTrans(u8 u8Mode, u8 u8DevAddr, u8 *pu8Buf, u8 u8Len) 
{ 
	u8 i;
	g_u8TWIDevAddrRW = u8DevAddr | u8Mode;
	if(u8Mode == 0) // I2C Master Write
	{
		for(i = 0; i < u8Len; i++)
		{
			g_bfu8TWIData[i] = *pu8Buf++;  
		}
	}
	g_u8TWIDataLength = u8Len;

	// start send when twi is in idle 
	while(g_u8TWIState & 0xf0);
	// set twi into master tx
	g_u8TWIState = E_TWI_MASTER_TX; 
	// send start 
	TWI_SEND_START(); 
	// stop send when send is completed
	while(g_u8TWIState & 0xf0);
	// wait for complete of STOP
	while((TWCR&(1<<TWSTO)));  
	// TWI_SEND_STOP();  
} 
#endif

/**
 * @fn void __vector_24 __attribute__((signal, __INTR_ATTRS))
 *	TWI's service routine, Compile when argTWINTEna is TRUE
 */
#if (argTWINTEna== TRUE)

LGT_VECTOR(IVN_TWI)
{ 
	u8 status; 
	// read twi status field
	status = TWI_STATUS_CODE(); 
	
	//if(status == TW_SR_STOP)
	//	TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 

	switch(status) 
	{ 
	// twi master mode
	case TWI_START:                   	// 0x08: START has been send
	case TWI_REP_START:               	// 0x10: re-START has been send
		// send SLA + R/W 
		TWDR=g_u8TWIDevAddrRW; 
		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		s_u8TWIDataIndex = 0;
		break;     
	// master-send/master-receive 
	case TWI_MT_SLA_ACK:               	// 0x18: SLA+W has been transmitted, and ACK has been received
		g_u8TWIState = E_TWI_MASTER_TX;
	case TWI_MT_DATA_ACK:            	// 0x28: data has been transmitted, and ACK has been received
		if(s_u8TWIDataIndex < g_u8TWIDataLength)
		{ 
			// send data
			TWDR=g_bfu8TWIData[s_u8TWIDataIndex++]; 
			TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		}
		else
		{ 
			// send stop
			TWI_SEND_STOP(); 
			// set twi status
			g_u8TWIState = E_TWI_IDLE; 
		} 
		break; 
	case TWI_MT_SLA_NACK:            	// 0x20: SLA+W has been send and NAk has been received 
	case TWI_MR_SLA_NACK:            	// 0x48: SLA+R has been send and NAk has been received
		// send stop
		TWI_SEND_STOP(); 
		// set status 
		g_u8TWIState = E_TWI_ADDR_NAK; 
		break; 
	case TWI_MR_DATA_NACK:            	// 0x58: data  has been received and NAK has been received 
		// store the last data
		g_bfu8TWIData[s_u8TWIDataIndex++] = TWDR; 
	case TWI_MT_DATA_NACK:            	// 0x30:  data has been send and NAk has been received
		// send stop
		TWI_SEND_STOP(); 
		// set status 
		g_u8TWIState = E_TWI_IDLE; 
		break; 
	case TWI_MT_ARB_LOST:            	// 0x38: SLA+W or data arbitration lost 
		// release bus
		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		// set status
		g_u8TWIState = E_TWI_ARB_LOST;     
		break; 
		
		// check that if all data has been received
	case TWI_MR_SLA_ACK:               	// 0x40: SLA+R has been received and ACK has been send
		g_u8TWIState = E_TWI_MASTER_RX;
		if(s_u8TWIDataIndex < (g_u8TWIDataLength-1)) 
			// ACK for data continue
    		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA);  
		else 
			// NAK for the last data
    		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT);  
		break;
	case TWI_MR_DATA_ACK:           	// 0x50: data has been received and ACK has been send 
		// store data into receive buffer
		g_bfu8TWIData[s_u8TWIDataIndex++] = TWDR; 
		if(s_u8TWIDataIndex < (g_u8TWIDataLength-1))  
			// ACK for data continue
    		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA);  
		else 
			// NAK for the last data
    		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT);  
		break;
	// slave receive 
	case TWI_SR_SLA_ACK:                // 0x60: SLA+W has been received, and ACK has been send
	case TWI_SR_ARB_LOST_SLA_ACK:  		// 0x68: arbitration lost as master, and SLA+W as slave has been received and NACK has been send
	case TWI_SR_GCALL_ACK:             	// 0x70: general call has been received, and ACK has been send
	case TWI_SR_ARB_LOST_GCALL_ACK:   	// 0x78: arbitration lost as master, general call has been received, and NACK has been send
		// device has been selected as slave
		// set status
		g_u8TWIState = E_TWI_SLAVE_RX; 
		// prepare receive buffer 
		s_u8TWIDataIndex = 0; 
		// receive data 
    	TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA);  
		break; 
	case TWI_SR_DATA_ACK:             		// 0x80: data has been received and ACK has been send -- sla + w
	case TWI_SR_GCALL_DATA_ACK:     		// 0x90: data has been received and ACK has been send -- general call
		// receive data
		g_bfu8TWIData[s_u8TWIDataIndex++] = TWDR; 
		// check that if the receive buffer if full
		if(s_u8TWIDataIndex < (TRANS_DATA_LEN)) 
			// ACK for data continue
    		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA);  
		else 
			// NAK for the last data
    		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT);  		// last data , send NAK
		break; 
	case TWI_SR_DATA_NACK:             		// 0x88: data has been received and NAK has been send -- sla + w
	case TWI_SR_GCALL_DATA_NACK:     		// 0x98: data has been received and NAK has been send -- general call 
		// receive data and return NAK
		g_bfu8TWIData[s_u8TWIDataIndex++] = TWDR;
		//twi_receive_byte(TRUE);
		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		if(DrvTWI_SlaveRecvHook != PNULL)
			DrvTWI_SlaveRecvHook(g_bfu8TWIData, &g_u8TWIDataLength);
		// receive complete
		g_u8TWIState = E_TWI_IDLE;
		break; 
	case TWI_SR_STOP:                 		// 0xA0: receive stop or re-start
		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		// twi  receive has complete, copy data from receive buffer into local buffer
		//if(s_pfnTWISlaveRecevCallBack)  
		//	s_pfnTWISlaveRecevCallBack(s_u8TWIRecevDataIndex, s_pu8TWIReceiveData);  
		g_u8TWIState = E_TWI_IDLE; 
		if(DrvTWI_SlaveRecvHook != PNULL)
			DrvTWI_SlaveRecvHook(g_bfu8TWIData, &g_u8TWIDataLength);
		break; 

	// slave send
	case TWI_ST_SLA_ACK:                	// 0xA8: SLA+R has been received and ACK has been send
	case TWI_ST_ARB_LOST_SLA_ACK:  			// 0xB0: arbitration lost, asn SLA+R has been received and ACK has been send
		// has been selected as slave transmitter
		// set status
		g_u8TWIState = E_TWI_SLAVE_TX; 
		// copy data from local buffer into transfer buffer 
		//DrvTWI_SlaveSendHook();
		if(DrvTWI_SlaveSendHook != PNULL)
			DrvTWI_SlaveSendHook(g_bfu8TWIData, &g_u8TWIDataLength);
		else
			g_u8TWIDataLength = 1;
		s_u8TWIDataIndex = 1; 		
	   	// load data into twi dta register
	 	TWDR=g_bfu8TWIData[0]; 
	   	// start send data
	 	TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		break;
		//  
	case TWI_ST_DATA_ACK:             // 0xB8: data has been send and ACK has been received
		// prepare data 
		TWDR=g_bfu8TWIData[s_u8TWIDataIndex++]; 
		if(s_u8TWIDataIndex < g_u8TWIDataLength) 
			TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); // ACK
		else 
			TWCR =(TWCR&TWCR_CMD_MASK)|(1<<TWINT); // NACK
		break; 
	case TWI_ST_DATA_NACK:             // 0xC0: TWDR NCK has been received
	case TWI_ST_LAST_DATA:             // 0xC8: the last data has been received and ACK has been received
		// 
		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWEA); 
		// set status
		g_u8TWIState = E_TWI_IDLE; 
		break;   
	case TWI_NO_INFO:                  // 0xF8: 
		// no operation  
		break; 
	case TWI_BUS_ERROR:                // 0x00: bus error because of illegal start or stop
		// hardware reset , release buf
		TWCR = (TWCR&TWCR_CMD_MASK)|(1<<TWINT)|(1<<TWSTO)|(1<<TWEA); 
		// set status
		g_u8TWIState = E_TWI_BUS_ERR; 
		break; 
	} 
}
#endif

/**********************************************************************************
***					       			LOCAL FUNCTONS								***													  	
**********************************************************************************/ 


/**********************************************************************************
***					       				EOF										***													  	
**********************************************************************************/ 

