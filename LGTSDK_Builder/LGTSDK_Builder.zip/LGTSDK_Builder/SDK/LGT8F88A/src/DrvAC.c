/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvAC.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvAC.c
 * @brief Source File of AC
 */

/** complier directives */
#define _DRVAC_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for AC initialize */

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvAC_Init(void)
 * @brief Initialize AC.
 */
void DrvAC_Init(void)
{
	// Disable AC
	ACSR = (1 << ACD);
	// Clear Interrupt Flag
	ACSR |= (1 << ACI);
	// set negetive input
#if (AC_ACME != E_ACME_AIN1)
	ADCSRA = 0x0;
	ADCSRB = (1 << ACME) | (AC_ACME);
#endif
	// set AC
	ACSR |= ((AC_ACBG << ACBG) | (AC_ACIEN << ACIE) | \
				(AC_ACIC << ACIC) | (AC_ACIS << ACIS0));
	// Disable AINT0 and AINT1's digital function
#if AC_ACBG == E_ACBG_AIN0
	DIDR1 = 1;
#endif
#if (AC_ACME == E_ACME_AIN1)
	DIDR1 |= 2;
#else
	DIDR0 |= (1 << AC_ACME);
#endif
	// enable AC
	ACSR &= ~(1 << ACD);
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/

