 /*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : LGT_TouchQ												    	**
** filename : TKdev.c		   	 												**
** version  : 1.0 													   			**
** date     : October 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	LogicGreen techologies									**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: October 01, 2013
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

#define _TKDEV_SRC_C_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***					        EXPORTED VARIABLES									***													  	
**********************************************************************************/
#if ((TK_CFG_ADC_ENA == 1) | (TK_CFG_AC_ENA == 1))
/** reference value */
unsigned int 	g_u16TKRefVal[TK_CFG_TKX_NUM];
/** current value */
unsigned int 	g_u16TKCurVal[TK_CFG_TKX_NUM];
/** sum of current value */
unsigned long	g_u32TKCurValSum[TK_CFG_TKX_NUM];
/** key status */
unsigned int 	g_u16Key;
/** calibration */
unsigned int	g_u16CalibTime;
#endif

/**********************************************************************************
***					        	LOCAL VARIABLES									***													  	
**********************************************************************************/
static void TK_GetChnCfg(unsigned char u8Indx, unsigned int* pu16Dsc);

static void TK_TKInit(void);
static void TK_PWMInit(void);
static void TK_PWMStart(void);
static void TK_PWMStop(void);
#if TK_CFG_ICP_ENA
static void TK_ICPInit(void);
static void TK_ICPStart(void);
static void TK_ICPStop(void);
#endif

#if (TK_CFG_ADC_ENA == 1)
static void TK_ADCInit(void);
static void TK_ADCStart(void);
static void TK_ADCStop(void);
static unsigned int TK_ADCReadData(void);
static void TK_ADCGetKey(void);
static void TK_ADCScanKey(void);
#endif
#if ((TK_CFG_AC_ENA == 1) || (TK_CFG_ADC_ENA))
static void TK_DelayUs(unsigned char u8Top);
#endif

#if ((TK_CFG_AC_ENA == 1) || (TK_CFG_INTERNAL))
static void TK_DelayMs(unsigned char u8Top);
#endif
#if (TK_CFG_AC_ENA == 1)
static void TK_ACInit(void);
static void TK_ACScanKey(void);
#endif
#if ((TK_CFG_PWM_TIMER == 1) || (TK_CFG_ICP_ENA == 1))
static void TK_WriteTC1Reg(unsigned int u8RegAddr, unsigned int u16RegVal);
static unsigned int TK_ReadTC1Reg(unsigned int u8RegAddr);
#endif
	


/**********************************************************************************
***					        EXPORTED FUNCTIONS									***													  	
**********************************************************************************/
/**
 * @fn void TK_Open(void)
 */
void TK_Open(void)
{
	unsigned int i, j;
	
#if (TK_CFG_ADC_ENA == 1)
	for(i = 0; i < TK_CFG_TKX_NUM; i++)
	{
		g_u16TKCurVal[i] = 0;
		g_u16TKRefVal[i] = 0;
		g_u32TKCurValSum[i] = 0;
		g_u16CalibTime = 0;
	}
#endif

	TK_TKInit();				/**< disable digital IO */
	TK_PWMInit();				/**< initial Timer for PWM */
	
#if (TK_CFG_ADC_ENA == 1)
	TK_ADCInit();
	TK_PWMStart();				/**< start PWM */
#if (TK_CFG_INTERNAL == 1)
	TK_TKCR = ((TK_CFG_PWM_TIMER + 1) << 5) | (TK_CFG_PWM_OCX << 4);					/**< select TK channel	*/
#endif
#endif
#if (TK_CFG_AC_ENA == 1)
	TK_ACInit();
#endif
#if (TK_CFG_ICP_ENA == 1)
	TK_ICPInit();
#endif


#if (TK_CFG_ADC_ENA == 1)		/**< get TKx's Reference Value */
#if (TK_CFG_INTERNAL == 0)
	for(i = 0; i < (500 / TK_CFG_TKX_NUM); i++)
	//for(i = 0; i < (0x60); i++)
	{
		TK_ADCGetKey();
	}
	for(j = 0; j < 8; j++)
#else
	for(j = 0; j < 2; j++)
#endif
	{
		TK_ADCScanKey();
	
		for(i = 0; i < TK_CFG_TKX_NUM; i++)
		{
			g_u16TKRefVal[i] += g_u16TKCurVal[i];
		}
	}
	for(i = 0; i < TK_CFG_TKX_NUM; i++)
	{
		g_u16TKRefVal[i] = g_u16TKRefVal[i] >> 3;
	}
	

#endif

#if (TK_CFG_AC_ENA == 1)		/**< get TKx's Reference Value */
/*	TK_PWMStart();*/
	for(j = 0; j < 8; j++)
	{
		TK_ACScanKey();
	
		for(i = 0; i < TK_CFG_TKX_NUM; i++)
		{
			g_u16TKRefVal[i] += g_u16TKCurVal[i];
		}
	}
	for(i = 0; i < TK_CFG_TKX_NUM; i++)
	{
		g_u16TKRefVal[i] = g_u16TKRefVal[i] >> 3;
	}
#endif

}

/**
 * @fn unsigned int TK_Key(void)
 *
 * @return 
 *		(1 << i) if TKi is ture
 */
unsigned int TK_Key(void)
{
	unsigned char i, u8CalibSign;
	unsigned char u8BufIndx;
	unsigned int u16ChnMsk;
	unsigned int u16Delta;

	STR_CHN_CFG  strChnCfg;

	u8CalibSign = 0;
	u8BufIndx = 0;
	u16ChnMsk = 1;
	
	// Scan TK0 - TK11
#if (TK_CFG_ADC_ENA == 1)
	TK_ADCScanKey();			/**< scan all key for TK_CFG_SAMPLE_TIME times */
	
#if (TK_CFG_INTERLACING == 1)		/**< interlaced scanning */
	for(i = 0; i < 13; i += 2)
	{
		if(i == 12)
		{
			i = 1;
			u16ChnMsk = 2;
		}
#else								/**< progressive scanning */
	for(i = 0; i < 12; i++)
	{
#endif
		if(u16ChnMsk & TK_CFG_TKX_ENA)
		{
			TK_GetChnCfg(i, (unsigned int *)(&strChnCfg));
			//TK_GetChnCfg(u8BufIndx, (unsigned int *)(&strChnCfg));
			
			if(g_u16TKRefVal[u8BufIndx] > g_u16TKCurVal[u8BufIndx])
			{
	
				u16Delta = g_u16TKRefVal[u8BufIndx] - g_u16TKCurVal[u8BufIndx];
				
				if(u16Delta > strChnCfg.u16KeyPress)		/**< key touch threshold */
					g_u16Key |= (1 << u8BufIndx);
				else if(u16Delta < strChnCfg.u16KeyRelease)	/**< key realease threshold */
					g_u16Key &= ~(1 << u8BufIndx);

				
				if((u16Delta > strChnCfg.u16KeyCalib) && (!(g_u16Key & strChnCfg.u16KeyRelated)))		/**< calibration threshold */
					u8CalibSign = 1;
				if((g_u16Key & strChnCfg.u16KeyMulti) && (g_u16Key & (~(strChnCfg.u16KeyMulti))))
					u8CalibSign = 1;
			
			}
			else
			{
				u16Delta = g_u16TKCurVal[u8BufIndx] - g_u16TKRefVal[u8BufIndx];
				g_u16Key &= ~(1 << u8BufIndx);
				if((u16Delta > strChnCfg.u16KeyCalib) && (!(g_u16Key & strChnCfg.u16KeyRelated)))
					u8CalibSign = 1;
			}
			u8BufIndx++;
		}
		
#if (TK_CFG_INTERLACING == 1)
		u16ChnMsk = u16ChnMsk << 2;
#else
		u16ChnMsk = u16ChnMsk << 1;
#endif

	}

	if(u8CalibSign == 1)
	{
		g_u16CalibTime += 1;
		
		if(g_u16CalibTime > TK_CFG_CALIB_TOP)
		{
			TK_ADCScanKey();

			for(i = 0; i < TK_CFG_TKX_NUM; i++)
				g_u16TKRefVal[i] = g_u16TKCurVal[i];
			g_u16CalibTime = 0;
		}
		return 0x0;
	}
	else
		g_u16CalibTime = 0;	

	
#elif (TK_CFG_AC_ENA == 1)

	TK_ACScanKey();			/**< scan all key for TK_CFG_SAMPLE_TIME times */		
	
#if (TK_CFG_INTERLACING == 1)		/**< interlaced scanning */
	for(i = 0; i < 13; i += 2)
	{
		if(i == 12)
		{
			i = 1;
			u16ChnMsk = 2;
		}
#else								/**< progressive scanning */
	for(i = 0; i < 12; i++)
	{
#endif
		if(u16ChnMsk & TK_CFG_TKX_ENA)
		{
			TK_GetChnCfg(i, (unsigned int *)(&strChnCfg));
			//TK_GetChnCfg(u8BufIndx, (unsigned int *)(&strChnCfg));
			
			if(g_u16TKRefVal[u8BufIndx] < g_u16TKCurVal[u8BufIndx])
			{
				u16Delta = g_u16TKCurVal[u8BufIndx] - g_u16TKRefVal[u8BufIndx];
				
				if(u16Delta > strChnCfg.u16KeyPress)		/**< key touch threshold */
					g_u16Key |= (1 << u8BufIndx);

				else if(u16Delta < strChnCfg.u16KeyRelease)	/**< key realease threshold */
					g_u16Key &= ~(1 << u8BufIndx);

				
				if((u16Delta > strChnCfg.u16KeyCalib) && (!(g_u16Key & strChnCfg.u16KeyRelated)))		/**< calibration threshold */
					u8CalibSign = 1;
				if((g_u16Key & strChnCfg.u16KeyMulti) && (g_u16Key & (~(strChnCfg.u16KeyMulti))))
					u8CalibSign = 1;
				
			}
			else
			{
				u16Delta = g_u16TKRefVal[u8BufIndx] - g_u16TKCurVal[u8BufIndx];
				g_u16Key &= ~(1 << u8BufIndx);
				if((u16Delta > strChnCfg.u16KeyCalib) && (!(g_u16Key & strChnCfg.u16KeyRelated)))
					u8CalibSign = 1;
			}
			u8BufIndx++;
		}
		
#if (TK_CFG_INTERLACING == 1)
		u16ChnMsk = u16ChnMsk << 2;
#else
		u16ChnMsk = u16ChnMsk << 1;
#endif

	}

	if(u8CalibSign == 1)
	{
		g_u16CalibTime += 1;
		
		if(g_u16CalibTime > TK_CFG_CALIB_TOP)
		{
			TK_ACScanKey();

			for(i = 0; i < TK_CFG_TKX_NUM; i++)
				g_u16TKRefVal[i] = g_u16TKCurVal[i];
		}
		return 0x0;
	}
	else
		g_u16CalibTime = 0;

#endif
	return g_u16Key;

}

/**
 * @fn 
 */
#if TK_CFG_AC_ENA
extern unsigned char g_u8Dig6;
extern unsigned char g_u8Dig4;
extern unsigned char g_u8Dig3;
extern unsigned char g_u8Dig2;
extern unsigned char g_u8Dig1;
extern unsigned char  	g_u8DigTbl[17];
#endif
unsigned int TK_Test(void)
{
#if TK_CFG_AC_ENA

	unsigned int u16Tmp;

	//TK_ACScanKey();
	
	TK_TKCR = 0;
	TK_ICPStart();
	//TK_AC_START();
	TK_DelayMs(1);
	g_u8Dig4 = g_u8DigTbl[(TK_ACSR & 0x20) >> 4];
	
	TK_PWMStart();
	//while(TK_ACSR & 0x20);
#if 1
	while(1)
	{
		g_u8Dig3= g_u8DigTbl[(TK_ACSR & 0x20) >> 4];
		g_u8Dig2= g_u8DigTbl[(TK_ACSR & 0xf)];
		//g_u8Dig2= g_u8DigTbl[TK_TIFR1 & 0xf];
		g_u8Dig1= g_u8DigTbl[(TK_TIFR1 >> 4) & 0xf];
	}
#else
	while(!(TK_TIFR1 & 0x20))
	{
	if((TK_ACSR & 0x20) == 0)
		g_u8Dig6 = 0xa0;
	}
#endif
	TK_TIFR1 = 0x20;
	if((TK_ACSR & 0x20) == 0)
		g_u8Dig6 = 0xaa;

	TK_PWMStop();
	TK_ICPStop();
	//TK_AC_STOP();
	TK_DelayMs(40);

	u16Tmp = TK_ReadTC1Reg(0x86);
	return u16Tmp;
	
#else
	return 0;
#endif
}

/**
 * @fn static void TK_GetChnCfg(unsigned char u8Indx, unsigned int* pu16Dsc)
 */
static void TK_GetChnCfg(unsigned char u8Indx, unsigned int* pu16Dsc)
{
	switch(u8Indx)
	{
	case 0:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK0;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK0;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK0;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK0;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK0;
		break;
	case 1:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK1;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK1;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK1;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK1;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK1;
		break;
	case 2:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK2;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK2;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK2;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK2;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK2;
		break;
	case 3:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK3;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK3;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK3;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK3;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK3;
		break;
	case 4:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK4;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK4;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK4;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK4;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK4;
		break;
	case 5:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK5;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK5;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK5;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK5;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK5;
		break;
	case 6:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK6;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK6;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK6;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK6;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK6;
		break;
	case 7:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK7;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK7;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK7;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK7;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK7;
		break;
	case 8:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK8;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK8;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK8;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK8;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK8;
		break;
	case 9:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK9;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK9;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK9;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK9;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK9;
		break;
	case 10:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK10;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK10;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK10;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK10;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK10;
		break;
	case 11:
		*pu16Dsc++ = TK_CFG_DELTA_PRESS_TK11;
		*pu16Dsc++ = TK_CFG_DELTA_RELEASE_TK11;
		*pu16Dsc++ = TK_CFG_DELTA_CALIB_TK11;
		*pu16Dsc++ = TK_CFG_KEY_RELATED_TK11;
		*pu16Dsc   = TK_CFG_KEY_MULTI_TK11;
		break;
	default:;
	}
}

/*
 * @fn static void TK_TKInit(void)
 *	disable TKi's digital input function, if TKi is enabled for Touch Key
 */
static void TK_TKInit(void)
{
	unsigned char u8Reg;

	u8Reg = (TK_CFG_TK0_ENA << TK_DIDR20) | ( TK_CFG_TK1_ENA << TK_DIDR21) \
			| (TK_CFG_TK2_ENA << TK_DIDR22) | ( TK_CFG_TK3_ENA << TK_DIDR23) \
			| (TK_CFG_TK4_ENA << TK_DIDR24) | ( TK_CFG_TK5_ENA << TK_DIDR25) \
			| (TK_CFG_TK6_ENA << TK_DIDR26) | ( TK_CFG_TK7_ENA << TK_DIDR27);

	TK_DIDR2 = u8Reg;

	u8Reg = (TK_CFG_TK8_ENA << TK_DIDR30) | ( TK_CFG_TK9_ENA << TK_DIDR31) \
			| (TK_CFG_TK10_ENA << TK_DIDR32) | ( TK_CFG_TK11_ENA << TK_DIDR33);

	TK_DIDR3 = u8Reg;
}

/*
 * @fn static void TK_PWMInit(void)
 *	PWM(TC1/TC2/TC2) -- 500KHz/1MHz
 */
static void TK_PWMInit(void)
{
#if (TK_CFG_PWM_TIMER == 0)	// TC0

	TK_TCCR0B 	= 0;
	TK_TCNT0 	= 0;
#if (TK_CFG_PWM_OCX == 0)
	TK_TCCR0A 	= 0x42;		// CTC
	TK_TCCR0B 	= TK_CFG_PWM_OCXPIN << 5;
#else
	TK_TCCR0A 	= 0x23;		// FPWM-OCR0A
	TK_TCCR0B 	= 0x08;
#endif

#if (TK_CFG_INTERNAL == 0)	
#if TK_CFG_PWM_OCX
	TK_DDRD		|= (1 << 5);
#else
#if TK_CFG_PWM_OCXPIN
	TK_DDRE		|= (1 << 4);
#else
	TK_DDRD		|= (1 << 6);
#endif
#endif

#endif

#if (TK_CFG_PWM_OCX == 0)
	TK_OCR0A 	=  (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 200) - 1;
	TK_OCR0B 	=  (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 200) - 1;
#elif (TK_CFG_PWM_OCX == 1)
	TK_OCR0A 	=  (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) - 1;
	TK_OCR0B 	=  (((((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) * TK_CFG_PWM_DUTY + 50) / 100) - 1;
#endif

#elif (TK_CFG_PWM_TIMER == 1) // TC1

	TK_TCCR1B 	= 0;
	TK_WriteTC1Reg(0x84, 0x0000);	// TCNT1 = 0
	
	TK_TCCR1A 	= (2 << (6 - TK_CFG_PWM_OCX - TK_CFG_PWM_OCX)) | 0x2;	// FPWM - ICR1
	TK_TCCR1B 	= 0x18;


#if (TK_CFG_INTERNAL == 0)
#if TK_CFG_PWM_OCX 
	TK_DDRB		|= (1 << 2);
#else
	TK_DDRB		|= (1 << 1);
#endif
#endif
	
#if (TK_CFG_PWM_OCX == 0)
	TK_WriteTC1Reg(0x86, (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) - 1);
	TK_WriteTC1Reg(0x88, (((((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) * TK_CFG_PWM_DUTY + 50) / 100) - 1);
#elif (TK_CFG_PWM_OCX == 1)
	TK_WriteTC1Reg(0x86, (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) - 1);
	TK_WriteTC1Reg(0x8a, (((((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) * TK_CFG_PWM_DUTY + 50) / 100) - 1);
#endif

#else						// TC2
	TK_TCCR2B 	= 0;
	TK_TCNT2	= 0;
#if (TK_CFG_PWM_OCX == 0)
	TK_TCCR2A 	= 0x42;
#else
	TK_TCCR2A 	= 0x23;
	TK_TCCR2B 	= 0x8;
#endif
#if (TK_CFG_INTERNAL == 0)
#if TK_CFG_PWM_OCX 
		TK_DDRD 	|= (1 << 3);
#else
		TK_DDRB 	|= (1 << 3);
#endif
#endif
 
#if (TK_CFG_PWM_OCX == 0)
	TK_OCR2A 	=  (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 200) - 1;
	TK_OCR2B 	=  (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 200) - 1;
#elif (TK_CFG_PWM_OCX == 1)
	TK_OCR2A 	=  (((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) - 1;
	TK_OCR2B 	=  (((((TK_CFG_MCU_FREQ / TK_CFG_PWM_FREQ) + 50) / 100) * TK_CFG_PWM_DUTY + 50) / 100) - 1;
#endif

#endif
}

/**
 * @fn static void TK_PWMStart(void)
 */
static void TK_PWMStart(void)
{
#if (TK_CFG_PWM_TIMER == 0)	// TC0
	TK_TCCR0B	= (TK_TCCR0B & 0xf8) | 1;
#elif (TK_CFG_PWM_TIMER == 1) // TC1
	TK_TCCR1B	= (TK_TCCR1B & 0xf8) | 1;
#else						// TC2
	TK_TCCR2B	= (TK_TCCR2B & 0xf8) | 1;
#endif
}

/**
 * @fn static void TK_PWMStop(void)
 */
static void TK_PWMStop(void)
{
#if (TK_CFG_PWM_TIMER == 0)	// TC0
	TK_TCCR0B 	= TK_TCCR0B & 0xf8;
#elif (TK_CFG_PWM_TIMER == 1) // TC1
	TK_TCCR1B 	= TK_TCCR1B & 0xf8;
#else						// TC2
	TK_TCCR2B 	= TK_TCCR2B & 0xf8;
#endif
}

#if TK_CFG_ICP_ENA
/**
 * @fn static void TK_ICPInit(void)
 */
static void TK_ICPInit(void)
{
	TK_TCCR1B 	= 0;
	TK_WriteTC1Reg(0x84, 0x0000);	/**< TCNT1 = 0 */
	TK_TCCR1A 	= 0;				/**< normal */
	TK_TIMSK1	= 0;
	TK_TIFR1	= 0x27;
}

/**
 * @fn static void TK_ICPStart(void)
 */
static void TK_ICPStart(void)
{
	TK_WriteTC1Reg(0x84, 0x0000);	// TCNT1 = 0
#if (TK_CFG_MCU_FREQ == 32000)
	TK_TCCR1B 	= 0x84;
#elif (TK_CFG_MCU_FREQ == 16000)
	TK_TCCR1B 	= 0x83;
#else
	TK_TCCR1B 	= 0x83;
#endif
	TK_TIFR1 = 0x20;
}

/**
 * @fn static void TK_ICPStop(void)
 */
static void TK_ICPStop(void)
{
	TK_TCCR1B = 0;
}
#endif

#if ((TK_CFG_PWM_TIMER == 1) || (TK_CFG_ICP_ENA == 1))
/**
 * @fn static void TK_WriteTC1Reg(void)
 */
static void TK_WriteTC1Reg(unsigned int u8RegAddr, unsigned int u16RegVal)
{
	unsigned char sregval;
	// save global interrupt flag
	sregval = TK_SREG;
	// disable interrupts
	asm("cli");
	// set tcnt1
	(*(volatile unsigned char *)(u8RegAddr + 1)) = (u16RegVal >> 8);
	(*(volatile unsigned int *)(u8RegAddr))  = u16RegVal;
	// restore global interrupt flag
	TK_SREG = sregval;
}

/**
 * @fn static void TK_ReadTC1Reg(void)
 */
static unsigned int TK_ReadTC1Reg(unsigned int u8RegAddr)
{
	unsigned char sregval;
	unsigned int regval;
	// save global interrupt flag
	sregval = TK_SREG;
	// disable interrupts
	asm("cli");
	// set tcnt1
	regval = (*((volatile unsigned char *)(u8RegAddr)));
	regval |=((*((volatile unsigned char *)(u8RegAddr + 1))) << 8);
	// restore global interrupt flag
	TK_SREG = sregval;
	//
	return(regval);
}

#endif

#if (TK_CFG_ADC_ENA == 1)
/**
 * @fn static void TK_ADCInit(void)
 */
static void TK_ADCInit(void)
{
#if (TK_CFG_MCU_FREQ == 32000)
	TK_ADCSRA = 0x90 | 5;
#elif (TK_CFG_MCU_FREQ == 16000)
	TK_ADCSRA = 0x90 | 4;
#elif (TK_CFG_MCU_FREQ == 8000)
	TK_ADCSRA = 0x90 | 3;
#endif
	TK_ADCSRB = 0;
	TK_ADMUX = 0x40 | 26;
}

/**
 * @fn static void TK_ADCStart(void)
 */
static void TK_ADCStart(void)
{
	TK_ADCSRA |= (1 << 6);
}

/**
 * @fn static void TK_ADCStop(void)
 */
static void TK_ADCStop(void)
{
	TK_ADCSRA &= ~(1 << 5);
}

/**
 * @fn static unsigned int TK_ADCReadData(void)
 */
static unsigned int TK_ADCReadData(void)
{
	unsigned int u16Temp;

  	while(!(TK_ADCSRA & (1 << 4)));
	u16Temp = TK_ADCL;
	u16Temp |= (TK_ADCH << 8);

	TK_ADCSRA |= (1 << 4);
	return u16Temp;
}

/**
 * @fn static void TK_ADCGetKey(void)
 */
static void TK_ADCGetKey(void)
{
	unsigned char i, j;
	unsigned char u8BufIndx;
	unsigned int  u16ChnMsk;
	unsigned int  u16Sum, u16Tmp, u16Max, u16Min;

	u8BufIndx = 0;
	u16ChnMsk = 1;

#if (TK_CFG_INTERLACING == 1)	
	for(i = 0; i < 13; i += 2)
	{
		if(i == 12)
		{
			i = 1;
			u16ChnMsk = 2;
		}
#else
	for(i = 0; i < 12; i++)
	{
#endif
		if(TK_CFG_TKX_ENA & u16ChnMsk)
		{

#if (TK_CFG_INTERNAL == 1)
			TK_TKCR = ((TK_CFG_PWM_TIMER + 1) << 5) | (TK_CFG_PWM_OCX << 4) | i;					/**< select TK channel	*/
#else
			TK_TKCR = i;					/**< select TK channel	*/
#endif
			//TK_ADMUX = 0x45;
			u16Sum = 0;
			u16Min = 0x3ff;
			u16Max = 0;
#if (TK_CFG_INTERNAL == 1)
			TK_DelayMs(30);
#else
			TK_DelayUs(50);					/**< delay 50us */
#endif
			// first conver - dummy conver
			TK_ADCStart();					/**< start conver */
			u16Tmp = TK_ADCReadData(); 		/**< read ADC result */

			// effective conver
			for(j = 0; j < TK_CFG_SAMPLE_NUM + 2; j++)
			{
				TK_ADCStart();				/**< start conver */
				u16Tmp = TK_ADCReadData();	/**< read ADC result */

				if(u16Max < u16Tmp)			/**< maximum value */
					u16Max = u16Tmp;
				if(u16Tmp < u16Min)			/**< minimum value */
					u16Min = u16Tmp;
				u16Sum += u16Tmp;			/**< sum of samples */
			}
			u16Sum -= u16Max;				/**< remove the maximum value from sum */
			u16Sum -= u16Min;				/**< remove the minimus value from sum */

			g_u16TKCurVal[u8BufIndx] = u16Sum;	/** store sum of samples */
			u8BufIndx++;
		}
#if (TK_CFG_INTERLACING == 1)
		u16ChnMsk = u16ChnMsk << 2;
#else
		u16ChnMsk = u16ChnMsk << 1;
#endif
	}
}

/**
 * @fn static void TK_ADCScanKey(void)
 */
void TK_ADCScanKey(void)
{
	unsigned char i, j;

	for(i = 0; i < TK_CFG_TKX_NUM; i++)					/**< clean sum */
		g_u32TKCurValSum[i] = 0x0;

	for(j = 0; j < TK_CFG_SAMPLE_TIME; j++)				/**< scan touch key for (TK_CFG_SAMPLE_TIME) times */
	{
		TK_ADCGetKey();									/**< scan touch for one time */
		for(i = 0; i < TK_CFG_TKX_NUM; i++)
			g_u32TKCurValSum[i] += g_u16TKCurVal[i];
	}

	// get the average value
	for(i = 0; i < TK_CFG_TKX_NUM; i++)					/**< average */
		g_u16TKCurVal[i] = g_u32TKCurValSum[i] / TK_CFG_SAMPLE_DIV;
}
#endif

#if ((TK_CFG_AC_ENA == 1) || (TK_CFG_ADC_ENA))

/**
 * @fn static void TK_DelayUs(unsigned char u8Top)
 */
static void TK_DelayUs(unsigned char u8Top)
{
	unsigned char u8Cnt;

	u8Top -= 2;

	for(u8Cnt = 0; u8Cnt < u8Top; u8Cnt++)
	{
		asm("nop");
		asm("nop");
 		asm("nop");
		asm("nop");
		asm("nop");
	}
}
#endif

#if ((TK_CFG_AC_ENA == 1) || (TK_CFG_INTERNAL == 1))
/**
 * @fn static void TK_DelayMs(unsigned char u8Top)
 */
static void TK_DelayMs(unsigned char u8Top)
{
	unsigned char u8Cnt;

	for(u8Cnt = 0; u8Cnt < u8Top; u8Cnt++)
	{
		TK_DelayUs(250);
		TK_DelayUs(250);
		TK_DelayUs(250);
		TK_DelayUs(240);
	}
}
#endif

#if (TK_CFG_AC_ENA == 1)
/**
 * @fn static void TK_ACInit(void)
 */
static void TK_ACInit(void)
{
	// ACME = 1;
	TK_ADCSRB = 0x40;
	// CH = TK
	TK_ADMUX = 26;
#if (TK_CFG_MCU_FREQ == 32000)
	TK_ADCSRA = 0x10 | 5;
#elif (TK_CFG_MCU_FREQ == 16000)
	TK_ADCSRA = 0x10 | 4;
#elif (TK_CFG_MCU_FREQ == 8000)
	TK_ADCSRA = 0x10 | 3;
#endif

	// ACBG = 1; ACIC = 1
	TK_ACSR = (1 << 6) | (1 << 2);
}

/**
 * static void TK_ACScanKey(void)
 */
static void TK_ACScanKey(void)
{
	unsigned char i, j;
	unsigned int u16ChnMsk;
	unsigned int u16Tmp;
	unsigned char u8BufIndx;

	for(j = 0; j < TK_CFG_TKX_NUM; j++)
		g_u32TKCurValSum[j] = 0;

	for(j = 0; j < TK_CFG_SAMPLE_TIME; j++)
	{
		u16ChnMsk = 1;
		u8BufIndx = 0;
#if (TK_CFG_INTERLACING == 1)
		for(i = 0; i < 13; i+=2)
		{
			if(i == 12)
			{
				i = 1;
				u16ChnMsk = 2;
			}
#else
		for(i = 0; i < 12; i++)
		{
#endif
			if(TK_CFG_TKX_ENA & u16ChnMsk)
			{
#if (TK_CFG_INTERNAL == 1)
				TK_TKCR = ((TK_CFG_PWM_TIMER + 1) << 5) | (TK_CFG_PWM_OCX << 4) | i;
#else
				TK_TKCR = i;
#endif
				TK_ICPStart();
				TK_PWMStart();
				//asm("cli");
				//while(TK_ACSR & 0x20);
				while(!(TK_TIFR1 & 0x20));
				TK_TIFR1 = 0x20;
				//asm("sei");
				TK_PWMStop();
				TK_ICPStop();
#if (TK_CFG_INTERNAL == 1)
				TK_TKCR = 0x80;
				TK_DelayMs(10);
#else
				TK_DelayMs(40);
#endif

				g_u32TKCurValSum[u8BufIndx] += TK_ReadTC1Reg(0x86);
				u8BufIndx++;
			}
#if (TK_CFG_INTERLACING == 1)
			u16ChnMsk = u16ChnMsk << 2;
#else
			u16ChnMsk = u16ChnMsk << 1;
#endif
		}
	}

	u8BufIndx = 0;
	u16ChnMsk = 1;

	for(i = 0; i < 12; i++)
	{
		if(TK_CFG_TKX_ENA & u16ChnMsk)
		{
			g_u16TKCurVal[u8BufIndx] = g_u32TKCurValSum[u8BufIndx] / TK_CFG_SAMPLE_DIV;
			u8BufIndx++;
		}
		u16ChnMsk = u16ChnMsk << 1;
	}

}

#endif


/**********************************************************************************
***					          	DEFINITINS										***													  	
**********************************************************************************/
