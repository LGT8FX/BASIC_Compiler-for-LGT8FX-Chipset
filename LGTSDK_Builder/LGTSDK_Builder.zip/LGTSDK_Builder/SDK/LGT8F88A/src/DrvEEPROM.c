/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvEEPROM.c  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/** complier directives */
#define _DrvEEPROM_SRC_C_

/**********************************************************************************
*** 							MODULES USED									*** 													
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***					         MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/** macro for Flash Control Enable */

/**********************************************************************************
*** 								LOCAL VARIABLES 							*** 													
**********************************************************************************/

/**********************************************************************************
*** 						  EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvEEPROM_ProgByte(u16 u16Addr, u16 u16Len, u8 *pu8Data)
 *	Program EEPROM in Byte mode
 * @param u16Addr
 *	EEPROM Address which specify the Write Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the source data
 */
void DrvEEPROM_ProgByte(u16 u16Addr, u8 u8Data)
{
	DrvMISC_CLRI();
	// wait for completion of previous write
	// while(EECR & (1 << EEPE));
	
	// address
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	// data
	EEDR = u8Data;
	// Program Mode
	EECR = (E_EEPROM_BYTE << 5);
	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	__ASM("sbi 0x1f, 2");
	__ASM("sbi 0x1f, 1");
	//
	DrvMISC_RESI();
}

/** 
 * @fn void DrvEEPROM_ReadEByte(u16 u16Addr, u16 u16Len, u8 *pu8Data)
 *	Read data from EEPROM in Byte mode
 * @param u16Addr
 *	EEPROM Address which specify the Read Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the destination space
 */
u8 DrvEEPROM_ReadByte(u16 u16Addr)
{
	
	// wait for completion of previous write
	// while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	// start eeprom read by writting EERE
	EECR |= (1 << EERE);
	NOP();
	NOP();

	// return data from data register
	return EEDR;
}

#if (EEPROM_HWORD_EN == 1)
/**
 * @fn void DrvEEPROM_ProgHWord(u16 wAddr, u16 wData)
 *	Write 2-byte
 * @param wAddr
 *	Half-word address
 * @param wData
 *	2-byte data
 */
void DrvEEPROM_ProgHWord(u16 u16Addr, u16 u16Data)
{
	DrvMISC_CLRI();

	// wait for completion of previous write
	// while(EECR & (1 << EEPE));
	
	u16Addr = u16Addr & 0xfffe;
	// address
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	// data
	EEDR = u16Data & 0xff;
	//
	u16Addr += 1;
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	EEDR = (u16Data >> 8) & 0xff;
	// Program Mode
	EECR = (E_EEPROM_HWORD << 5);
	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	
	__ASM("sbi 0x1f, 2");
	__ASM("sbi 0x1f, 1");

	// wait for completion of This write
	//while(EECR & (1 << EEPE));
	DrvMISC_RESI();
}
#endif

#if EEPROM_WORD_EN == 1
/**
 *	@fn	DrvEEPROM_ProgWord(u16 u16Addr, u32 u32Data)
 *		Write 4 byte in one page in EEPROM
 *	@param u16Addr
 *		Word Address
 *	@param u32Data
 *		4-byte data
 */
void DrvEEPROM_ProgWord(u16 u16Addr, u32 u32Data)
{
	DrvMISC_CLRI();

	u16Addr = u16Addr & 0xfffc;
	// wait for completion of previous write
	// while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	// data
	EEDR = u32Data & 0xff;
	//
	EEARL = (u16Addr + 3) & 0xff;
	EEDR = (u32Data >> 24) & 0xff;
	EEARL = (u16Addr + 2) & 0xff;
	EEDR = (u32Data >> 16) & 0xff;
	EEARL = (u16Addr + 1) & 0xff;
	EEDR = (u32Data >> 8) & 0xff;
	
	// Program Mode
	EECR = (E_EEPROM_WORD << 5);
	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	__ASM("sbi 0x1f, 2");
	__ASM("sbi 0x1f, 1");
	// wait for completion of This write
	// while(EECR & (1 << EEPE));
	
	DrvMISC_RESI();
}
#endif

#if (FLASH_ISPAPI_EN == 1)
/**
 * @fn void DrvEEPROM_ProgFWord(u16 u16Addr, u16 u16Len, u8 *pData)
 *	Program FLASH in Word(4-Byte) Mode
 * @param u16Addr
 *	EEPROM Address which specify the Write Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the source data
 */
void DrvFLASH_ProgData(u16 u16Addr, u16 u16Len, u16 *pu16Data)
{
	u16 i;

	u8 *pData = (u8 *)(pu16Data);

	DrvMISC_CLRI();

	for(i = 0; i < u16Len; i++)
	{
		// wait for completion of previous write
		while(EECR & (1 << EEPE));
		u16Addr = u16Addr & 0xfffc;
		// address
		EEARH = (u16Addr >> 8) & 0xff;
		EEARL = (u16Addr) & 0xff;
		u16Addr += 1;
		// data
		EEDR = *pData++;
		//
		EEARL = (u16Addr) & 0xff;
		EEDR = *pData++;
		u16Addr += 1;
		//
		EEARL = (u16Addr) & 0xff;
		EEDR = *pData++;
		u16Addr += 1;
		//
		EEARL = (u16Addr) & 0xff;
		EEDR = *pData++;
		u16Addr += 1;
		// Program Mode
		EECR = 0xa0 | (EECR & (1 << EERIE));
		// write logical one to EEMWE
		// start eeprom write by setting EEWE
		__ASM("sbi 0x1f, 2");
		__ASM("sbi 0x1f, 1");

	}
	// wait for completion of This write
	while(EECR & (1 << EEPE));

	EECR = (EECR & (1 << EERIE));
	
	DrvMISC_RESI();
}

/**
 * @fn void DrvEEPROM_EraseFPage(u16 u16Addr)
 *	Erase FLASH in Page(512-Byte) Mode
 * @param u16Addr
 *	EEPROM Address which specify the Erase Space, u16Addr[8:0] Must be 0x00
 */
void DrvEEPROM_ErasePage(u16 u16Addr)
{
	DrvMISC_CLRI();

	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0xff;
	EEARL = (u16Addr) & 0xff;
	// data
	//EEDRL = *wData & 0xff;
	//EEDRH = (*wData >> 8) & 0xff;
	// Program Mode
	EECR = 0x80;
	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	__ASM("sbi 0x1f, 2");
	__ASM("sbi 0x1f, 1");
	/// wait for completion of This write
	while(EECR & (1 << EEPE));
	// re-config global interrupt enable
	DrvMISC_RESI();

	EECR = 0x0;		
}


/**
 * @fn void DrvEEPROM_EraseFPage(u16 u16Addr)
 *	Erase FLASH in Page(512-Byte) Mode
 * @param u16Addr
 *	EEPROM Address which specify the Erase Space, u16Addr[8:0] Must be 0x00
 */
void DrvFLASH_ErasePage(u16 u16Addr)
{
	DrvMISC_CLRI();

	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0xff;
	EEARL = (u16Addr) & 0xff;
	// data
	//EEDRL = *wData & 0xff;
	//EEDRH = (*wData >> 8) & 0xff;
	// Program Mode
	EECR = 0x90;
	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	__ASM("sbi 0x1f, 2");
	__ASM("sbi 0x1f, 1");
	/// wait for completion of This write
	while(EECR & (1 << EEPE));
	// re-config global interrupt enable
	DrvMISC_RESI();

	EECR = 0x0;		
}

static void DrvFLASH_LPMReadWord(u16 u16Addr, u16* pu16Data)
{
	Compiler_LPMReadWord();

	u16Addr = u16Addr;
	pu16Data = pu16Data;
}

/**
 * @fn void DrvEEPROM_ReadFWord(u16 u16Addr, u16 u16Len, u16 *pu16Data)
 *	Program FLASH in Word(4-Byte) Mode
 * @param u16Addr
 *	EEPROM Address which specify the Write Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the source data
 */
void DrvFLASH_ReadData(u16 u16Addr, u16 u16Len, u16 *pu16Data)
{
	u16 i;
	for(i = 0; i < u16Len; i++) 
	{
		DrvFLASH_LPMReadWord(u16Addr, pu16Data++);//pgm_read_word(u16Addr);
		u16Addr += 2;
	}
}

#endif

/**********************************************************************************
*** 										EOF 								*** 													
**********************************************************************************/

