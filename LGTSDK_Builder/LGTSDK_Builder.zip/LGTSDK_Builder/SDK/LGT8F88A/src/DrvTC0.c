/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvTC0.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvTC0.c
 * @brief Source File of TC0 driver 
 */

/** complier directives */
#define _DRVTC0_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"

#if (TC0_CS0 == 0)
	#warning <E0:Timer/Counter 0> No clock source selected for Timer 0
#endif	

#if ((TC0_WGM0 != 0) && (TC0_WGM0 != 2)) && (TC0_COM0A == 1)
	#warning <W0:Timer/Counter 0> Selected compare(A) mode only support by Normal/CTC mode
#endif

#if ((TC0_WGM0 != 0) && (TC0_WGM0 != 2)) && (TC0_COM0B == 1)
	#warning <W0:Timer/Counter 0> Selected compare(B) mode only support by Normal/CTC mode
#endif

#if ((TC0_WGM0 == 0) || (TC0_WGM0 == 2) || (TC0_WGM0 == 4) || (TC0_WGM0 == 5))
	#if (TC0_OC0AEN == 1) && (TC0_COM0A == 1)
	#warning <W1:Timer/Counter 0> OC0A only support 50% duty ratio PWM with current configuration
	#endif
#endif

#if ((TC0_WGM0 == 0) || (TC0_WGM0 == 2))
	#if (TC0_OC0BEN == 1) && (TC0_COM0B == 1)
	#warning <W1:Timer/Counter 0> OC0B only support 50% duty ratio PWM with current configuration
	#endif
	#if (TC0_COM0A != 1) && (TC0_OC0AEN == 1)
	#warning <W1:Timer/Counter 0> There will no PWM output on OC0A with current configuration
	#endif
	#if (TC0_COM0B != 1) && (TC0_OC0BEN == 1)
	#warning <W1:Timer/Counter 0> There will no PWM output on OC0B with current configuration
	#endif
#endif

#if (TC0_WGM0 == 2) || (TC0_WGM0 == 4) || (TC0_WGM0 == 5)
	#if (TC0_OCR0B > TC0_OCR0A)
	#warning <E0:Timer/Counter 0> OCR0B should not over than OCR0A in selected mode
	#endif
#endif	

#if (TC0_COM0A == 0) && (TC0_OC0AEN == 1)
#warning <W1:Timer/Counter 0> Compare(A) mode must be selected for PWM output
#endif

#if (TC0_COM0B == 0) && (TC0_OC0BEN == 1)
#warning <W1:Timer/Counter 0> Compare(B) mode must be selected for PWM output
#endif

#if (TC0_COM0A != 0) && (TC0_OCR0A == 0)
#warning <W1:Timer/Counter 0> Please confirm OCR0A is given properly
#endif

#if (TC0_COM0B != 0) && (TC0_OCR0B == 0)
#warning <W1:Timer/Counter 0> Please confirm OCR0B is given properly
#endif

/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for TC0 initialize */
#if (TC0_WGM0 == 0) || (TC0_WGM0 == 1) || (TC0_WGM0 == 3)
#define TC0_TOP 0xff
#else
#define TC0_TOP TC0_OCR0A 
#endif


static u8 _tccr0b = 0;

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvTC0_Init(void)
 * @brief Initialize TC0 and run. \n
 *	The arguments of this function are macros (TC0_CS0,TC0_WGM0,argCOM0,argOCR0,\n
 *	TC0_TCNT0,argOC0Ena). Before calling you should give the correct value to \n
 *  shese macros according your application
 */
void DrvTC0_Init(void)
{
	/** 1. Stop timer */
	TCCR0B = 0x0;

	/** 2. Force compare match: OC = 1*/
	// The setup of the OC0 should be performed before setting 
	// the Data Direction Register for the port pin to output
	// set OC0 before DDR_oc0 is set
	TCCR0A = (E_COM0_CSET << COM0A0) | E_COM0_CSET << COM0B0;
	// force compare match
	TCCR0B = 0xc0;

	/** 3. Set PIN OC's direction */
#if (TC0_OC0ASEL == 1)
	DDRE |= (1 << PE4);
#else
	DDRD |= (TC0_OC0AEN << PD6);
#endif
	DDRD |= (TC0_OC0BEN << PD5);
	
	/** 4. Initiate TCNT0 */
	TCNT0 = TC0_TCNT0;
	/** 5. Initiate (OCR)output compare register */
	OCR0A = TC0_OCR0A;
	OCR0B = TC0_OCR0B;

	/** 6. Config Interrupt if OCF0 or TOV is enabled */
#if (TC0_OCF0AEN == TRUE) || (TC0_OCF0BEN == TRUE) || (TC0_TOV0EN == TRUE)
	// Clear interrupt flag
	TIFR0 = 7;
	TIMSK0 = TC0_TOV0EN | (TC0_OCF0AEN << 1) | (TC0_OCF0BEN << 2);	
#endif
	/** 7. Initiate TCCR0A and TCCR0B */
	TCCR0A = (TC0_COM0A << COM0A0) | (TC0_COM0B << COM0B0) |\
			((TC0_WGM0 & 0x3) << WGM00);
	TCCR0B = TC0_CS0 | (((TC0_WGM0 & 0x4) >> 2) << WGM02) | (TC0_OC0ASEL << OC0AS);
}

void DrvTC0_Stop(void)
{
	_tccr0b = TCCR0B;
	TCCR0B = 0;
}

void DrvTC0_Restart(void)
{
	TCCR0B = _tccr0b;
}

#if (TC0_PWMAPI == 1)
void TC0_SetOCARatio(u8 ratio)
{
#if (TC0_WGM0 == 2) || (TC0_WGM0 == 4) || (TC0_WGM0 == 5)
#error <E0:Timer/Counter 0> OC0A can not set ratio in selected mode.
#endif
	u16 _ratio = (ratio * TC0_TOP)/100;
	u8 _ocr0a = _ratio & 0xff;
	DrvTC0_SetOCA(_ocr0a);
}

void TC0_SetOCBRatio(u8 ratio)
{
	u16 _ratio = (ratio * TC0_TOP)/100;
	u8 _ocr0b = _ratio & 0xff;
	DrvTC0_SetOCB(_ocr0b);
}
#endif

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/

