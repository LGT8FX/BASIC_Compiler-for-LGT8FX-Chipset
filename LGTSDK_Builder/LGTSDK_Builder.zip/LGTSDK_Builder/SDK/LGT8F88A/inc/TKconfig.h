/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : LGT_TouchQ												    	**
** filename : TKconfig.h  	   	 												**
** version  : 1.0 													   			**
** date     : October 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	LogicGreen techologies									**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: October 01, 2013
Revised by 	: LogicGreen Software Group
Description : Original version.
	This file is an configuration for the TouchQ drive
*/

#ifndef _TKCONFIG_H_
#define _TKCONFIG_H_

#include "global.h"
#include "FSYSCLK.h"

/**********************************************************************************
***					      		MACRO AND DEFINITIONS							***													  	
**********************************************************************************/ 
/*----------------------------------- MCU ---------------------------------------*/
/** define MCU frequency */
#define TK_CFG_MCU_FREQ		(FCLK/1000l)	/**< used by PWM */
#define TK_CFG_INTERNAL		0

/*------------------------------ Touch Key IO -----------------------------------*/
#define TK_CFG_TKX_ENA		(TK_CFG_TK0_ENA | (TK_CFG_TK1_ENA << 1) | (TK_CFG_TK2_ENA << 2) | (TK_CFG_TK3_ENA << 3) | \
							(TK_CFG_TK4_ENA << 4) | (TK_CFG_TK5_ENA << 5) | (TK_CFG_TK6_ENA << 6) | (TK_CFG_TK7_ENA << 7) | \
							(TK_CFG_TK8_ENA << 8) | (TK_CFG_TK9_ENA << 9) | (TK_CFG_TK10_ENA << 10) | (TK_CFG_TK11_ENA << 11))
#define TK_CFG_TKX_NUM		(TK_CFG_TK0_ENA + TK_CFG_TK1_ENA + TK_CFG_TK2_ENA + TK_CFG_TK3_ENA + TK_CFG_TK4_ENA + TK_CFG_TK5_ENA + \
							 TK_CFG_TK6_ENA + TK_CFG_TK7_ENA + TK_CFG_TK8_ENA + TK_CFG_TK9_ENA + TK_CFG_TK10_ENA + TK_CFG_TK11_ENA)

/*------------------------------------- PWM -------------------------------------*/
/** select Timer for PWM, 0:TC0, 1:TC1, 2:TC2 */
#if (TK_CFG_PWM_TYPE == 0) || (TK_CFG_PWM_TYPE == 1)
	#define TK_CFG_PWM_TIMER	0
#elif (TK_CFG_PWM_TYPE == 2) || (TK_CFG_PWM_TYPE == 3)
	#define TK_CFG_PWM_TIMER	1
#elif (TK_CFG_PWM_TYPE == 4) || (TK_CFG_PWM_TYPE == 5)
	#define TK_CFG_PWM_TIMER	2
#endif

/** select OCx, 0: OCA, 1: OCB */
#define TK_CFG_PWM_OCX		((TK_CFG_PWM_TYPE == 0) || (TK_CFG_PWM_TYPE == 2) || (TK_CFG_PWM_TYPE == 4))	
/** select PWM IO */
#define TK_CFG_PWM_OCXPIN	1


/*------------------------------------- ADC -------------------------------------*/
/** Enable ADC */
#define TK_CFG_ADC_ENA				(TK_CFG_SAMPLE_TYPE == 0)
#if (TK_CFG_SAMPLE_TYPE == 0)
#define TK_CFG_KEY_RELATED_TK0		((TK0_RELATED11 << 11) | (TK0_RELATED10 << 10) | (TK0_RELATED9 << 9) | (TK0_RELATED8 << 8) | (TK0_RELATED7 << 7) | \
					(TK0_RELATED6 << 6) | (TK0_RELATED5 << 5) | (TK0_RELATED4 << 4) | (TK0_RELATED3 << 3) | (TK0_RELATED2 << 2) | \
					(TK0_RELATED1 << 1) | TK0_RELATED0)
#define TK_CFG_KEY_MULTI_TK0		((TK0_MULTI11 << 11) | (TK0_MULTI10 << 10) | (TK0_MULTI9 << 9) | (TK0_MULTI8 << 8) | (TK0_MULTI7 << 7) | \
					(TK0_MULTI6 << 6) | (TK0_MULTI5 << 5) | (TK0_MULTI4 << 4) | (TK0_MULTI3 << 3) | (TK0_MULTI2 << 2) | \
					(TK0_MULTI1 << 1) | TK0_MULTI0)

#define TK_CFG_KEY_RELATED_TK1		((TK1_RELATED11 << 11) | (TK1_RELATED10 << 10) | (TK1_RELATED9 << 9) | (TK1_RELATED8 << 8) | (TK1_RELATED7 << 7) | \
					(TK1_RELATED6 << 6) | (TK1_RELATED5 << 5) | (TK1_RELATED4 << 4) | (TK1_RELATED3 << 3) | (TK1_RELATED2 << 2) | \
					(TK1_RELATED1 << 1) | TK1_RELATED0)
#define TK_CFG_KEY_MULTI_TK1		((TK1_MULTI11 << 11) | (TK1_MULTI10 << 10) | (TK1_MULTI9 << 9) | (TK1_MULTI8 << 8) | (TK1_MULTI7 << 7) | \
					(TK1_MULTI6 << 6) | (TK1_MULTI5 << 5) | (TK1_MULTI4 << 4) | (TK1_MULTI3 << 3) | (TK1_MULTI2 << 2) | \
					(TK1_MULTI1 << 1) | TK1_MULTI0)

#define TK_CFG_KEY_RELATED_TK2		((TK2_RELATED11 << 11) | (TK2_RELATED10 << 10) | (TK2_RELATED9 << 9) | (TK2_RELATED8 << 8) | (TK2_RELATED7 << 7) | \
					(TK2_RELATED6 << 6) | (TK2_RELATED5 << 5) | (TK2_RELATED4 << 4) | (TK2_RELATED3 << 3) | (TK2_RELATED2 << 2) | \
					(TK2_RELATED1 << 1) | TK2_RELATED0)
#define TK_CFG_KEY_MULTI_TK2		((TK2_MULTI11 << 11) | (TK2_MULTI10 << 10) | (TK2_MULTI9 << 9) | (TK2_MULTI8 << 8) | (TK2_MULTI7 << 7) | \
					(TK2_MULTI6 << 6) | (TK2_MULTI5 << 5) | (TK2_MULTI4 << 4) | (TK2_MULTI3 << 3) | (TK2_MULTI2 << 2) | \
					(TK2_MULTI1 << 1) | TK2_MULTI0)

#define TK_CFG_KEY_RELATED_TK3		((TK3_RELATED11 << 11) | (TK3_RELATED10 << 10) | (TK3_RELATED9 << 9) | (TK3_RELATED8 << 8) | (TK3_RELATED7 << 7) | \
					(TK3_RELATED6 << 6) | (TK3_RELATED5 << 5) | (TK3_RELATED4 << 4) | (TK3_RELATED3 << 3) | (TK3_RELATED2 << 2) | \
					(TK3_RELATED1 << 1) | TK3_RELATED0)
#define TK_CFG_KEY_MULTI_TK3		((TK3_MULTI11 << 11) | (TK3_MULTI10 << 10) | (TK3_MULTI9 << 9) | (TK3_MULTI8 << 8) | (TK3_MULTI7 << 7) | \
					(TK3_MULTI6 << 6) | (TK3_MULTI5 << 5) | (TK3_MULTI4 << 4) | (TK3_MULTI3 << 3) | (TK3_MULTI2 << 2) | \
					(TK3_MULTI1 << 1) | TK3_MULTI0)

#define TK_CFG_KEY_RELATED_TK4		((TK4_RELATED11 << 11) | (TK4_RELATED10 << 10) | (TK4_RELATED9 << 9) | (TK4_RELATED8 << 8) | (TK4_RELATED7 << 7) | \
					(TK4_RELATED6 << 6) | (TK4_RELATED5 << 5) | (TK4_RELATED4 << 4) | (TK4_RELATED3 << 3) | (TK4_RELATED2 << 2) | \
					(TK4_RELATED1 << 1) | TK4_RELATED0)
#define TK_CFG_KEY_MULTI_TK4		((TK4_MULTI11 << 11) | (TK4_MULTI10 << 10) | (TK4_MULTI9 << 9) | (TK4_MULTI8 << 8) | (TK4_MULTI7 << 7) | \
					(TK4_MULTI6 << 6) | (TK4_MULTI5 << 5) | (TK4_MULTI4 << 4) | (TK4_MULTI3 << 3) | (TK4_MULTI2 << 2) | \
					(TK4_MULTI1 << 1) | TK4_MULTI0)

#define TK_CFG_KEY_RELATED_TK5		((TK5_RELATED11 << 11) | (TK5_RELATED10 << 10) | (TK5_RELATED9 << 9) | (TK5_RELATED8 << 8) | (TK5_RELATED7 << 7) | \
					(TK5_RELATED6 << 6) | (TK5_RELATED5 << 5) | (TK5_RELATED4 << 4) | (TK5_RELATED3 << 3) | (TK5_RELATED2 << 2) | \
					(TK5_RELATED1 << 1) | TK5_RELATED0)
#define TK_CFG_KEY_MULTI_TK5		((TK5_MULTI11 << 11) | (TK5_MULTI10 << 10) | (TK5_MULTI9 << 9) | (TK5_MULTI8 << 8) | (TK5_MULTI7 << 7) | \
					(TK5_MULTI6 << 6) | (TK5_MULTI5 << 5) | (TK5_MULTI4 << 4) | (TK5_MULTI3 << 3) | (TK5_MULTI2 << 2) | \
					(TK5_MULTI1 << 1) | TK5_MULTI0)

#define TK_CFG_KEY_RELATED_TK6		((TK6_RELATED11 << 11) | (TK6_RELATED10 << 10) | (TK6_RELATED9 << 9) | (TK6_RELATED8 << 8) | (TK6_RELATED7 << 7) | \
					(TK6_RELATED6 << 6) | (TK6_RELATED5 << 5) | (TK6_RELATED4 << 4) | (TK6_RELATED3 << 3) | (TK6_RELATED2 << 2) | \
					(TK6_RELATED1 << 1) | TK6_RELATED0)
#define TK_CFG_KEY_MULTI_TK6		((TK6_MULTI11 << 11) | (TK6_MULTI10 << 10) | (TK6_MULTI9 << 9) | (TK6_MULTI8 << 8) | (TK6_MULTI7 << 7) | \
					(TK6_MULTI6 << 6) | (TK6_MULTI5 << 5) | (TK6_MULTI4 << 4) | (TK6_MULTI3 << 3) | (TK6_MULTI2 << 2) | \
					(TK6_MULTI1 << 1) | TK6_MULTI0)

#define TK_CFG_KEY_RELATED_TK7		((TK7_RELATED11 << 11) | (TK7_RELATED10 << 10) | (TK7_RELATED9 << 9) | (TK7_RELATED8 << 8) | (TK7_RELATED7 << 7) | \
					(TK7_RELATED6 << 6) | (TK7_RELATED5 << 5) | (TK7_RELATED4 << 4) | (TK7_RELATED3 << 3) | (TK7_RELATED2 << 2) | \
					(TK7_RELATED1 << 1) | TK7_RELATED0)
#define TK_CFG_KEY_MULTI_TK7		((TK7_MULTI11 << 11) | (TK7_MULTI10 << 10) | (TK7_MULTI9 << 9) | (TK7_MULTI8 << 8) | (TK7_MULTI7 << 7) | \
					(TK7_MULTI6 << 6) | (TK7_MULTI5 << 5) | (TK7_MULTI4 << 4) | (TK7_MULTI3 << 3) | (TK7_MULTI2 << 2) | \
					(TK7_MULTI1 << 1) | TK7_MULTI0)

#define TK_CFG_KEY_RELATED_TK8		((TK8_RELATED11 << 11) | (TK8_RELATED10 << 10) | (TK8_RELATED9 << 9) | (TK8_RELATED8 << 8) | (TK8_RELATED7 << 7) | \
					(TK8_RELATED6 << 6) | (TK8_RELATED5 << 5) | (TK8_RELATED4 << 4) | (TK8_RELATED3 << 3) | (TK8_RELATED2 << 2) | \
					(TK8_RELATED1 << 1) | TK8_RELATED0)
#define TK_CFG_KEY_MULTI_TK8		((TK8_MULTI11 << 11) | (TK8_MULTI10 << 10) | (TK8_MULTI9 << 9) | (TK8_MULTI8 << 8) | (TK8_MULTI7 << 7) | \
					(TK8_MULTI6 << 6) | (TK8_MULTI5 << 5) | (TK8_MULTI4 << 4) | (TK8_MULTI3 << 3) | (TK8_MULTI2 << 2) | \
					(TK8_MULTI1 << 1) | TK8_MULTI0)

#define TK_CFG_KEY_RELATED_TK9		((TK9_RELATED11 << 11) | (TK9_RELATED10 << 10) | (TK9_RELATED9 << 9) | (TK9_RELATED8 << 8) | (TK9_RELATED7 << 7) | \
					(TK9_RELATED6 << 6) | (TK9_RELATED5 << 5) | (TK9_RELATED4 << 4) | (TK9_RELATED3 << 3) | (TK9_RELATED2 << 2) | \
					(TK9_RELATED1 << 1) | TK9_RELATED0)
#define TK_CFG_KEY_MULTI_TK9		((TK9_MULTI11 << 11) | (TK9_MULTI10 << 10) | (TK9_MULTI9 << 9) | (TK9_MULTI8 << 8) | (TK9_MULTI7 << 7) | \
					(TK9_MULTI6 << 6) | (TK9_MULTI5 << 5) | (TK9_MULTI4 << 4) | (TK9_MULTI3 << 3) | (TK9_MULTI2 << 2) | \
					(TK9_MULTI1 << 1) | TK9_MULTI0)

#define TK_CFG_KEY_RELATED_TK10		((TK10_RELATED11 << 11) | (TK10_RELATED10 << 10) | (TK10_RELATED9 << 9) | (TK10_RELATED8 << 8) | (TK10_RELATED7 << 7) | \
					(TK10_RELATED6 << 6) | (TK10_RELATED5 << 5) | (TK10_RELATED4 << 4) | (TK10_RELATED3 << 3) | (TK10_RELATED2 << 2) | \
					(TK10_RELATED1 << 1) | TK10_RELATED0)
#define TK_CFG_KEY_MULTI_TK10		((TK10_MULTI11 << 11) | (TK10_MULTI10 << 10) | (TK10_MULTI9 << 9) | (TK0_MULTI8 << 8) | (TK10_MULTI7 << 7) | \
					(TK10_MULTI6 << 6) | (TK10_MULTI5 << 5) | (TK0_MULTI4 << 4) | (TK0_MULTI3 << 3) | (TK10_MULTI2 << 2) | \
					(TK10_MULTI1 << 1) | TK10_MULTI0)

#define TK_CFG_KEY_RELATED_TK11		((TK11_RELATED11 << 11) | (TK11_RELATED10 << 10) | (TK11_RELATED9 << 9) | (TK11_RELATED8 << 8) | (TK11_RELATED7 << 7) | \
					(TK11_RELATED6 << 6) | (TK11_RELATED5 << 5) | (TK11_RELATED4 << 4) | (TK11_RELATED3 << 3) | (TK11_RELATED2 << 2) | \
					(TK11_RELATED1 << 1) | TK11_RELATED0)
#define TK_CFG_KEY_MULTI_TK11		((TK11_MULTI11 << 11) | (TK11_MULTI10 << 10) | (TK11_MULTI9 << 9) | (TK11_MULTI8 << 8) | (TK11_MULTI7 << 7) | \
					(TK11_MULTI6 << 6) | (TK11_MULTI5 << 5) | (TK11_MULTI4 << 4) | (TK11_MULTI3 << 3) | (TK11_MULTI2 << 2) | \
					(TK11_MULTI1 << 1) | TK11_MULTI0)
#endif

/*------------------------------------- AC --------------------------------------*/
/** Enable AC */
#define TK_CFG_AC_ENA		(TK_CFG_SAMPLE_TYPE == 1)	
#if(TK_CFG_SAMPLE_TYPE == 1)
/*------------------------------------- CAPTURE ---------------------------------*/
/** Enable CAPTURE */
#define TK_CFG_ICP_ENA		1

#define TK_CFG_KEY_RELATED_TK0		((TK0_RELATED11 << 11) | (TK0_RELATED10 << 10) | (TK0_RELATED9 << 9) | (TK0_RELATED8 << 8) | (TK0_RELATED7 << 7) | \
					(TK0_RELATED6 << 6) | (TK0_RELATED5 << 5) | (TK0_RELATED4 << 4) | (TK0_RELATED3 << 3) | (TK0_RELATED2 << 2) | \
					(TK0_RELATED1 << 1) | TK0_RELATED0)
#define TK_CFG_KEY_MULTI_TK0		((TK0_MULTI11 << 11) | (TK0_MULTI10 << 10) | (TK0_MULTI9 << 9) | (TK0_MULTI8 << 8) | (TK0_MULTI7 << 7) | \
					(TK0_MULTI6 << 6) | (TK0_MULTI5 << 5) | (TK0_MULTI4 << 4) | (TK0_MULTI3 << 3) | (TK0_MULTI2 << 2) | \
					(TK0_MULTI1 << 1) | TK0_MULTI0)

#define TK_CFG_KEY_RELATED_TK1		((TK1_RELATED11 << 11) | (TK1_RELATED10 << 10) | (TK1_RELATED9 << 9) | (TK1_RELATED8 << 8) | (TK1_RELATED7 << 7) | \
					(TK1_RELATED6 << 6) | (TK1_RELATED5 << 5) | (TK1_RELATED4 << 4) | (TK1_RELATED3 << 3) | (TK1_RELATED2 << 2) | \
					(TK1_RELATED1 << 1) | TK1_RELATED0)
#define TK_CFG_KEY_MULTI_TK1		((TK1_MULTI11 << 11) | (TK1_MULTI10 << 10) | (TK1_MULTI9 << 9) | (TK1_MULTI8 << 8) | (TK1_MULTI7 << 7) | \
					(TK1_MULTI6 << 6) | (TK1_MULTI5 << 5) | (TK1_MULTI4 << 4) | (TK1_MULTI3 << 3) | (TK1_MULTI2 << 2) | \
					(TK1_MULTI1 << 1) | TK1_MULTI0)

#define TK_CFG_KEY_RELATED_TK2		((TK2_RELATED11 << 11) | (TK2_RELATED10 << 10) | (TK2_RELATED9 << 9) | (TK2_RELATED8 << 8) | (TK2_RELATED7 << 7) | \
					(TK2_RELATED6 << 6) | (TK2_RELATED5 << 5) | (TK2_RELATED4 << 4) | (TK2_RELATED3 << 3) | (TK2_RELATED2 << 2) | \
					(TK2_RELATED1 << 1) | TK2_RELATED0)
#define TK_CFG_KEY_MULTI_TK2		((TK2_MULTI11 << 11) | (TK2_MULTI10 << 10) | (TK2_MULTI9 << 9) | (TK2_MULTI8 << 8) | (TK2_MULTI7 << 7) | \
					(TK2_MULTI6 << 6) | (TK2_MULTI5 << 5) | (TK2_MULTI4 << 4) | (TK2_MULTI3 << 3) | (TK2_MULTI2 << 2) | \
					(TK2_MULTI1 << 1) | TK2_MULTI0)

#define TK_CFG_KEY_RELATED_TK3		((TK3_RELATED11 << 11) | (TK3_RELATED10 << 10) | (TK3_RELATED9 << 9) | (TK3_RELATED8 << 8) | (TK3_RELATED7 << 7) | \
					(TK3_RELATED6 << 6) | (TK3_RELATED5 << 5) | (TK3_RELATED4 << 4) | (TK3_RELATED3 << 3) | (TK3_RELATED2 << 2) | \
					(TK3_RELATED1 << 1) | TK3_RELATED0)
#define TK_CFG_KEY_MULTI_TK3		((TK3_MULTI11 << 11) | (TK3_MULTI10 << 10) | (TK3_MULTI9 << 9) | (TK3_MULTI8 << 8) | (TK3_MULTI7 << 7) | \
					(TK3_MULTI6 << 6) | (TK3_MULTI5 << 5) | (TK3_MULTI4 << 4) | (TK3_MULTI3 << 3) | (TK3_MULTI2 << 2) | \
					(TK3_MULTI1 << 1) | TK3_MULTI0)

#define TK_CFG_KEY_RELATED_TK4		((TK4_RELATED11 << 11) | (TK4_RELATED10 << 10) | (TK4_RELATED9 << 9) | (TK4_RELATED8 << 8) | (TK4_RELATED7 << 7) | \
					(TK4_RELATED6 << 6) | (TK4_RELATED5 << 5) | (TK4_RELATED4 << 4) | (TK4_RELATED3 << 3) | (TK4_RELATED2 << 2) | \
					(TK4_RELATED1 << 1) | TK4_RELATED0)
#define TK_CFG_KEY_MULTI_TK4		((TK4_MULTI11 << 11) | (TK4_MULTI10 << 10) | (TK4_MULTI9 << 9) | (TK4_MULTI8 << 8) | (TK4_MULTI7 << 7) | \
					(TK4_MULTI6 << 6) | (TK4_MULTI5 << 5) | (TK4_MULTI4 << 4) | (TK4_MULTI3 << 3) | (TK4_MULTI2 << 2) | \
					(TK4_MULTI1 << 1) | TK4_MULTI0)

#define TK_CFG_KEY_RELATED_TK5		((TK5_RELATED11 << 11) | (TK5_RELATED10 << 10) | (TK5_RELATED9 << 9) | (TK5_RELATED8 << 8) | (TK5_RELATED7 << 7) | \
					(TK5_RELATED6 << 6) | (TK5_RELATED5 << 5) | (TK5_RELATED4 << 4) | (TK5_RELATED3 << 3) | (TK5_RELATED2 << 2) | \
					(TK5_RELATED1 << 1) | TK5_RELATED0)
#define TK_CFG_KEY_MULTI_TK5		((TK5_MULTI11 << 11) | (TK5_MULTI10 << 10) | (TK5_MULTI9 << 9) | (TK5_MULTI8 << 8) | (TK5_MULTI7 << 7) | \
					(TK5_MULTI6 << 6) | (TK5_MULTI5 << 5) | (TK5_MULTI4 << 4) | (TK5_MULTI3 << 3) | (TK5_MULTI2 << 2) | \
					(TK5_MULTI1 << 1) | TK5_MULTI0)

#define TK_CFG_KEY_RELATED_TK6		((TK6_RELATED11 << 11) | (TK6_RELATED10 << 10) | (TK6_RELATED9 << 9) | (TK6_RELATED8 << 8) | (TK6_RELATED7 << 7) | \
					(TK6_RELATED6 << 6) | (TK6_RELATED5 << 5) | (TK6_RELATED4 << 4) | (TK6_RELATED3 << 3) | (TK6_RELATED2 << 2) | \
					(TK6_RELATED1 << 1) | TK6_RELATED0)
#define TK_CFG_KEY_MULTI_TK6		((TK6_MULTI11 << 11) | (TK6_MULTI10 << 10) | (TK6_MULTI9 << 9) | (TK6_MULTI8 << 8) | (TK6_MULTI7 << 7) | \
					(TK6_MULTI6 << 6) | (TK6_MULTI5 << 5) | (TK6_MULTI4 << 4) | (TK6_MULTI3 << 3) | (TK6_MULTI2 << 2) | \
					(TK6_MULTI1 << 1) | TK6_MULTI0)

#define TK_CFG_KEY_RELATED_TK7		((TK7_RELATED11 << 11) | (TK7_RELATED10 << 10) | (TK7_RELATED9 << 9) | (TK7_RELATED8 << 8) | (TK7_RELATED7 << 7) | \
					(TK7_RELATED6 << 6) | (TK7_RELATED5 << 5) | (TK7_RELATED4 << 4) | (TK7_RELATED3 << 3) | (TK7_RELATED2 << 2) | \
					(TK7_RELATED1 << 1) | TK7_RELATED0)
#define TK_CFG_KEY_MULTI_TK7		((TK7_MULTI11 << 11) | (TK7_MULTI10 << 10) | (TK7_MULTI9 << 9) | (TK7_MULTI8 << 8) | (TK7_MULTI7 << 7) | \
					(TK7_MULTI6 << 6) | (TK7_MULTI5 << 5) | (TK7_MULTI4 << 4) | (TK7_MULTI3 << 3) | (TK7_MULTI2 << 2) | \
					(TK7_MULTI1 << 1) | TK7_MULTI0)

#define TK_CFG_KEY_RELATED_TK8		((TK8_RELATED11 << 11) | (TK8_RELATED10 << 10) | (TK8_RELATED9 << 9) | (TK8_RELATED8 << 8) | (TK8_RELATED7 << 7) | \
					(TK8_RELATED6 << 6) | (TK8_RELATED5 << 5) | (TK8_RELATED4 << 4) | (TK8_RELATED3 << 3) | (TK8_RELATED2 << 2) | \
					(TK8_RELATED1 << 1) | TK8_RELATED0)
#define TK_CFG_KEY_MULTI_TK8		((TK8_MULTI11 << 11) | (TK8_MULTI10 << 10) | (TK8_MULTI9 << 9) | (TK8_MULTI8 << 8) | (TK8_MULTI7 << 7) | \
					(TK8_MULTI6 << 6) | (TK8_MULTI5 << 5) | (TK8_MULTI4 << 4) | (TK8_MULTI3 << 3) | (TK8_MULTI2 << 2) | \
					(TK8_MULTI1 << 1) | TK8_MULTI0)

#define TK_CFG_KEY_RELATED_TK9		((TK9_RELATED11 << 11) | (TK9_RELATED10 << 10) | (TK9_RELATED9 << 9) | (TK9_RELATED8 << 8) | (TK9_RELATED7 << 7) | \
					(TK9_RELATED6 << 6) | (TK9_RELATED5 << 5) | (TK9_RELATED4 << 4) | (TK9_RELATED3 << 3) | (TK9_RELATED2 << 2) | \
					(TK9_RELATED1 << 1) | TK9_RELATED0)
#define TK_CFG_KEY_MULTI_TK9		((TK9_MULTI11 << 11) | (TK9_MULTI10 << 10) | (TK9_MULTI9 << 9) | (TK9_MULTI8 << 8) | (TK9_MULTI7 << 7) | \
					(TK9_MULTI6 << 6) | (TK9_MULTI5 << 5) | (TK9_MULTI4 << 4) | (TK9_MULTI3 << 3) | (TK9_MULTI2 << 2) | \
					(TK9_MULTI1 << 1) | TK9_MULTI0)

#define TK_CFG_KEY_RELATED_TK10		((TK10_RELATED11 << 11) | (TK10_RELATED10 << 10) | (TK10_RELATED9 << 9) | (TK10_RELATED8 << 8) | (TK10_RELATED7 << 7) | \
					(TK10_RELATED6 << 6) | (TK10_RELATED5 << 5) | (TK10_RELATED4 << 4) | (TK10_RELATED3 << 3) | (TK10_RELATED2 << 2) | \
					(TK10_RELATED1 << 1) | TK10_RELATED0)
#define TK_CFG_KEY_MULTI_TK10		((TK10_MULTI11 << 11) | (TK10_MULTI10 << 10) | (TK10_MULTI9 << 9) | (TK0_MULTI8 << 8) | (TK10_MULTI7 << 7) | \
					(TK10_MULTI6 << 6) | (TK10_MULTI5 << 5) | (TK0_MULTI4 << 4) | (TK0_MULTI3 << 3) | (TK10_MULTI2 << 2) | \
					(TK10_MULTI1 << 1) | TK10_MULTI0)

#define TK_CFG_KEY_RELATED_TK11		((TK11_RELATED11 << 11) | (TK11_RELATED10 << 10) | (TK11_RELATED9 << 9) | (TK11_RELATED8 << 8) | (TK11_RELATED7 << 7) | \
					(TK11_RELATED6 << 6) | (TK11_RELATED5 << 5) | (TK11_RELATED4 << 4) | (TK11_RELATED3 << 3) | (TK11_RELATED2 << 2) | \
					(TK11_RELATED1 << 1) | TK11_RELATED0)
#define TK_CFG_KEY_MULTI_TK11		((TK11_MULTI11 << 11) | (TK11_MULTI10 << 10) | (TK11_MULTI9 << 9) | (TK11_MULTI8 << 8) | (TK11_MULTI7 << 7) | \
					(TK11_MULTI6 << 6) | (TK11_MULTI5 << 5) | (TK11_MULTI4 << 4) | (TK11_MULTI3 << 3) | (TK11_MULTI2 << 2) | \
					(TK11_MULTI1 << 1) | TK11_MULTI0)
#endif


/*------------------------------------- OTHER -----------------------------------*/
#define TK_CFG_KEY_SEQ		0			/**< key sequencing: 1: order from 88A's datasheet 0: scan sequence*/ 

typedef struct
{
	unsigned int	u16KeyPress;
	unsigned int	u16KeyRelease;
	unsigned int	u16KeyCalib;
	unsigned int	u16KeyRelated;
	unsigned int	u16KeyMulti;
}STR_CHN_CFG;

#endif

/**********************************************************************************
***					      				EOF										***													  	
**********************************************************************************/ 

