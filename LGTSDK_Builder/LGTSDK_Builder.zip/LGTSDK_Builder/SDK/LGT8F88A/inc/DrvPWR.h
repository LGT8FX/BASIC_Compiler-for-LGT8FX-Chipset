/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A													    **
** filename : DrvPWR.h	 	 	   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	LogicGreen techologies									**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

#ifndef _DrvPWR_H_
#define _DrvPWR_H_

/**********************************************************************************
***					            	MODULES USED								***													  	
**********************************************************************************/  
#include "global.h"

/**********************************************************************************
***					          	  MACRO AND DEFINTION							***													  	
**********************************************************************************/ 
#define PRR_ADC		0x0001
#define PRR_USART0	0x0002
#define PRR_SPI		0x0004
#define PRR_TIM1	0x0008
#define PRR_TIM0	0x0020
#define PRR_TIM2	0x0040
#define PRR_TWI		0x0080

#define PRR_PCI		0x0200
#define PRR_EFL		0x0400
#define PRR_WDT		0x2000

#define PRR10	(*(volatile u16*)0x0064)

#define DrvPWR_ModuleEnable(ID) do { PRR10 &= ~ID; } while(0)
#define DrvPWR_ModuleDisable(ID) do { PRR10 |= ID; } while(0)

#define DRVPWR_PWROFF_LOCK() do {SMCR = 0x8;} while(0)

/**********************************************************************************
***					            TYPEDEF AND STRUCTURE							***													  	
**********************************************************************************/
/**
 * @enum emSmod
 *	Sleep Mode
 */

/**
 * @typedef typedef enum emSmode EMSMODE
 */
typedef enum emSmod
{
	E_SLEEP_IDLE,			/**< idle mode */
	E_SLEEP_ADCNRM,			/**< ADC Noise Reduction mode */
	E_SLEEP_PWRDOWN, 		/**< power down mode */
	E_SLEEP_PWROFF, 		/**< power off mode */
}EMSMODE;

/**********************************************************************************
***					            	EXPORTED FUNCTIONS							***													  	
**********************************************************************************/ 
void DrvPWR_Init(void);
void DrvPWR_Sleep(EMSMODE emSMode);

#endif
/**********************************************************************************
***					            		EOF										***													  	
**********************************************************************************/  
