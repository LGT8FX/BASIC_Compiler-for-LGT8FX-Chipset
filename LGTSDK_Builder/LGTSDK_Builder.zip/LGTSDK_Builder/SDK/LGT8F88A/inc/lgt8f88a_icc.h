#ifndef __LGT8F88A_ICC_H
#define __LGT8F88A_ICC_H

#include "global.h"
#include "lgt8f88a_bit.h"

/* Interrupter vector */
#define LGT_VECTOR_S_IVN_EXINT0		"interrupt_handler __vector_1:2"
#define LGT_VECTOR_S_IVN_EXINT1		"interrupt_handler __vector_2:3"
#define LGT_VECTOR_S_IVN_PCINT0		"interrupt_handler __vector_3:4"
#define LGT_VECTOR_S_IVN_PCINT1		"interrupt_handler __vector_4:5"
#define LGT_VECTOR_S_IVN_PCINT2		"interrupt_handler __vector_5:6"
#define LGT_VECTOR_S_IVN_WDT		"interrupt_handler __vector_6:7"
#define LGT_VECTOR_S_IVN_TC2_OCA	"interrupt_handler __vector_7:8"
#define LGT_VECTOR_S_IVN_TC2_OCB	"interrupt_handler __vector_8:9"
#define LGT_VECTOR_S_IVN_TC2_TOV	"interrupt_handler __vector_9:10"
#define LGT_VECTOR_S_IVN_TC1_ICP	"interrupt_handler __vector_10:11"
#define LGT_VECTOR_S_IVN_TC1_OCA	"interrupt_handler __vector_11:12"
#define LGT_VECTOR_S_IVN_TC1_OCB	"interrupt_handler __vector_12:13"
#define LGT_VECTOR_S_IVN_TC1_TOV	"interrupt_handler __vector_13:14"
#define LGT_VECTOR_S_IVN_TC0_OCA	"interrupt_handler __vector_14:15"
#define LGT_VECTOR_S_IVN_TC0_OCB	"interrupt_handler __vector_15:16"
#define LGT_VECTOR_S_IVN_TC0_TOV	"interrupt_handler __vector_16:17"
#define LGT_VECTOR_S_IVN_SPI_STC	"interrupt_handler __vector_17:18"
#define LGT_VECTOR_S_IVN_RXC		"interrupt_handler __vector_18:19"
#define LGT_VECTOR_S_IVN_UDR		"interrupt_handler __vector_19:20"
#define LGT_VECTOR_S_IVN_TXC		"interrupt_handler __vector_20:21"
#define LGT_VECTOR_S_IVN_ADC		"interrupt_handler __vector_21:22"
#define LGT_VECTOR_S_IVN_EE_RDY		"interrupt_handler __vector_22:23"
#define LGT_VECTOR_S_IVN_ACP		"interrupt_handler __vector_23:24"
#define LGT_VECTOR_S_IVN_TWI		"interrupt_handler __vector_24:25"
#define LGT_VECTOR_S_IVN_PCINT3		"interrupt_handler __vector_27:28"

#define L_VECTOR(N)	__vector_##N

#define LGT_VECTOR(NAME) \
_Pragma (LGT_VECTOR_S_##NAME)  void NAME (void)

/** compiler relative macros */
#define SEI() asm("sei")
#define CLI() asm("cli")
#define SLEEP() asm("sleep")
#define WDR() asm("wdr")
#define NOP() asm("nop")
#define __ASM asm

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
#define Compiler_SetClk() do { \
	__ASM("lds 	r20, 0xf2"); \
	__ASM("andi	r20, 0x70"); \
	__ASM("ori	r20, 0x80"); \
	__ASM("or	r16, r20"); \
	__ASM("sts	0xf2, r16"); \
	__ASM("sts	0xf2, r16"); \
	} while(0)

#define Compiler_SetMclk() do { \
	__ASM("lds 	r20, 0xf2"); \
	__ASM("andi	r20, 0x1f"); \
	__ASM("ori	r20, 0x80"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("or	r16, r20"); \
	__ASM("sts	0xf2, r16"); \
	__ASM("sts	0xf2, r16"); \
	} while(0)

#define Compiler_SetClkDiv() do { \
	__ASM("lds 	r20, 0x61"); \
	__ASM("andi	r20, 0x60"); \
	__ASM("ori	r20, 0x80"); \
	__ASM("or	r16, r20"); \
	__ASM("sts	0x61, r16"); \
	__ASM("sts	0x61, r16"); \
	} while(0)

#define Compiler_SetWclk() do { \
	__ASM("lds 	r20, 0xf2"); \
	__ASM("andi	r20, 0x6f"); \
	__ASM("ori	r20, 0x80"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("lsl	r16"); \
	__ASM("or	r16, r20"); \
	__ASM("sts	0xf2, r16"); \
	__ASM("sts	0xf2, r16"); \
	} while(0)

#define Compiler_SetWDT() do { \
	__ASM("mov	r17, r16"); \
	__ASM("ori	r17, 0x08"); \
	__ASM("sts	0x60, r17"); \
	__ASM("sts	0x60, r16"); \
	} while(0)


#define Compiler_LPMReadWord() do { \
	__ASM("mov 	r30, r16"); \
	__ASM("mov 	r31, r17"); \
	__ASM("lpm	r16, z+"); \
	__ASM("lpm	r17, z"); \
	__ASM("mov	r30, r18"); \
	__ASM("mov	r31, r19"); \
	__ASM("st	z+, r16"); \
	__ASM("st	z, r17"); \
	} while(0)
    
#endif
