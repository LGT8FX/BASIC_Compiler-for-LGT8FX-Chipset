/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : LGT_TouchQ												    	**
** filename : TKreg.h  	   	 													**
** version  : 1.0 													   			**
** date     : October 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	LogicGreen techologies									**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: October 01, 2013
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

#ifndef _TKREG_H_
#define _TKREG_H_
/**********************************************************************************
***					      		MACRO AND DEFINITIONS							***													  	
**********************************************************************************/ 
/** Touch Key Control Register */
#define TK_TKCR		(*(volatile unsigned char *)0xcd)
#define TK_TKMUX	0
#define TK_TKSSEL	4
#define TK_PD		7

/** Digital I/O Disable Register */
#define TK_DIDR0	(*(volatile unsigned char *)0x7e)
#define TK_DIDR1	(*(volatile unsigned char *)0x7f)
#define TK_DIDR2	(*(volatile unsigned char *)0xce)
#define TK_DIDR20	0
#define TK_DIDR21	1
#define TK_DIDR22	2
#define TK_DIDR23	3
#define TK_DIDR24	4
#define TK_DIDR25	5
#define TK_DIDR26	6
#define TK_DIDR27	7
#define TK_DIDR3	(*(volatile unsigned char *)0xcf)
#define TK_DIDR30	0
#define TK_DIDR31	1
#define TK_DIDR32	2
#define TK_DIDR33	3

/** TC0 Register*/
#define TK_TCCR0A	(*(volatile unsigned char *)0x44)
#define TK_TCCR0B	(*(volatile unsigned char *)0x45)
#define TK_TCNT0	(*(volatile unsigned char *)0x46)
#define TK_OCR0A	(*(volatile unsigned char *)0x47)
#define TK_OCR0B	(*(volatile unsigned char *)0x48)
#define TK_TIMSK0   (*(volatile unsigned char *)0x6e)

/** TC1 Register */
#define TK_TCCR1A 	(*(volatile unsigned char *)0x80)
#define TK_TCCR1B 	(*(volatile unsigned char *)0x81)
#define TK_TCCR1C 	(*(volatile unsigned char *)0x82)
#define TK_TCNT1L 	(*(volatile unsigned char *)0x84)
#define TK_TCNT1H 	(*(volatile unsigned char *)0x85)
#define TK_ICR1L 	(*(volatile unsigned char *)0x86)
#define TK_ICR1H 	(*(volatile unsigned char *)0x87)
#define TK_OCR1AL 	(*(volatile unsigned char *)0x88)
#define TK_OCR1AH 	(*(volatile unsigned char *)0x89)
#define TK_OCR1BL 	(*(volatile unsigned char *)0x8a)
#define TK_OCR1BH 	(*(volatile unsigned char *)0x8b)
#define TK_TIFR1	(*(volatile unsigned char *)0x36)
#define TK_TIMSK1	(*(volatile unsigned char *)0x6f)

/** TC2 Register */
#define TK_TCCR2A	(*(volatile unsigned char *)0xb0)
#define TK_TCCR2B	(*(volatile unsigned char *)0xb1)
#define TK_TCNT2	(*(volatile unsigned char *)0xb2)
#define TK_OCR2A	(*(volatile unsigned char *)0xb3)
#define TK_OCR2B	(*(volatile unsigned char *)0xb4)
#define TK_ASSR		(*(volatile unsigned char *)0xb6)
#define TK_TIFR2	(*(volatile unsigned char *)0x37)
#define TK_TIMSK2	(*(volatile unsigned char *)0x70)

/** GPIO */
#define TK_PINB		(*(volatile unsigned char *)0x23)
#define TK_DDRB		(*(volatile unsigned char *)0x24)
#define TK_PORTB	(*(volatile unsigned char *)0x25)
#define TK_PINC		(*(volatile unsigned char *)0x26)
#define TK_DDRC		(*(volatile unsigned char *)0x27)
#define TK_PORTC	(*(volatile unsigned char *)0x28)
#define TK_PIND		(*(volatile unsigned char *)0x29)
#define TK_DDRD		(*(volatile unsigned char *)0x2a)
#define TK_PORTD	(*(volatile unsigned char *)0x2b)
#define TK_PINE		(*(volatile unsigned char *)0xa7)
#define TK_DDRE		(*(volatile unsigned char *)0xa8)
#define TK_PORTE	(*(volatile unsigned char *)0xa9)

/** ADC Register */
#define TK_ADCL		(*(volatile unsigned char *)0x78)
#define TK_ADCH		(*(volatile unsigned char *)0x79)
#define TK_ADCSRA	(*(volatile unsigned char *)0x7a)
#define TK_ADCSRB	(*(volatile unsigned char *)0x7b)
#define TK_ADMUX	(*(volatile unsigned char *)0x7c)
#define TK_ADTMU	(*(volatile unsigned char *)0x7d)

#define TK_SREG		(*(volatile unsigned char *)0x5f)

#define TK_DSCR		(*(volatile unsigned char *)0xF1)
#define TK_IOCR		(*(volatile unsigned char *)0xF0)

/** AC Register */
#define TK_ACSR 	(*(volatile unsigned char *)0x50)
#endif
/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/ 

