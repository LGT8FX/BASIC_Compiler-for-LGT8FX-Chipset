/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : LGT_TouchQ												    	**
** filename : TKdev.h  	   	 													**
** version  : 1.0 													   			**
** date     : October 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	LogicGreen techologies									**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: October 01, 2013
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

#ifndef _TKDEV_H_
#define _TKDEV_H_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/
#include "TKconfig.h"
#include "TKreg.h"


#if (TK_CFG_AC_ENA == 1)
#define TK_AC_START()	do{TK_ACSR = (TK_ACSR & 0x5f);} while(0)
#define TK_AC_STOP()	do{TK_ACSR = (TK_ACSR & 0xdf) | 0x80;} while(0)
#endif

/**********************************************************************************
***					        EXPORTED VARIABLES									***													  	
**********************************************************************************/
#ifndef _TKDEV_SRC_C_
extern unsigned int 	g_u16TKRefVal[TK_CFG_TKX_NUM];
extern unsigned int 	g_u16TKCurVal[TK_CFG_TKX_NUM];
extern unsigned long	g_u32TKCurValSum[TK_CFG_TKX_NUM];
extern unsigned int		g_u16CalibTime;
#endif

/**********************************************************************************
***					        EXPORTED FUNCTIONS									***													  	
**********************************************************************************/
void 			TK_Open(void);
unsigned int 	TK_Key(void);
unsigned int	TK_Test(void);

#endif
/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/ 

