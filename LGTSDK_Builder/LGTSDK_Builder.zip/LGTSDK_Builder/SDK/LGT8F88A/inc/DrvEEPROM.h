/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F88A												    	**
** filename : DrvEEPROM.h  	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvEEPROM.h
 * @brief Header File of Internal EEPROM Contorller 
 *		
 */

#ifndef _DrvEEPROM_H_
#define _DrvEEPROM_H_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/

/**********************************************************************************
***					         MACROS AND DEFINITIONS								***													  	
**********************************************************************************/  

/**********************************************************************************
***					           TYPEDEF AND STRUCTURES							***													  	
**********************************************************************************/
/** 
 * @enum emEepm 
 * 	EEPROM(Flash) Promgramme Mode 
 */
enum emEepm
{
	E_EEPROM_BYTE,			/**< Page Erase and Byte Write */
	E_EEPROM_HWORD, 		/**< Erase One Page */
	E_EEPROM_WORD,			/**< Byte Write */
};

/**********************************************************************************
***					       		  MACROS FUNCTIONS								***													  	
**********************************************************************************/  
/** macro for Enable EEPROM interrupt */
#define DrvEEPROM_ENABLEINT()		do{EECR |= (1 << EERIE);} while(0)
/** macro for Disable EEPROM interrupt */
#define DrvEEPROM_DISABLEINT()		do{EECR &= (~(1 << EERIE));} while(0)
												  	
/**********************************************************************************
***					      	STRUCTRUES AND TYPEDEFINE							***													  	
**********************************************************************************/  

/**********************************************************************************
***					      		EXPORTED FUNCTIONS								***													  	
**********************************************************************************/ 
void DrvEEPROM_ProgByte(u16 u16Addr, u8 u8Data);
u8 DrvEEPROM_ReadByte(u16 u16Addr);

#if (EEPROM_HWORD_EN == 1)
void DrvEEPROM_ProgHWord(u16 u16Addr, u16 u16Data);
#endif

#if (EEPROM_WORD_EN == 1)
void DrvEEPROM_ProgWord(u16 u16Addr, u32 u32Data);
#endif

#if (FLASH_ISPAPI_EN)
void DrvFLASH_ProgData(u16 u16Addr, u16 u16Len, u16 *pu16Data);
void DrvFLASH_ErasePage(u16 u16Addr);
void DrvFLASH_ReadData(u16 u16Addr, u16 u16Len, u16 *pu16Data);
#endif

#endif
/**********************************************************************************
***					      					EOF									***													  	
**********************************************************************************/
