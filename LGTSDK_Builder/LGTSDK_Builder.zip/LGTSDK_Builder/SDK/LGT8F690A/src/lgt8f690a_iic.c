//-----------------------------------------
// LGTSDK Builder Project
// LGT8F690A/I2C Interface
//-----------------------------------------
#include "allinone.h"


// device address for slave
static volatile u8 _sladr = 0;

void i2cInit()
{
#if (I2C_PSDA == 0)
	LATA0 = 1;
	TRISA0 = 1;
#if (I2C_IPUP == 1)
	WPUA0 = 1;
#endif
#else
#if (I2C_IPUP == 1)
	WPUC0 = 1;
#endif
	LATC0 = 1;
	TRISC0 = 1;
#endif

#if (I2C_PSCL == 0)
	LATA1 = 1;
	TRISA1 = 1;
#if (I2C_IPUP == 1)
	WPUA1 = 1;
#endif
#else
#if (I2C_IPUP == 1)
	WPUC1 = 1;
#endif
	LATC1 = 1;
	TRISC1 = 1;
#endif

#if (I2C_IPUP == 1)
	nRABPU = 0;
#endif

	// store device address
	_sladr = I2C_DADDR & 0xfe;

	TWCR = (1 << 7)	|	// enable TWI module
		(I2C_MODE << 6) | // master / slave 
		(I2C_PSCL << 5) | // SCL assignment
		(I2C_PSDA << 4) | // SDA assignment
		(I2C_TWPS);	// bit rate prescaler

}

void i2cSetDevAddress(u8 sladr)
{
	_sladr = sladr & 0xfe;
}

// slave mode
#if (I2C_MODE == 0)
void i2cEndTransmission()
{
	TWIF = 0x0; 	// clear TWIF to continue i2c opeartion
	TWIEN = 0x0;
}

char i2cBeginTransmission()
{
	u8 trType = I2C_FAIL;

	TWSR = 0x0; 
	TWIF = 0x0; 	// clear TWIF
	TWIEN = 0x1;
//----------------------------------------------------------------
// wait start
//----------------------------------------------------------------
	TWIRXP = 0x0;
	while(TWIF == 0x0); 	// wait for TWIF set

	if (TWIRXS == 0x1) {		// tx start will receive start		
		TWIRXP = 0x0;	// clear rxp
		TWIRXS = 0x0;	// clear rxs
	}

//----------------------------------------------------------------
// receive sla+w 
//----------------------------------------------------------------
	TWITACK = 0x1;		// set NAK enable	
	TWIF = 0x0; 	// clear TWIF to continue i2c operation

	while(TWIF == 0x0); 	// wait for TWIF set, sla+w sent and acknowledge received

	if (TWIRXD == 0x1) {
		trType = TWDR & 0x1;
		if ((TWDR & 0xfe) != _sladr) {
			goto _not_addressed_1_;
		}

		TWITACK = 0x0;	// set ACK enable
		TWIRXD = 0x0;	// clear RXD
		TWITXK = 0x1;	// send ACK
		if(trType == I2C_READ) {
			TWIF = 0x0;
		}
	}
//----------------------------------------------------------------
// wait until ACK sent for sla+t 
//----------------------------------------------------------------	
	if(trType == I2C_WRITE)
		TWIF = 0x0; 	// clear TWIF to continue i2c operation

	while(TWIF == 0x0); 	// wait for TWIF set, ACK sent for acknowledge sla+w

	return trType;	// if addressed, return transfer type 
//----------------------------------------------------------------
// not address state
//----------------------------------------------------------------
_not_addressed_1_:
	i2cEndTransmission();
	return I2C_FAIL;
}

void i2cReadBuffer (char *rxbuf, u8 length)
{
	unsigned char i;
//----------------------------------------------------------------
// receive data
//----------------------------------------------------------------
	for(i = length; i > 0; )
	{
		TWIF = 0x0; 	// clear TWIF to continue i2c operation
		while(TWIF == 0x0); 	// wait for TWIF set, sla+w sent and acknowledge received

		if (TWIRXD == 0x1) {
			rxbuf[length-i] = TWDR;	// save data
			if (i == 1) { TWITACK = 0x1; }	// set NAK enable
			else { TWITACK = 0x0; }		// set ACK enable
			TWIRXD = 0x0;	// clear RXD
			i--;
			TWITXK = 0x1;	// send ACK
		}
	}

	while(TWIF==0x0); 	// wait for TWIF set, sla+w sent and acknowledge received
}

char i2cWriteBuffer (char *txbuf, u8 length)
{
	unsigned char i;
 
	for(i = length; i > 0; ) {
		TWDR = txbuf[length - i];
		TWITXD = 0x1;
		TWIF = 0x0; 	// clear TWIF to continue i2c operation

		while(TWIF == 0x0); 	// wait for TWIF set, data send and acknowledge received

		if (TWIRXK && TWIRACK)
			break;	// terminate transfer 
		i--;
		TWIRXK = 0x0;	// clear RXK
	}

	//while(TWIF==0x0); 	// wait for TWIF set, data send and acknowledge received
	TWIF = 0x0; 	// clear TWIF to continue i2c opeartion

	if(i > 0) return I2C_FAIL;

	return I2C_SUCCESS;
}
#endif

#if (I2C_MODE == 1)
char i2cBeginTransmission(u8 trType)
{
	TWIF = 0x0; 	// clear TWIF
//----------------------------------------------------------------
// send start
//----------------------------------------------------------------
	TWIRXS = 0x0;
	TWITXS = 0x1;

	while(TWIF==0x0); 	// wait for TWIF set

	if (TWIRXS==0x1) {		// tx start will receive start		
		//TWIRXP = 0x0;	// clear rxp
		TWIRXS = 0x0;	// clear rxs
	}

//----------------------------------------------------------------
// send sla+w 
//----------------------------------------------------------------
	TWDR = _sladr | (trType & 1);
	TWITXD = 0x1;

	TWIF = 0x0;

	while(TWIF==0x0); 	// wait for TWIF set, sla+w sent and acknowledge received

	if (TWIRXK==0x1) {
		if (TWIRACK == 0x1) {goto _m_not_addressed_;}
		TWIRXK = 0x0;	// clear RXK
		return  I2C_SUCCESS;
	}

//----------------------------------------------------------------
// not addressed state
//----------------------------------------------------------------
_m_not_addressed_:
	i2cEndTransmission();
	return I2C_FAIL;
}

void i2cEndTransmission()
{
	TWIRXP = 0x0;
	TWITXP = 0x1;
	TWIF = 0x0; 	// clear TWIF to continue i2c opeartion

	while(TWITXP == 0x1); // wait for stop sent
}

char i2cWriteBuffer (char *txbuf, u8 length)
{
	unsigned char i;
 
	TWIF = 0x0; 	// clear TWIF
//----------------------------------------------------------------
// send data
//----------------------------------------------------------------
	for(i = length; i > 0; i--)
	{
		TWDR = txbuf[length - i];
		TWITXD = 0x1;
		TWIF = 0x0; 	// clear TWIF to continue i2c operation

		while(TWIF == 0x0); 	// wait for TWIF set, data send and acknowledge received

		if(TWIRXK && TWIRACK)
			break; 

		TWIRXK = 0x0;	// clear RXK
	}

	if(i > 0) return I2C_FAIL;

	return I2C_SUCCESS;
}

char i2cWriteByte (u8 data)
{
	u8 status = I2C_ACK;

	TWIF = 0x0; 	// clear TWIF
//----------------------------------------------------------------
// send data
//----------------------------------------------------------------
	TWDR = data;
	TWITXD = 0x1;
	TWIF = 0x0; 	// clear TWIF to continue i2c operation

	while(TWIF==0x0); 	// wait for TWIF set, data send and acknowledge received

	if(TWIRXK && TWIRACK)
		status = I2C_NAK; 

	TWIRXK = 0x0;	// clear RXK
	return status;
}

void i2cReadBuffer(char *rxbuf, u8 length)
{
	u8 i;
 
	TWIF = 0x0; 	// clear TWIF
//----------------------------------------------------------------
// receive data
//----------------------------------------------------------------
	for(i = length; i > 0; i--) {
		TWITACK = 0x0; 
		if (i == 0x1) { TWITACK = 0x1; }
		TWITXK = 0x1;

		TWIF = 0x0; 	// clear TWIF to continue i2c operation

		while(TWIF == 0x0); 	// wait for TWIF set, data send and acknowledge received

		if (TWIRXD == 0x1) {
			rxbuf[length-i] = TWDR;
		}
	}
}

char i2cReadByte()
{
	TWIF = 0x0; 	// clear TWIF
//----------------------------------------------------------------
// receive data
//----------------------------------------------------------------
	TWITACK = 0x1;
	TWITXK = 0x1;

	TWIF = 0x0; 	// clear TWIF to continue i2c operation
	while(TWIF==0x0); 	// wait for TWIF set, data send and acknowledge received

	return TWDR;
}

/*
char i2cReadByteAsync(char *data)
{
	static u8 is_flag = 0;

	if(is_flag == 0) {
		TWIF = 0x0; 	// clear TWIF
//----------------------------------------------------------------
// receive data
//----------------------------------------------------------------
		TWITACK = 0x1;
		TWITXK = 0x1;
		is_flag = 1;
	}

	if(TWIF == 1) {
		is_flag = 0;
		TWIF = 0;
		*data = TWDR;

		return TRUE;
	}

	return FALSE;
}
*/
#endif
