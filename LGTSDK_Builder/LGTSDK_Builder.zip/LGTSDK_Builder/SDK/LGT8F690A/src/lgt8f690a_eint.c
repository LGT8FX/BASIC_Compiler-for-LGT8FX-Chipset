/**********************************************
 * system settings  
 **********************************************/

#include "allinone.h"

#define EINT_IOCA ((EINT_IOCA7 << 7)|(EINT_IOCA6 << 6)|(EINT_IOCA5 << 5)|(EINT_IOCA4 << 4)|(EINT_IOCA3 << 3)|(EINT_IOCA2 << 2)|(EINT_IOCA1 << 1)|(EINT_IOCA0))
#define EINT_IOCB ((EINT_IOCB7 << 7)|(EINT_IOCB6 << 6)|(EINT_IOCB5 << 5)|(EINT_IOCB4 << 4)|(EINT_IOCB3 << 3)|(EINT_IOCB2 << 2)|(EINT_IOCB1 << 1)|(EINT_IOCB0))

void eintInit(void)
{

#if (EINT_INTEN == 1)
	INTEDG = EINT_INTEDG;
	INTE = 1;
#endif
	
#if (EINT_IOCAEN == 1)
	IOCA = EINT_IOCA;
#endif

#if (EINT_IOCBEN == 1)
	IOCB = EINT_IOCB;
#endif

#if (EINT_IOCAEN == 1) || (EINT_IOCBEN == 1)
	RABIE = 1;
#endif
}
