//-----------------------------------------
// LGTSDK Builder Project 
// LGT8F690A SPI Interface
//-----------------------------------------
#include "allinone.h"

void spiInit()
{
#if (SPI_SPIM == 0)		// slave
	// initial port status
	LATA |= 0x70;
	LATB0 = 1;
	// initial port direction
	TRISA |= 0x70;
	TRISB0 = 0;
#else // (SPI_SPIM == 1)	// master
	TRISB0 = 1;
#if (SPI_SPDT == 0x0) || (SPI_SPDT == 0x1)
	// spcs => 1
	// spck => 0
	LATA = (LATA & 0x8f) | 0x40;
#else
	// spcs => 1
	// spck => 1
	LATA = (LATA & 0x8f) | 0x50;
#endif
	TRISA &= 0x8f;
#endif

	// SPSR : data/clock mode
	SPSR = (SPI_SPDM << 2) | // data mode
  		(SPI_SPCM >> 2); // clock mode

	// SPCR : SPI transfer control
	SPCR = (SPI_SPDORD << 5) | // data order
		(SPI_SPIM << 4)	| // master/slave
#if (SPI_SPDT == 0x2) || (SPI_SPDT == 0x3)
		(1 << 3) |	// POL
#endif
#if (SPI_SPDT == 0x1) || (SPI_SPDT == 0x3)
		(1 << 2) |	// PHA
#endif
		(SPI_SPCM & 0x3); // spi clock
		
	// enable SPI module
	SPIEN = 1;

}

char spiTransferByte(char data)
{
	u8 tmp;

	// clear tx/rx buffer status
	SPFR = 0x44;

	// dummy read to flush transfer buffer
	if(MCUCR & 0x6) {
		tmp = SPDR; tmp = SPDR; tmp = SPDR;
	}

	// write tx buffer
	SPDR = data;

	while(!(SPFR & (1 << 2)));

	return SPDR;
}

void spiReadBuffer(char *rxbuf, u8 length)
{
	u8 i, tmp;

	// clear tx/rx buffer status
	SPFR = 0x44;

	// dummy read to align data buffer
	if(MCUCR & 0x6) {
		tmp = SPDR; tmp = SPDR; tmp = SPDR;
	}

	// fill tx buffer 
	for(i = 0; i < 4; i++)
	{
		if(i == length) break;
		SPDR = 0xff;
	}

	// data transfer
	while ( length > 4)
	{
		if(!(SPFR & (1 << 3))) 
		{
			*rxbuf++ = SPDR;
			length--;
			SPDR = 0xff;
		}
	}

	while(length > 0)
	{
		if(SPFR & (1 << 2)) 
		{
			*rxbuf++ = SPDR;
			length--;
		}
	}
}

void spiWriteBuffer(char *txbuf, u8 length)
{
	u8 i, tmp;

	// clear tx/rx buffer status
	SPFR = 0x44;

	// dummy read to align data buffer
	if(MCUCR & 0x6) {
		tmp = SPDR; tmp = SPDR; tmp = SPDR;
	}

	// fill tx buffer 
	for(i = 0; i < 4; i++)
	{
		if(i == length) break;
		SPDR = *txbuf++;
	}

	// data transfer
	while ( length > 4)
	{
		if(!(SPFR & (1 << 3))) 
		{
			tmp = SPDR;
			length--;
			SPDR = *txbuf++;
		}
	}

	while(length > 0)
	{
		if(SPFR & (1 << 2)) 
		{
			tmp = SPDR;
			length--;
		}
	}
}

void spiTransferBuffer(char *txbuf, char *rxbuf, u8 length)
{
	u8 i, tmp;

	// clear tx/rx buffer status
	SPFR = 0x44;

	// dummy read to align data buffer
	if(MCUCR & 0x6) {
		tmp = SPDR; tmp = SPDR; tmp = SPDR;
	}

	// fill tx buffer 
	for(i = 0; i < 4; i++)
	{
		if(i == length) break;
		SPDR = *txbuf++;
	}

	// data transfer
	while ( length > 4)
	{
		if(!(SPFR & (1 << 3))) 
		{
			*rxbuf++ = SPDR;
			length--;
			SPDR = *txbuf++;
		}
	}

	while(length > 0)
	{
		if(SPFR & (1 << 2)) 
		{
			*rxbuf++ = SPDR;
			length--;
		}
	}
}
