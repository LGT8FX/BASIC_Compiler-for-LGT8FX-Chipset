//-----------------------------------------
// LGTSDK Builder Project 
// LGT8F690A EEP Interface
//-----------------------------------------
#include "allinone.h"


void eepWrite(u16 address, u8 data)
{
    u8 btmp;

    EEPGD = 0;  // E2PROM
    EEADR = address;
    EEADRH = address >> 8;
    EEDAT = data;
    
	// enable write
    WREN = 1;

    btmp = INTCON;
    GIE = 0;

    EECON2 = 0x55;
    EECON2 = 0xaa;
    EEWR = 1; // set WR bit to begin write

    WREN = 0;
    INTCON = btmp;	
}

u8 eepRead(u16 address)
{
    EEADR = address;
    EEADRH = address >> 8;

    EEPGD = 0;  // select EEPROM
    EERD = 1;

    return EEDAT;	
}
