/*
*******************************  C FILE  *********************************
** project  : LGT8F690A						    	**
**************************************************************************
** Copyright (c) 2017, 	LogicGreen Technologies Co., LTD		**
** All rights reserved.                                                	**
**************************************************************************

VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2017
Revised by 	: LogicGreen Software Group
Description 	: Original version.
*/
	
#include "lgt8f690a.h"
#include "macros_auto.h"

/**********************************************************************************
*** LGT8F690A CONFIGURATION WORD DEFINITION					***
**********************************************************************************/

#if (CFW_CONFIG1 == 1)
__L_CONFIG(CFW_FOSC & CFW_SUT & CFW_WDT & CFW_MCRE & CFW_OFS & CFW_TCYC & CFW_LVR & CFW_LVRPM);
#endif

/**********************************************************************************
***	       	  EOF								***
**********************************************************************************/
