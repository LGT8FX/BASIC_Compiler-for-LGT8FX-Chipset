#ifndef __LGT8F690A_EINT_H__
#define __LGT8F690A_EINT_H__

#include "allinone.h"

#define IOC_GPPA	IOCA
#define IOC_GPPB	IOCB

#define IOCF_GPPA	IOCAF
#define IOCF_GPPB	IOCBF

/**********************************************************************************
***	 MACROS AND DEFINITIONS							***
**********************************************************************************/ 
// enable external interrupt  
// ------------------------------------------------------------------------------
// usage: eintEnable();
//	- will enable external interrupt funciton from RA1/INT
#define eintEnable() INTIE = 1

// disable external interrupt  
// ------------------------------------------------------------------------------
// usage: eintDisable();
//	- will disable external interrupt function from RA1/INT 
#define eintDisable() INTIE = 0

// enable level change interrupt of gpp.pn 
// ------------------------------------------------------------------------------
// usage: eintEnableIOC(GPPA, P1);
//	- will disable level change interrupt function from RA1/INT 
#define eintEnableIOC(gpp, pn) IOC_##gpp |= (pn)

// disable level change interrupt of gpp.pn 
// ------------------------------------------------------------------------------
// usage: eintDisableIOC(GPPA, P1);
//	- will disable level change interrupt function from RA1/INT 
#define eintDisableIOC(gpp, pn) IOC_##gpp &= ~(pn)

// test level change interrupt flag
// ------------------------------------------------------------------------------
// usage: eintTestIOCF(GPPA, P1)
// 	- test level change flag of IOCAF1 (set or unset)
#define eintTestIOCF(gpp, pn) ((IOCF_##gpp & pn) == pn)

// clear level change interrupt flag bit
// usage: eintClearIOCF(GPPA, P1)
// 	- clear level change flag of ICOAF1
#define eintClearIOCF(gpp, pn) IOCF_##gpp &= ~(pn)

// ==============================================================================
// EXPORT API
void eintInit();

// end of __LGT8F690A_EINT_H__
#endif
