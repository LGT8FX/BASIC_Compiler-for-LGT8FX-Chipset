#ifndef __LGT8F690A_EEP__
#define __LGT8F690A_EEP__
// ============================================
#include "global.h"
#include "lgt8f690a.h"

#define eepInit() 	EECKE = 1

void eepWrite(u16, u8);
u8 eepRead(u16);

#endif
