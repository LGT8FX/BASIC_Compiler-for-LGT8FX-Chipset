#ifndef __LGT8F690A_IIC_H__
#define __LGT8F690A_IIC_H__

#include "allinone.h"

/**********************************************************************************
***	 MACROS AND DEFINITIONS							***
**********************************************************************************/ 
#define		I2C_SUCCESS	1
#define		I2C_FAIL	-1	

#define		I2C_WRITE	0
#define		I2C_READ	1

#define		I2C_NAK		1
#define		I2C_ACK		0

// ==============================================================================
// EXPORT API
void i2cInit();
void i2cSetDevAddress(u8);

void i2cReadBuffer(char *, u8);
char i2cWriteBuffer(char *, u8);
void i2cEndTransmission();

#if (I2C_MODE == 1 )
char i2cReadByte();
char i2cWriteByte(u8);
char i2cBeginTransmission(u8);
#else
char i2cBeginTransmission();
#endif

// end of __LGT8F690A_SYS_H__
#endif
