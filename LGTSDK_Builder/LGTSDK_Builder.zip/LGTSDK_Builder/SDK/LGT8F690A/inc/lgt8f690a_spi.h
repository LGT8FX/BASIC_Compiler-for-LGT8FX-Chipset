/*
*******************************  C HEADER FILE  **************************
** project  : LGT8F690A						    	**
**************************************************************************
** Copyright (c) 2017, 	LogicGreen Technologies Co., LTD		**
** All rights reserved.                                                	**
**************************************************************************

VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2017
Revised by 	: LogicGreen Software Group
Description 	: Original version.
*/
	
#ifndef _LGT8F690A_SPI_H_
#define _LGT8F690A_SPI_H_

/**********************************************************************************
***	          TYPEDEFS AND STRUCTURES					***
**********************************************************************************/
#define		SPSSPIN		LATA6

/**********************************************************************************
***	  	  EXPORTED VARIABLES						***
**********************************************************************************/
#define spiSSON()	SPSSPIN = 0
#define spiSSOFF()	SPSSPIN = 1

#define spiReadByte()		spiTransferByte(0xff)
#define spiWriteByte(value)	spiTransferByte(value)

/**********************************************************************************
*** 	  	  EXPORTED FUNCTIONS						***
**********************************************************************************/
void spiInit();
char spiTransferByte(char);
void spiTransferBuffer(char *, char *, u8);
void spiWriteBuffer(char *, u8);
void spiReadBuffer(char *, u8);

/**********************************************************************************
***	       	  EOF								***
**********************************************************************************/
#endif
