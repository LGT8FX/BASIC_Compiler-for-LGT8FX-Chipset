#include "allinone.h"


extern void init_modules(void);

volatile u8 gotNewChar = 0;

int main(void)
{

	// device initilization
	init_modules();
	
	// Global interrupt enable
	SEI();

	// Say hello!
	DrvUSART_SendStr("Hello, the world!\n");
		
	// demo start from here
	while(1)
	{
		if(gotNewChar != 0)
		{
			DrvUSART_SendChar(gotNewChar);
			gotNewChar = 0;
		}
	}

	return 0;
}
