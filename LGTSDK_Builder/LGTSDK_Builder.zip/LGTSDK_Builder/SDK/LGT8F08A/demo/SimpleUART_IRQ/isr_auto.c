//===================================================
// Auto generated file : 2014-05-07 06:23:20
//===================================================

#include "allinone.h"

extern volatile gotNewChar;

// Enable USART Receive Complete interrupt
#if (USART_RXC == 1)
LGT_VECTOR(IVN_RXC0)
{
	// TODO: Add your code here
	gotNewChar = DrvUSART_GetChar();
}
#endif
