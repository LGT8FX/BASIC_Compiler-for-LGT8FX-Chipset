//===================================================
// Auto generated file : 2014-05-07 06:23:20
// Range between ///Autogen will be overwriten by LGTSDK
// Take care if you have change this file.
//===================================================

#include "allinone.h"

void init_modules(void)
{

///Autogen start
	// modules initialization
	DrvUSART_Init();
	DrvMISC_Init();
///Autogen end

}
