#include "allinone.h"

extern void init_modules(void);

int main(void)
{

	// device initilization
	init_modules();
	
	// demo start from here
	while(1)
	{
		DrvUSART_SendStr("Hello, the world!\n");
		
		DrvMISC_Delayms(100);
	}

	return 0;
}
