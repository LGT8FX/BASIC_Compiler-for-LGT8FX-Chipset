#include "allinone.h"

int main(void)
{

	return 0;
}
