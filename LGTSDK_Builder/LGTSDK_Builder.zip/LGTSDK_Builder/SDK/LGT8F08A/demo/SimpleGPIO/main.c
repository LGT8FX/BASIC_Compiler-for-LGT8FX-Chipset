//===================================================
// Auto generated file : 2014-05-07 12:10:26
//===================================================

#include "allinone.h"

extern void init_modules(void);

int main(void)
{
	volatile u8 pinLevel;
	
	// Device initialization
	init_modules();


	// Add your code from here
	while(1)
	{
		DrvGPIO_TogglePort(A, OUT0);
		DrvGPIO_TogglePort(C, OUT0);
		DrvGPIO_TogglePort(D, (OUT1|OUT0));
		
		// VIN: for saftly read pin value, 
		// it must be read as following and 
		// pinLevel must be qulified by 'volatile'
		pinLevel = DrvGPIO_GetSinglePin(A, IN0);
		if(pinLevel == HIGH)
		{
			DrvGPIO_SetPort(B, OUT0);
		}
		else
		{
			DrvGPIO_ClearPort(B, OUT0);
		}

		DrvMISC_Delayms(100);
		
	}

	return 0;
}
