//===================================================
// Auto generated file : 2014-05-07 02:10:26
//===================================================

#include "allinone.h"

extern void init_modules(void);

int main(void)
{
	
	// Device initialization
	init_modules();

	// Global interrupt enable
	SEI();

	// Add your code from here
	while(1)
	{
		NOP();
	}

	return 0;
}
