//===================================================
// Auto generated file : 2014-05-07 06:23:20
//===================================================

#include "allinone.h"

// Enable Timer0 compare match interrupt
#if (TC0_OCF0EN == 1)
LGT_VECTOR(IVN_TC0_OC)
{
	// TODO: Add your code here
	DrvGPIO_TogglePort(A, OUT0);
}
#endif
