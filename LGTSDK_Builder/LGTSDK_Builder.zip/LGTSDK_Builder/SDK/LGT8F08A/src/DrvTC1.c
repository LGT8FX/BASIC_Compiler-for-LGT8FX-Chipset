/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvTC1.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvTC1.c
 * @brief Source File of TC1 driver 
 */

/** complier directives */
#define _DRVTC1_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
#if (TC1_CS1 == 0)
#warning <W1:Timer/Counter 1> No clock source selected for Timer 1
#endif	

#if (TC1_COM1A == 0) && (TC1_OC1AEN == 1)
#warning <W1:Timer/Counter 1> Compare(A) mode should be selected for PWM output
#endif

#if (TC1_COM1B == 0) && (TC1_OC1BEN == 1)
#warning <W1:Timer/Counter 1> Compare(B) mode should be selected for PWM output
#endif

#if ((TC1_WGM1 == 0) || (TC1_WGM1 == 4)) && ((TC1_COM1A == 2) || (TC1_COM1A == 3))
	#if (TC1_OC1AEN == 1)
	#warning <W1:Timer/Counter 1> OC1A will not output PWM in selected configuration
	#endif
#endif

#if ((TC1_WGM1 == 0) || (TC1_WGM1 == 4)) && ((TC1_COM1B == 2) || (TC1_COM1B == 3))
	#if (TC1_OC1AEN == 1)
	#warning <W1:Timer/Counter 1> OC1B will not output PWM in selected configuration
	#endif
#endif

#if ((TC1_WGM1 == 0) || (TC1_WGM1 == 4)) && ((TC1_OC1AEN == 1) || (TC1_OC1BEN == 1))
#warning <W1:Timer/Counter 1> only 50% duty ratio PWM supported by selected mode
#endif

#if ((TC1_WGM1 == 9) || (TC1_WGM1 == 0xb) || (TC1_WGM1 == 0xf))
	#if (TC1_OC1AEN == 1) && (TC1_COM1A == 1)
	#warning <W1:Timer/Counter 1> OC1A PWM only support 50% duty ratio in selected mode
	#endif
	#if (TC1_OCR1B > TC1_OCR1A)
	#warning <W0:Timer/Counter 1> OCR1A should be set more smaller than OCR1A in selected mode
	#endif
#endif

#if ((TC1_WGM1 == 4) || (TC1_WGM1 == 9) || (TC1_WGM1 == 0xb) || (TC1_WGM1 == 0xf))
	#if (TC1_COM1A != 1) && (TC1_OC1AEN == 1)
	#warning <W1:Timer/Counter 1> OC1A will not output PWM in selected configuration
	#endif
#endif

#if ((TC1_WGM1 == 8) || (TC1_WGM1 == 0xa) || (TC1_WGM1 == 0xc) || (TC1_WGM1 == 0xe))
	#if (TC1_ICR1 == 0)
	#warning <W0:Timer/Counter 1> ICR1 should be set for selected mode
	#endif
	#if (TC1_OCR1A > TC1_ICR1) || (TC1_OCR1B > TC1_ICR1)
	#warning <W0:Timer/Counter 1> OCR1A/OCR1B should be set smaller than ICR1 in selected mode
	#endif
#endif

#if ((TC1_WGM1 == 5) || (TC1_WGM1 == 6) || (TC1_WGM1 == 7) || (TC1_WGM1 == 0xe))
	#if (TC1_OC1AEN == 1) && (TC1_COM1A == 1)
	#warning <W0:Timer/Counter 1> OC1A will not output PWM in selected configuration
	#endif
	#if (TC1_OC1BEN == 1) && (TC1_COM1B == 1)
	#warning <W0:Timer/Counter 1> OC1B will not output PWM in selected configuration
	#endif
#endif

#if (TC1_WGM1 == 0xf) && (TC1_OC1BEN)
#warning <W1:Timer/Counter 1> OC1B will not output PWM in select configuration
#endif

#if ((TC1_WGM1 == 1) || (TC1_WGM1 == 2) || (TC1_WGM1 == 3) || (TC1_WGM1 == 8) || (TC1_WGM1 == 0xa))
	#if ((TC1_OC1AEN == 1) && (TC1_COM1A == 1))
	#warning <W0:Timer/Counter 1> OC1A will not output PWM in selected configuration
	#endif
	#if ((TC1_OC1BEN == 1) && (TC1_COM1B == 1))
	#warning <W0:Timer/Counter 1> OC1B will not output PWM in selected configuration
	#endif
#endif

#if ((TC1_WGM1 == 0xb) || (TC1_WGM1 == 9)) && (TC1_OC1BEN ==1)
	#if (TC1_COM1B == 1)
	#warning <W1:Timer/Counter 1> OC1B will not output PWM in select configuration
	#endif
#endif

#if (TC1_COM1A != 0) && (TC1_OCR1A == 0)
	#warning <W1:Timer/Counter 1> Please confirm OCR1A is given properly.
#endif

#if (TC1_COM1B != 0) && (TC1_OCR1B == 0)
	#warning <W1:Timer/Counter 1> Please confirm OCR1B is given properly.
#endif
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for TC1 initialize */
static u8 _tccr1b = 0x0;

/**********************************************************************************
*** 						PROTOTYPE OF LOCAL FUNCTIONS						*** 													
**********************************************************************************/

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvTC1_Init(void)
 * @brief Initialize TC1 and run. \n
 *	The arguments of this function are macros (TC1_CS1,TC1_WGM1,TC1_COM1A,TC1_COM1B, \n
 *	TC1_OCR1A,TC1_OCR1B,TC1_TCNT1,TC1_ICR1,TC1_OC1AEN,TC1_OCR1BEna). Before calling  \n
 *	you should give the correct value to shese macros according your application
 */
void DrvTC1_Init(void)
{
	// u8Sreg is used for storing value of SREG
	volatile u8 u8Sreg = 0;
		
	/** 1. Stop timer */
	TCCR1B = 0x0;

	/** 2. Force compare match: OC = 1*/
	// The setup of the OC1x should be performed before setting 
	// the Data Direction Register for the port pin to output
	// set OC1x before DDR_OC1x is set
	TCCR1A = (E_COM1_CSET << COM1A0) | (E_COM1_CSET << COM1B0);
	// force compare match
	TCCR1C = 0xc0;

	/** 3. Set PIN OC1x's direction */
#if (MMCU_PACKAGE == MMCU_SSOP24L) || (MMCU_PACKAGE == MMCU_SOP8L)
	DDRA |= (TC1_OC1AEN << PA3) | (TC1_OC1BEN << PA2);
#else
	DDRD |= (TC1_OC1AEN << PD5) | (TC1_OC1BEN << PD4);
#endif

	/** 4. Disalble Global Interrupt */
	u8Sreg = SREG;
	CLI();
	
	/** 5. Initiate TCNT1 */
	TCNT1H = (TC1_TCNT1 >> 8) & 0xff;
	TCNT1L = TC1_TCNT1 & 0xff;
	
	/** 6. Initiate (OCR1A & OCR1B)output compare register */
	OCR1AH = (TC1_OCR1A >> 8) & 0xff;
	OCR1AL = TC1_OCR1A & 0xff;
	OCR1BH = (TC1_OCR1B >> 8) & 0xff;
	OCR1BL = TC1_OCR1B & 0xff;
	ICR1H = (TC1_ICR1 >> 8) & 0xff;
	ICR1L = TC1_ICR1 & 0xff;

	/** 7. Restore SREG  */
	SREG = u8Sreg;

	/** 8. Config Interrupt if OCF1A, OCR1B, TOV1 or ICP1 is enabled */
#if (TC1_TOV1EN | TC1_OCF1AEN | TC1_OCF1BEN | TC1_ICP1EN)
	// Clear interrupt flag
	TIFR1 = 0x27;
	TIMSK1 = (TC1_TOV1EN << TOV1) | (TC1_OCF1AEN << OCF1A) | \
				(TC1_OCF1BEN << OCF1B) | (TC1_ICP1EN << ICF1);
#endif
	
	/** 9. Initiate TCCR1A and TCCR1B */
	TCCR1A = (TC1_COM1A << COM1A0) | (TC1_COM1B << COM1B0) | \
			((TC1_WGM1 & 0x3) << WGM10);
	TCCR1B = TC1_CS1 | (((TC1_WGM1 & 0xc) >> 2) << WGM12) | (TC1_ICNC1 << ICNC1) | (TC1_ICES1 << ICES1);

}

void DrvTC1_Stop(void)
{
	_tccr1b = TCCR1B;
	TCCR1B = 0x0;
}

void DrvTC1_Restart(void)
{
	TCCR1B = _tccr1b;
}


void DrvTC1_SetCNT(u16 value)
{
	volatile u8 _sreg;
	_sreg = SREG;
	CLI();
	_tc1_SetCNT(value);
	SREG = _sreg;
}

void DrvTC1_SetOCA(u16 value)
{
	volatile u8 _sreg;
	_sreg = SREG;
	CLI();
	_tc1_SetOCA(value);
	SREG = _sreg;
}

void DrvTC1_SetOCB(u16 value)
{
	volatile u8 _sreg;
	_sreg = SREG;
	CLI();
	_tc1_SetOCB(value);
	SREG = _sreg;
}

void DrvTC1_SetICR(u16 value)
{
	volatile u8 _sreg;
	_sreg = SREG;
	CLI();
	_tc1_SetICR(value);
	SREG = _sreg;
}

u16 DrvTC1_GetCNT(void)
{
	volatile u8 _sreg;
	u16 u16Tmp = 0;

	_sreg = SREG;
	CLI();
	u16Tmp = _tc1_GetCNT();
	SREG = _sreg;

	return u16Tmp;
}

u16 DrvTC1_GetOCA(void)
{
	volatile u8 _sreg;
	u16 u16Tmp = 0;

	_sreg = SREG;
	CLI();
	u16Tmp = _tc1_GetOCA();
	SREG = _sreg;

	return u16Tmp;
}

u16 DrvTC1_GetOCB(void)
{
	volatile u8 _sreg;
	u16 u16Tmp = 0;

	_sreg = SREG;
	CLI();
	u16Tmp = _tc1_GetOCB();
	SREG = _sreg;

	return u16Tmp;
}

u16 DrvTC1_GetICR(void)
{
	volatile u8 _sreg;
	u16 u16Tmp = 0;

	_sreg = SREG;
	CLI();
	u16Tmp = _tc1_GetICR();
	SREG = _sreg;

	return u16Tmp;
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/
