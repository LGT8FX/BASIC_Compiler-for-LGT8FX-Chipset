/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvRTC.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvRTC.c
 * @brief Source File of RTC
 */

/** complier directives */
#define _DRVRTC_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for RTC initialize */

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvRTC_Open(void)
 * @brief Initialize RTC and run. 
 * 	RCK must be enabled, 
 */
void DrvRTC_Init(void)
{
	// 1. Prepare top value
	RTCTOPL = RTC_TCTOP & 0xff;
	RTCTOPM = (RTC_TCTOP >> 8) & 0xff;
	RTCTOPH = (RTC_TCTOP >> 16) & 0xff;
	// 2. 
#if (RTC_IEN == TRUE)
	RTCISR = (1 << IF) | (1 << IEN);
#endif
	while(!(RTCSR & (1 << WREN)));
	RTCSR = (RTC_WKT << CWEN) | (1 << EN) | (1 << LOAD);
	while(!(RTCSR & (1 << WREN)));
	// 3. power off set
	if(RTC_WKT != E_WKT_NO)
	{
		RTCSR |= 0x1;
		while(!(RTCSR & (1 << WREN)));
	}
}

/**
 * @fn void __vector_27 __attribute__((signal, __INTR_ATTRS))
 *	RTCI's service routine, Compile when RTC_IEN is TRUE
 */

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/
