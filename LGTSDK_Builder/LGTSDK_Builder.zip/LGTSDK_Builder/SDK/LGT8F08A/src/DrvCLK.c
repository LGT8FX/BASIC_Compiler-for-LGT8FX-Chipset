/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F08A												    	**
** filename : DrvCLK.c	 		 												**
** version  : 1.0 													   			**
** date     : April 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	Logic Green Technologies								**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2013
Revised by 	: LGT Software Group
Description : Original version.
*/


/** complier directives */
#define _DRVCLK_SRC_C_

/**********************************************************************************
***					           	 	MODULES USED								***													  	
**********************************************************************************/
#include "allinone.h"

#if (MCK_CLKSEL == 0) && (MCK_RC16MEN == 0)
#warning <E0:System Clock> RC16M should be enable for clock source
#endif

#if (MCK_CLKSEL == 1) && (MCK_OSCMEN == 0)
#warning <E0:System Clock> External crystal should be enable for clock source
#endif

#if (MCK_CLKSEL == 2) && (MCK_RC1KEN == 0)
#warning <E0:System Clock> Internal RC1K/RC should be enable for clock source
#endif


/**********************************************************************************
***					            EXPORTED FUNCTIONS								***													  	
**********************************************************************************/  
/**
 * @fn void DrvCLK_Open(void)
 */
void DrvCLK_Init(void)
{
	DrvCLK_SetClockDivider(MCK_CLKDIV);
	NOP();
	DrvCLK_EnClockSource(E_OSCM_ENA | E_RCK_ENA | E_RCM_ENA);
	// wait for clock stable, eg. us
	DrvCLK_SetMainClock(MCK_MCLKSEL);

	NOP();
	NOP();
	NOP();	
	NOP();	

	//DrvCLK_EnClockSource(MCK_CLKENA);

#if (MCK_OSCEN == 0) && (MCK_CLKSEL != 0x1)
	// disable external crystal
	PMCR |= 0x4;
#endif

#if (MCK_RC1KEN == 0) && (MCK_CLKSEL != 0x2)
	// disable RC1K
	PMCR &= 0xfd;
#endif

#if (MCK_RC16MEN == 0) && (MCK_CLKSEL != 0x0)
	// diable RC16M
	PMCR &= 0xfe;
#endif
}

/**
 * @fn void DrvCLK_EnClockSource(u8 u8ClkEna)
 */
void DrvCLK_EnClockSource(u8 u8ClkEna)
{
	u8 u8Reg;

	u8ClkEna ^= 0x4;		// PMCR[2] = 1, Disable OSCM
	u8Reg = PMCR & 0x70;
	u8Reg |= u8ClkEna;
	PMCR = u8Reg;
}

/**
 * @fn void DrvCLK_SetMainClock(u8 u8MclkSel)
 */
void DrvCLK_SetMainClock(u8 u8MclkSel)
{
	u8 u8Reg;
	u8Reg = PMCR & 0x1f;
	u8Reg |= (u8MclkSel << 5);
	PMCR = u8Reg;
}

/**
 * @fn void DrvCLK_SetClockDivider(u8 u8ClkDiv)
 */
void DrvCLK_SetClockDivider(u8 u8ClkDiv)
{
	volatile u8 u8Tmp;

	Compiler_SetClkDiv();

	u8Tmp = u8ClkDiv;
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/  

