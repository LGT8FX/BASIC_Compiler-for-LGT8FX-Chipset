/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F08A												    	**
** filename : DrvPWR.c	 		 												**
** version  : 1.0 													   			**
** date     : April 01, 2013 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	Logic Green Technologies								**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2013
Revised by 	: LGT Software Group
Description : Original version.
*/


/** complier directives */
#define _DRVPWR_SRC_C_

/**********************************************************************************
***					           	 	MODULES USED								***													  	
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***					            MACRO AND DEFINITIONS							***													  	
**********************************************************************************/  


/**********************************************************************************
***					            EXPORTED FUNCTIONS								***													  	
**********************************************************************************/  
/**
 * @fn void DrvPWR_Init()
 * @bref release PC6 and clean up power/off flag
 */
void DrvPWR_Init(void)
{
}

/**
 * @fn void DrvPWR_Sleep() 
 */
void DrvPWR_Sleep(EM_SMODE emSMode)
{
	u8 u8Mod;
	u8Mod = ((emSMode & 0x7) << 1) | 0x1;
	SMCR = u8Mod;
	SLEEP();
}

/**
 * @fn void DrvPWR_PwrOff(u8 u8Wkup)
 */
void DrvPWR_PwrOff(EM_WK_SRC emWkup)
{
	while(!(RTCSR & 0x80));
	RTCSR = (RTCSR & 0xc) | (emWkup << CWEN);
	while(!(RTCSR & 0x80));
	RTCSR |= (1 << POWOFF);
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/  

