/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvINT.c		  		   	 										**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvINT.c
 * @brief Source File of External Interrupt and PIN Change Interrupt 
 */

/** complier directives */
#define _DRVINT_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for External Interrupt initialize */
/** macro for enable External Interrupt 0 */
#define argEXINT0Ena	TRUE
/** macro for EXINT0's Interrupt Sense */
#define argEXINT0ISC	E_ISC_FE
/** macro for enable External Interrupt 1 */
#define argEXINT1Ena	FALSE
/** macro for EXINT1's Interrupt Sense */
#define argEXINT1ISC	E_ISC_LOW
/** macro for enable External Interrupt 2 */
#define argEXINT2Ena	FALSE
/** macro for EXINT2's Interrupt Sense */
#define argEXINT2ISC	E_ISC_LOW

/* Arguments for PIN Change Interrupt */
/** macro for PORTA's PIN Change Interrupt Enable */
#define argPCIAEna		TRUE
/** macro for PORTA's PIN Change Interrupt Mask */
#define argPCIAMsk		0x3
/** macro for PORTB's PIN Change Interrupt Enable */
#define argPCIBEna		FALSE
/** macro for PORTB's PIN Change Interrupt Mask */
#define argPCIBMsk		0x0
/** macro for PORTC's PIN Change Interrupt Enable */
#define argPCICEna		FALSE
/** macro for PORTC's PIN Change Interrupt Mask */
#define argPCICMsk		0x0
/** macro for PORTD's PIN Change Interrupt Enable */
#define argPCIDEna		FALSE
/** macro for PORTD's PIN Change Interrupt Mask */
#define argPCIDMsk		0x0

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/** 
 * @fn void DrvEXINT_Open(void)
 * @brief Initial External Interrupt Controller
 */
void DrvEXINT_Open(void)
{
#if (argEXINT0Ena | argEXINT1Ena | argEXINT2Ena)
	u8 u8Tmp;

	/** Store SREG, & disable globall interupt */
	u8Tmp = SREG;
	asm("cli");
	/** Set Interrupt Sense */
	EICRA = (argEXINT0ISC << ISC00) | (argEXINT1ISC << ISC10) | (argEXINT2ISC << ISC20);
	/** Set Interrupt Enable */
	EIMSK = (argEXINT0Ena << INT0) | (argEXINT1Ena << INT1) | (argEXINT2Ena << INT2);
	/** Clear interupt flag */
	EIFR = (argEXINT0Ena << INT0) | (argEXINT1Ena << INT1) | (argEXINT2Ena << INT2);
	/** Restore SREG */
	SREG = u8Tmp;
#endif
}

/** 
 * @fn void DrvPCINT_Open(void)
 * @brief Initial PIN Interrupt Controller
 */
void DrvPCINT_Open(void)
{
#if (argPCIAEna | argPCIBEna | argPCICEna | argPCIDEna)
	u8 u8Tmp;

	/** Store SREG & disable global interrupt */
	u8Tmp = SREG;
	asm("cli");
	/** Set PIN Change Interrupt Mask */
#if argPCIAEna
	PCMSK0 = argPCIAMsk;
#endif
#if argPCIBEna
	PCMSK1 = argPCIBMsk;
#endif
#if argPCICEna
	PCMSK2 = argPCICMsk;
#endif
#if argPCIDEna
	PCMSK3 = argPCIDMsk;
#endif
	/** Set PIN Change Interrupt Enable */
	PCICR = (argPCIAEna << PCIE0) | (argPCIBEna << PCIE1) | \
			(argPCICEna << PCIE2) | (argPCIDEna << PCIE3);
	/** Clear Interrupt Flag */
	PCIFR = (argPCIAEna << PCIE0) | (argPCIBEna << PCIE1) | \
			(argPCICEna << PCIE2) | (argPCIDEna << PCIE3);
	/** Restore SREG */
	SREG = u8Tmp;
#endif
}

/**
 * @fn void __vector_1 __attribute__((signal, __INTR_ATTRS))
 *	External Interrupt 0 service routine, Compile when argEXINT0Ena is TRUE
 */
#if (argEXINT0Ena == TRUE)
SIGNAL(_VECTOR(1))
{
	// for test here, toggle PB0
	DDRB |= 0x1;
	PORTB = PORTB ^ 0x1;
}
#endif

/**
 * @fn void __vector_2 __attribute__((signal, __INTR_ATTRS))
 *	External Interrupt 1 service routine, Compile when argEXINT1Ena is TRUE
 */
#if (argEXINT1Ena == TRUE)
SIGNAL(_VECTOR(2))
{
}
#endif

/**
 * @fn void __vector_3 __attribute__((signal, __INTR_ATTRS))
 *	External Interrupt 2 service routine, Compile when argEXINT2Ena is TRUE
 */
#if (argEXINT2Ena == TRUE)
SIGNAL(_VECTOR(3))
{
}
#endif

/**
 * @fn void __vector_4 __attribute__((signal, __INTR_ATTRS))
 *	PORTA's PIN Change Interupt Service Routine, compile when argPCIAEna is TRUE
 */

#if (argPCIAEna == TRUE)
SIGNAL(_VECTOR(4))
{
	// for test here, toggle PB1
	DDRB |= 0x2;
	PORTB = PORTB ^ 0x2;
}
#endif

/**
 * @fn void __vector_5 __attribute__((signal, __INTR_ATTRS))
 *	PORTB's PIN Change Interupt Service Routine, compile when argPCIBEna is TRUE
 */

#if (argPCIBEna == TRUE)
SIGNAL(_VECTOR(5))
{
}
#endif

/**
 * @fn void __vector_6 __attribute__((signal, __INTR_ATTRS))
 *	PORTC's PIN Change Interupt Service Routine, compile when argPCICEna is TRUE
 */

#if (argPCICEna == TRUE)
SIGNAL(_VECTOR(6))
{
}
#endif

/**
 * @fn void __vector_7 __attribute__((signal, __INTR_ATTRS))
 *	PORTD's PIN Change Interupt Service Routine, compile when argPCIDEna is TRUE
 */

#if (argPCIDEna == TRUE)
SIGNAL(_VECTOR(7))
{
}
#endif


/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/
