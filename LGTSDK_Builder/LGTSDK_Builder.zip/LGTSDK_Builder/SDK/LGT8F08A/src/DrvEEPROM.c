/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvEEPROM.c  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/** complier directives */
#define _DrvEEPROM_SRC_C_

/**********************************************************************************
*** 							MODULES USED									*** 													
**********************************************************************************/
#include "allinone.h"

/**********************************************************************************
***					         MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 

/**********************************************************************************
*** 								LOCAL VARIABLES 							*** 													
**********************************************************************************/

/**********************************************************************************
*** 						  EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvEEPROM_ProgByte(u16 u16Addr, u8 pu8Data)
 *	Program EEPROM in Byte mode
 * @param u16Addr
 *	EEPROM Address which specify the Write Space
 * @param u8Data
 *	source data
 */
void DrvEEPROM_ProgByte(u16 u16Addr, u8 u8Data)
{
	volatile u8 u8Sreg = 0;

	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	// data
	EEDR = u8Data;
	// Program Mode
	//EECR = (EECR & (~DRVEEPROM_MODE_MSK));
	EECR = 0x0;

	// read status register
	u8Sreg = SREG;
	// clear global interrupt enable     
	CLI();

	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	__ASM("sbi 0x1f, 2");			//EEMPE = 1;
	__ASM("sbi 0x1f, 1");			//EEPE  = 1;
		
	SREG = u8Sreg;
}

/** 
 * @fn void DrvEEPROM_ReadByte(u16 u16Addr, u16 u16Len, u8 *pu8Data)
 *	Read data from EEPROM in Byte mode
 * @param u16Addr
 *	EEPROM Address which specify the Read Space
 */
u8 DrvEEPROM_ReadByte(u16 u16Addr)
{
	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0x3;
	EEARL = (u16Addr) & 0xff;
	// start eeprom read by writting EERE
	//EECR |= (1 << EERE);
	EECR = (EECR & 0x08) | (1 << EERE);
	NOP();
	NOP();

	// return data from data register
	return(EEDR);
}

#if (FLASH_ISPEN == 1)
/**
 * @fn void DrvFLASH_ProgData(u16 u16Addr, u16 u16Len, u16 *pu16Data)
 *	Program FLASH in Word(2-Byte) Mode
 * @param u16Addr
 *	EEPROM Address which specify the Write Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the source data
 */
void DrvFLASH_ProgData(u16 u16Addr, u16 u16Len, u16 *pu16Data)
{
	u8 u8Sreg;
	u16 i;
	// read status register
	u8Sreg = SREG;
	// clear global interrupt enable
	CLI();
	for(i = 0; i < u16Len; i++)
	{
		// wait for completion of previous write
		while(EECR & (1 << EEPE));
		// address
		EEARH = (u16Addr >> 8) & 0xff;
		EEARL = (u16Addr) & 0xff;
		// data
		EEDR  = *pu16Data & 0xff;
		EEDRH = (*pu16Data >> 8) & 0xff;
		// Program Mode
		EECR = E_WRITE_WORD;
		// write logical one to EEMWE
		// start eeprom write by setting EEWE
		__ASM("sbi 0x1f, 2");			//EEMPE = 1;
		__ASM("sbi 0x1f, 1");			//EEPE  = 1;

		u16Addr += 2;
		pu16Data++;

	}

	// wait for completion of This write
	while(EECR & (1 << EEPE));
	// re-config global interrupt enable
	SREG = u8Sreg;

	EECR &= 0x7F;
	
}


/**
 * @fn void DrvFLASH_ErasePage(u16 u16Addr)
 *	Erase FLASH in Page(512-Byte) Mode
 * @param u16Addr
 *	EEPROM Address which specify the Erase Space, u16Addr[8:0] Must be 0x00
 */
void DrvFLASH_ErasePage(u16 u16Addr)
{
	u8 u8Sreg;
	// read status register
	u8Sreg = SREG;
	// clear global interrupt enable
	CLI();
	
	// wait for completion of previous write
	while(EECR & (1 << EEPE));
	// address
	EEARH = (u16Addr >> 8) & 0xff;
	EEARL = (u16Addr) & 0xff;
	// data
	//EEDRL = *wData & 0xff;
	//EEDRH = (*wData >> 8) & 0xff;
	// Program Mode
	EECR = E_ERASE_PAGE;
	// write logical one to EEMWE
	// start eeprom write by setting EEWE
	__ASM("sbi 0x1f, 2"); 		//EEMPE = 1;
	__ASM("sbi 0x1f, 1"); 		//EEPE	= 1;

	/// wait for completion of This write
	while(EECR & (1 << EEPE));
	// re-config global interrupt enable
	SREG = u8Sreg;

	EECR &= 0x7F;
		
}

/**
 * @fn void DrvFLASH_ReadData(u16 u16Addr, u16 u16Len, u16 *pu16Data)
 *	Read FLASH in Word(2-Byte) Mode
 * @param u16Addr
 *	FLASH Address which specify the Read Space
 * @param u16Len
 *	Data Length
 * @param pu8Data
 *	Pointer while point to the Destination Space
 */
void DrvFLASH_ReadData(u16 u16Addr, u16 u16Len, u16 *pu16Data)
{
	u16 i;
    u16 u16Tmp;
    
	for(i = 0; i < u16Len; i++)
	{
		// wait for completion of previous write
		while(EECR & (1 << EEPE));
		// address
		EEARH = (u16Addr >> 8) & 0xff;
		EEARL = (u16Addr) & 0xff;
		// start eeprom read by writting EERE
		EECR = (EECR & 0x08) | E_READ_WORD| (1 << EERE);
		NOP();
		NOP();
		// return data from data register
        	u16Tmp = EEDR;
        	u16Tmp |= ((u16)EEDRH << 8);
		*pu16Data++ = u16Tmp;
		
		u16Addr += 2;
	}

}
#endif


/**********************************************************************************
*** 										EOF 								*** 													
**********************************************************************************/

