/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvADC.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvADC.c
 * @brief Source File of ADC
 */

/** complier directives */
#define _DRVADC_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/** macro for Digital IO Mask */
#define ARG_DIDR0	(ADC_DIDR07 << 7)|(ADC_DIDR06 << 6)|(ADC_DIDR05 << 5)|(ADC_DIDR04 << 4)| \
			(ADC_DIDR03 << 3)|(ADC_DIDR02 << 2)|(ADC_DIDR01 << 1)|ADC_DIDR00;

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvTC0_Open(void)
 * @brief Initialize TC0 and run.
 */
void DrvADC_Init(void)
{
	// Disable ADC
	ADCSRA = 0x10;
	// ADC Multiplexer Selection Register
 	ADMUX = (ADC_REFS << REFS0) | (ADC_ADLAR<< ADLAR) | ADC_CHMUX;
	// ADC Control and Status Register A
	ADCSRA = (ADC_ADATEN  << ADATE) | (ADC_ADIE << ADIE) | ADC_ADPS;
	// ADC Control and Status Register B
#if (ADC_ADATEN == TRUE)
	ADCSRB = ADC_ADTS;
#endif
	// 
	DIDR0 = ARG_DIDR0;
	// Enable ADC
	ADCSRA |= (1 << ADEN);
}

void DrvADC_softStart(void)
{
	while((ADCSRA & 0x40) != 0x00);

	ADCSRA |= 0x40;
}

void DrvADC_setChannel(emChnMux chnMux)
{
	ADMUX = (ADC_REFS << REFS0) | (ADC_ADLAR << ADLAR) | chnMux;
}

u16 DrvADC_readData(void)
{
	volatile u8 tmp = 0;

	DrvADC_softStart();

	tmp = ADCL;
	return (ADCH << 8) | tmp;
}

u16 DrvADC_readChannel(emChnMux chnMux)
{
	DrvADC_setChannel(chnMux);
	return DrvADC_readData();
}

/**
 * @fn u16 DrvADC_readDataEx(u8 fltCount)
 * @bref Read data from current channel, fltCount can be used for \n
 * 	data over-sample alogrithm
 */
u16 DrvADC_readDataEx(u8 fltCount)
{
	u8 i = 0;
	u16 data = DrvADC_readData();
	for(i = 0; i < fltCount; i++)
	{
		data += DrvADC_readData();
		data = data >> 1;
	}

	return data;
}

/**
 * @fn u16 DrvADC_readChannelEx(u8 fltCount, emChnMux chnMux)
 * @bref Read data from given channel, fltCount can be used for \n
 * 	data over-sample alogrithm
 */
u16 DrvADC_readChannelEx(u8 fltCount, emChnMux chnMux)
{
	DrvADC_setChannel(chnMux);
	return DrvADC_readDataEx(fltCount);
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/

