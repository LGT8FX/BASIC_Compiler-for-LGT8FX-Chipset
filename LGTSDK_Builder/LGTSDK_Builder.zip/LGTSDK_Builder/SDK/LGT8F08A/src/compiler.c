/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : compiler.c	  	   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/** complier directives */
#define _COMPILER_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "compiler.h"
#include "mcommon.h"
#include "mmacros.h"

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * void Compiler_SetClkDiv(u8 u8ClkDiv)
 */
void Compiler_SetClkDiv(u8 u8ClkDiv)
{
	// Set CLKPCE = 1
	ASM("ldi	r20, 0x80");
	ASM("sts	0x61, r20");
#ifdef __GNUC__
	ASM("sts	0x61, r24");
#endif
#ifdef __IAR_SYSTEMS_ICC__
	ASM("sts	0x61, r16");
#endif

#ifdef __ICC_VERSION
	ASM("sts	0x61, r16");
#endif

#ifdef __CODEVISIONAVR__
	#asm
		ld		r16, y
		sts		0x61, r16
	#endasm
#endif
    u8ClkDiv = u8ClkDiv;
}

void Compiler_SetWDT(u8 u8Wdtcsr)
{
	// Set CLKPCE = 1
#ifdef __GNUC__
	asm("mov	r25, r24");
	asm("ori	r25, 0x08");
	asm("sts	0x60, r25");
	asm("sts	0x60, r24");
#endif
#ifdef __IAR_SYSTEMS_ICC__
	asm("mov	r17, r16");
	asm("ori	r17, 0x08");
	asm("sts	0x60, r17");
	ASM("sts	0x60, r16");
#endif

#ifdef __ICC_VERSION
	asm("mov	r17, r16");
	asm("ori	r17, 0x08");
	asm("sts	0x60, r17");
	ASM("sts	0x60, r16");
#endif

#ifdef __CODEVISIONAVR__
	#asm
		ld		r16, y
		mov		r17, r16
		ori		r17, 0x08
		sts		0x60, r17
		sts		0x60, r16
	#endasm
#endif
    u8Wdtcsr = u8Wdtcsr;
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/
