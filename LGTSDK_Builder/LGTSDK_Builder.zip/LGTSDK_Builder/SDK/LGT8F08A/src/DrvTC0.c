/*
  							  	****************
*******************************  C SOURCE FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvTC0.c	  		   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

/**
 * @file DrvTC0.c
 * @brief Source File of TC0 driver 
 */

/** complier directives */
#define _DRVTC0_SRC_

/**********************************************************************************
***					            MODULES USED									***													  	
**********************************************************************************/ 
#include "allinone.h"
	
#if (TC0_CS0 == 0)
#warning <W1:Timer/Counter 0> No clock source selected for Timer 0
#endif	

#if (TC0_COM0 == 0) && (TC0_OC0EN == 1)
#warning <W0:Timer/Counter 0> Please select "Compare output mode" for PWM output
#endif

#if (TC0_OC0EN == 1) && (TC0_OCR0 == 0)
#if  (TC0_WGM0 == 0) || (TC0_WGM0 == 1) || (TC0_WGM0 == 3)
#warning <W0:Timer/Counter 0> Please confirm "Compare register" is right for PWM duty ratio (OCR0/0xFF)
#else
#warning <W1:Timer/Counter 0> Please confirm "Compare register" is right for PWM frequency
#endif
#endif

#if ((TC0_WGM0 == 2) || (TC0_WGM0 == 5) || (TC0_WGM0 == 7)) && (TC0_OC0EN == 1)
#warning <W1:Timer/Counter 0> Only 50% duty ratio is supported by selected waveform genearation mode
#endif

#if ((TC0_WGM0 == 0) || (TC0_WGM0 == 2)) && (TC0_COM0 != 1) && (TC0_OC0EN == 1)
#warning <W1:Timer/Counter 0> There will no PWM output with current selected configuration
#endif

#if (TC0_COM0 == 0) && (TC0_OC0EN == 1)
#warning <W1:Timer/Counter 0> Compare mode must be selected for PWM output
#endif

/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/* Arguments for TC0 initialize */
static u8 _tccr0b = 0;

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * @fn void DrvTC0_Open(void)
 * @brief Initialize TC0 and run. \n
 *	The arguments of this function are macros (TC0_CS0,TC0_WGM0,TC0_COM0,TC0_OCR0,\n
 *	TC0_TCNT0,TC0_OC0EN). Before calling you should give the correct value to \n
 *  shese macros according your application
 */
void DrvTC0_Init(void)
{

	/** 1. Stop timer */
	TCCR0B = 0x0;

	/** 2. Force compare match: OC = 1*/
	// The setup of the OC0 should be performed before setting 
	// the Data Direction Register for the port pin to output
	// set OC0 before DDR_oc0 is set
	TCCR0A = E_COM0_CSET << COM0A0;
	// force compare match
	TCCR0B = 0x80;

	/** 3. Set PIN OC's direction */
#if (MMCU_PACKAGE == MMCU_SOP8L) || (MMCU_PACKAGE == MCU_SSOP24L)
	DDRA |= (TC0_OC0EN << PA7);
#else
	DDRC |= (TC0_OC0EN << PC6);
#endif

	/** 4. Initiate TCNT0 */
	TCNT0 = TC0_TCNT0;
	/** 5. Initiate (OCR)output compare register */
	OCR0A = TC0_OCR0;

	/** 6. Config Interrupt if OCF0 or TOV is enabled */
#if (TC0_OCF0EN | TC0_TOV0EN)
	// Clear interrupt flag
	TIFR0 = 3;
	TIMSK0 = TC0_TOV0EN | (TC0_OCF0EN << 1);	
#endif
	
	/** 7. Initiate TCCR0A and TCCR0B */
	TCCR0A = (TC0_COM0 << COM0A0) |\
			((TC0_WGM0 & 0x3) << WGM00);
	TCCR0B = TC0_CS0 | (((TC0_WGM0 & 0x4) >> 2) << WGM02);

}

void DrvTC0_Stop(void)
{
	_tccr0b = TCCR0B;
	TCCR0B = 0;
}

void DrvTC0_Restart(void)
{
	TCCR0B = _tccr0b;
}

/**********************************************************************************
*** 									EOF 									*** 													
**********************************************************************************/

