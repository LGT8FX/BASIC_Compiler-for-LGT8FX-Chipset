#ifndef __LGT8F08A_IAR_H
#define __LGT8F08A_IAR_H

/** compiler relative macros */
#define SEI() asm("sei")
#define CLI() asm("cli")
#define SLEEP() asm("sleep")
#define WDR() asm("wdr")
#define NOP() asm("nop")
#define __ASM asm

/* Interrupt Vector Numbers */
#define LGT_VECTOR_S_IVN_EXINT0		"vector = 4"
#define LGT_VECTOR_S_IVN_EXINT1		"vector = 8"
#define LGT_VECTOR_S_IVN_EXINT2		"vector = 12"
#define LGT_VECTOR_S_IVN_PCINT0		"vector = 16"
#define LGT_VECTOR_S_IVN_PCINT1		"vector = 20"
#define LGT_VECTOR_S_IVN_PCINT2		"vector = 24"
#define LGT_VECTOR_S_IVN_PCINT3		"vector = 28"
#define LGT_VECTOR_S_IVN_WDT		"vector = 32"
#define LGT_VECTOR_S_IVN_TC1_ICP	"vector = 48"
#define LGT_VECTOR_S_IVN_TC1_OCA	"vector = 52"
#define LGT_VECTOR_S_IVN_TC1_OCB	"vector = 56"
#define LGT_VECTOR_S_IVN_TC1_TOV	"vector = 60"
#define LGT_VECTOR_S_IVN_TC0_OCA	"vector = 64"
#define LGT_VECTOR_S_IVN_TC0_OC		"vector = 64"
#define LGT_VECTOR_S_IVN_TC0_TOV	"vector = 72"
#define LGT_VECTOR_S_IVN_RXC0		"vector = 80"
#define LGT_VECTOR_S_IVN_UDR0		"vector = 84"
#define LGT_VECTOR_S_IVN_TXC0		"vector = 88"
#define LGT_VECTOR_S_IVN_ACP		"vector = 92"
#define LGT_VECTOR_S_IVN_ADC		"vector = 96"
#define LGT_VECTOR_S_IVN_EE_RDY		"vector = 100"
#define LGT_VECTOR_S_IVN_RTC		"vector = 108"

#define L_VECTOR(N)	__vector_##N

#define LGT_VECTOR(NAME) \
_Pragma (LGT_VECTOR_S_##NAME)  __interrupt void NAME(void)

#define Compiler_SetClkDiv() do {\
	asm("ldi	r20, 0x80"); \
	asm("sts	0x61, r20"); \
	asm("sts	0x61, r16"); \
} while(0)

#define Compiler_SetWDT() do {\
	asm("mov	r17, r16"); \
	asm("ori	r17, 0x08"); \
	asm("sts	0x60, r17"); \
	asm("sts	0x60, r16"); \
} while(0)

#endif
