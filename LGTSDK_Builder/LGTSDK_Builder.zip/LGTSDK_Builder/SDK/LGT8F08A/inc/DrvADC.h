/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvADC.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvADC.h
 * @brief Header File of ADC
 *		
 */

#ifndef _ADC_H_
#define _ADC_H_

/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/**
 * @enum emRefs
 *  Voltage reference for the ADC
 */
enum emRefs
{
	E_REFS_AREF,		/**< AVCC */
	E_REFS_AVCC,		/**< AVCC */
	E_REFS_INVR			/**< Internal 1.25V voltage Reference */
};

/**
 * @enum emAdlar
 *	ADC Left Adjust Result
 */
enum emAdlar
{
	E_ADLAR_RIGHT,		/**< right adjust the result */
	E_ADLAR_LEFT		/**< left adjust the result */
};

/**
 * @enum emChmux
 *	Analog Channel Select
 */
typedef enum _emChnMux
{
	E_CHMUX_ADC0,		/** Select ADC0(PA0) connect to ADC */
	E_CHMUX_ADC1,		/** Select ADC1(PA1) connect to ADC */		
	E_CHMUX_ADC2,		/** Select ADC2(PA2) connect to ADC */
	E_CHMUX_ADC3,		/** Select ADC3(PA3) connect to ADC */
	E_CHMUX_ADC4,		/** Select ADC4(PA4) connect to ADC */
	E_CHMUX_ADC5,		/** Select ADC5(PA5) connect to ADC */
	E_CHMUX_ADC6,		/** Select ADC6(PA6) connect to ADC */
	E_CHMUX_ADC7,		/** Select ADC7(PA7) connect to ADC */
	E_CHMUX_INVR = 25,	/** Select Internel Voltage Reference  connect to ADC */
	E_CHMUX_GND,			/** Select GND connect to ADC */	
	E_CHMUX_NONE = 31
} emChnMux;

/**
 * @enum emAdps
 *	ADC Prescaler Selections, determine the division factor between main clock
 *	and the input clock to the ADC
 */
enum emAdps
{
	E_ADPS_DIV2 = 0x1,	/**< Division Factor is 2 */
	E_ADPS_DIV4,		/**< Division Factor is 4 */
	E_ADPS_DIV8,		/**< Division Factor is 8 */
	E_ADPS_DIV16,		/**< Division Factor is 16 */
	E_ADPS_DIV32,		/**< Division Factor is 32 */
	E_ADPS_DIV64,		/**< Division Factor is 64 */
	E_ADPS_DIV128		/**< Division Factor is 128 */
};

/**
 * @enmum emAdts
 *	ADC Auto Trigger Source
 */
enum emAdts
{
	E_ADTS_FREE,		/**< Trigger Source is Free Running */
	E_ADTS_AC,			/**< Trigger Source is AC Comparator */
	E_ADTS_EINT0,		/**< Trigger Source is External Interrupt Request 0 */
	E_ADTS_OCF0,		/**< Trigger Source is TC0 Compare Match */
	E_ADTS_TOV0,		/**< Trigger Source is TC0 Overflow */
	E_ADTS_OCF1B,		/**< Trigger Source is TC1 Compare Match B */
	E_ADTS_TOV1,		/**< Trigger Source is TC1 Overflow */
	E_ADTS_ICP1,		/**< Trigger Source is TC1 Capture Event */
};

/**********************************************************************************
***					     	 MACROS AND DEFINITIONS								***													  	
**********************************************************************************/ 
/** Start ADC Coversion */
#define DRVADC_START_ADC()		do {ADCSRA |= (1 << ADSC);} while(0)

#define	DrvADC_disableADC()	ADCSRA &= 0x7F
#define DrvADC_enableADC()	ADCSRA |= 0x80


/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _ADC_SRC_
#endif
	
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvADC_Init(void);
u16 DrvADC_readDataEx(u8 fltCount);
u16 DrvADC_readChannelEx(u8 fltCount, emChnMux chnMux);
void DrvADC_softStart(void);
void DrvADC_setChannel(emChnMux chnMux);
u16 DrvADC_readData(void);
u16 DrvADC_readChannel(emChnMux chnMux);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/


