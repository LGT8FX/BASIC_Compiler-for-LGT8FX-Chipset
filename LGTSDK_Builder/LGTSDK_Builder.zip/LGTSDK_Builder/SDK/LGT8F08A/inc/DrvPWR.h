/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F08A													    **
** filename : DrvPWR.h	 	 	   	 											**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2013, 	LogicGreen techologies									**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/

#ifndef _DrvPWR_H_
#define _DrvPWR_H_

/**********************************************************************************
***					            	MODULES USED								***													  	
**********************************************************************************/  
#include "allinone.h"

/**********************************************************************************
***					          	  MACRO AND DEFINTION							***													  	
**********************************************************************************/ 
#define	PWR_TC0		0x20
#define PWR_TC1		0x08
#define PWR_USART	0x02
#define	PWR_ADC		0x01

#define DRVPWR_TC0_ENA()	do{PRR &= 0xdf;} while(0)
#define DRVPWR_TC0_DIS()	do{PRR |= 0x20;} while(0)
#define DRVPWR_TC1_ENA()	do{PRR &= 0xf7;} while(0)
#define DRVPWR_TC1_DIS()	do{PRR |= 0x08;} while(0)
#define DRVPWR_UART_ENA()	do{PRR &= 0xfd;} while(0)
#define DRVPWR_UART_DIS()	do{PRR |= 0x02;} while(0)
#define DRVPWR_ADC_ENA()	do{PRR &= 0xfe;} while(0)
#define DRVPWR_ADC_DIS()	do{PRR |= 0x01;} while(0)

#define DrvPWR_enableModule(_MODULE) do { PRR &= ~_MODULE;} while(0)
#define DrvPWR_disableMoudle(_MODULE) do { PRR |= _MODULE;} while(0)

/**********************************************************************************
***					            TYPEDEF AND STRUCTURE							***													  	
**********************************************************************************/
/**
 * @enum emSmod
 *	Sleep Mode
 */

/**
 * @typedef typedef enum emSmode EMSMODE
 */
typedef enum emSmod
{
	E_SLEEP_IDLE,			/**< idle mode */
	E_SLEEP_ADCNRM,			/**< ADC Noise Reduction mode */
	E_SLEEP_PWRDOWN, 		/**< power down mode */
}EM_SMODE;

/**
 * @enum emPwrOffWkupSrc
 */
typedef enum emPows
{
	E_POWS_RTC=1,			/**< Wake up source of POWER-OFF is RTC */
	E_POWS_EXINT,			/**< Wake up source of POWER-OFF is EXINT */
	E_POWS_BOTH				/**< Both RTC and EXINT can wake up MCU for POWER-OFF */
}EM_WK_SRC;


/**********************************************************************************
***					            	EXPORTED FUNCTIONS							***													  	
**********************************************************************************/ 
void DrvPWR_Init(void);
void DrvPWR_Sleep(EM_SMODE emSMode);
void DrvPWR_PwrOff(EM_WK_SRC u8Wkup);

#endif
/**********************************************************************************
***					            		EOF										***													  	
**********************************************************************************/  
