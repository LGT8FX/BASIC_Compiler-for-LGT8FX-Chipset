/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvAC.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvAC.h
 * @brief Header File of AC
 *		
 */

#ifndef _AC_H_
#define _AC_H_

/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/**
 * @enum emAcbg
 *  Analog Comparator Bangap Select
 */
enum emAcbg
{
	E_ACBG_AIN0,			/**< AIN0 is applied to the positive input */
	E_ACBG_BGR				/**< Bandgap reference volatage is applied to the 
									positive input */
};

/**
 * @enum emAcis
 *	AC Interrupt Mode Select 
 */
enum emAcis
{
	E_ACIS_AE,				/**< Any edge of ACO generates an interrupt */
	E_ACIS_REV,				/**< Reserved */
	E_ACIS_FE,				/**< Falling edge of ACO generates an interrupt */
	E_ACIS_RE				/**< Rising edge of ACO generates an interrupt */
};

/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _AC_SRC_
#endif

#define DrvAC_Stop() ACSR |= 0x80
#define DrvAC_Start() ACSR &= 0x7f
	
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvAC_Init(void);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/

