#ifndef __GLOBAL_H__
#define	__GLOBAL_H__

/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : common.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : * Original version.
*/
	
/**
 * @file mcommon.h
 * @brief Header File of all files \n
 *	This include some type define and macros for all files in this project
 */

/**********************************************************************************
***					          	TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/

/** C type extension */
typedef unsigned char  		u8;		/**< define unsigned 8-bite data type */
typedef signed char  		s8;		/**< define signed 8-bite data type */
typedef unsigned int   		u16;	/**< define unsigned 16-bite data type */
typedef signed int   		s16;	/**< define signed 16-bite data type */
typedef unsigned long  		u32;	/**< define unsigned 32-bite data type */
typedef signed long   		s32;	/**< define signed 32-bite data type */

/** define NULL while value is 0 */
#ifndef NULL
#define NULL 	0
#endif

/** define PNULL while is a pointer that point to address 0 */
#ifndef PNULL
#define PNULL 	((void *)0)
#endif

/** define TURE while is a boolean value 1 */
#ifndef TRUE
#define TRUE    1 
#endif

/** define FALSE while is a boolean value 0 */
#ifndef FALSE
#define FALSE   0    
#endif

/** define logic for i/o's status */
typedef enum _logic
{
	LOW = 0,
	HIGH = 1
} LOGIC;

/** Interrupt Vector Number */
#define IVN_RESET		L_VECTOR(0)
#define IVN_EXINT0		L_VECTOR(1)
#define IVN_EXINT1		L_VECTOR(2)
#define IVN_EXINT2		L_VECTOR(3)
#define IVN_PCINT0		L_VECTOR(4)
#define IVN_PCINT1		L_VECTOR(5)
#define IVN_PCINT2		L_VECTOR(6)
#define IVN_PCINT3		L_VECTOR(7)
#define IVN_WDT			L_VECTOR(8)
#define IVN_TC1_ICP		L_VECTOR(12)
#define IVN_TC1_OCA		L_VECTOR(13)
#define IVN_TC1_OCB		L_VECTOR(14)
#define IVN_TC1_TOV		L_VECTOR(15)
#define IVN_TC0_OCA		L_VECTOR(16)
#define IVN_TC0_OC		L_VECTOR(16)
#define IVN_TC0_TOV		L_VECTOR(18)
#define IVN_RXC0		L_VECTOR(20)
#define IVN_UDR0		L_VECTOR(21)
#define IVN_TXC0		L_VECTOR(22)
#define IVN_ACP			L_VECTOR(23)
#define IVN_ADC			L_VECTOR(24)
#define IVN_EE_RDY		L_VECTOR(25)
#define IVN_RTC			L_VECTOR(27)

/** Define common chip package */
#define MMCU_SOP8L		0
#define MMCU_SOP14L		1
#define MMCU_SOP16L		2
#define MMCU_SSOP24L		3
#define	MMCU_SSOP28L		4
#define	MMCU_SOP28L		4
#define MMCU_QFP32L		5

#endif
