/*
  							  	****************
*******************************  C HEADER FILE  **********************************
** 								**************** 						        **
** 																		        **
** project  : BSPLGT8F0XA												    	**
** filename : DrvWDT.h 	   	 													**
** version  : 1.0 													   			**
** date     : April 01, 2014 										   			**
** 			  		 	 												   		**
**********************************************************************************
** 																		   		**
** Copyright (c) 2014, 	LogicGreen Technologies Co., LTD						**
** All rights reserved.                                                    		**
**                                                                         		**
**********************************************************************************
VERSION HISTORY:
----------------
Version 	: 1.0
Date 		: April 01, 2014
Revised by 	: LogicGreen Software Group
Description : Original version.
*/
	
/**
 * @file DrvWDT.h
 * @brief Header File of WDT
 *		
 */

#ifndef _WDT_H_
#define _WDT_H_

/**********************************************************************************
***					          TYPEDEFS AND STRUCTURES							***													  	
**********************************************************************************/
/** 
 * @enum emWdtmode
 *	WDT mode 
 */
enum emwdtmode
{
	E_WDTM_STOP, 	/**< WDT Stopped */
	E_WDTM_INTR,	/**< Interrupt Mode */
	E_WDTM_RST,		/**< System Reset Mode */
	E_WDTM_INTRST	/**< Interrupt and System Reset Mode */
};

/**
 * @enum emWdp
 *	Watchdog Timer Prescale Select 
 */
enum emWdp
{
	E_WDP_2K,		/**< 2K of WDT Cycles */
	E_WDP_4K,		/**< 4K of WDT Cycles */
	E_WDP_8K,		/**< 8K of WDT Cycles */
	E_WDP_16K,		/**< 16K of WDT Cycles */
	E_WDP_32K,		/**< 32K of WDT Cycles */
	E_WDP_64K,		/**< 64K of WDT Cycles */
	E_WDP_128K,		/**< 128K of WDT Cycles */
	E_WDP_256K,		/**< 256K of WDT Cycles */
	E_WDP_512K,		/**< 512K of WDT Cycles */
	E_WDP_1024K,	/**< 1024K of WDT Cycles */
};
 
 
/**********************************************************************************
***						  MACROS AND DEFINITIONS							 ***													 
**********************************************************************************/ 
/** Clear WDT Counter */

/**********************************************************************************
***					          	EXPORTED VARIABLES								***													  	
**********************************************************************************/
#ifndef _DRVWDT_SRC_
#endif
	
/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
void DrvWDT_Init(void);
void DrvWDT_SetWDT(u8 u8Reg);

#endif
/**********************************************************************************
***					          			EOF										***													  	
**********************************************************************************/
