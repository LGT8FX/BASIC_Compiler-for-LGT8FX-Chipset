#ifndef __LGT8F08A_GCCV_H
#define __LGT8F08A_GCCV_H

#include "global.h"

/** compiler relative macros */
#define SEI() asm("sei")
#define CLI() asm("cli")
#define SLEEP() asm("sleep")
#define WDR() asm("wdr")
#define NOP() asm("nop")
#define __ASM asm

/** interrupt */
#define L_VECTOR(N)	__vector_##N
#define LGT_VECTOR(NAME)	\
void NAME (void) __attribute__ ((signal, used, externally_visible));\
void NAME (void)

/**********************************************************************************
*** 						  	EXPORTED FUNCTIONS								*** 													
**********************************************************************************/
/**
 * void Compiler_SetClkDiv(u8 u8ClkDiv)
 */
#define Compiler_SetClkDiv(u8ClkDiv) do { \
	asm("ldi r20, 0x80"); \
	asm("sts 0x61, r20"); \
	asm("sts 0x61, r16"); \
	} while(0)

#define Compiler_SetWDT(u8Wdtcsr) do { \
	asm("mov r17, r16"); \
	asm("ori r17, 0x08"); \
	asm("sts 0x60, r17"); \
	asm("sts 0x60, r16"); \
	} while(0);
    
#endif
